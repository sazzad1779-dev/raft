# Source URL: https://www.sevensix.co.jp/products/koherasbasik_nktp/

# 
# 小型モジュール型 超低ノイズ 狭線幅ファイバレーザー『Koheras BASIK 』
波長1535 ~ 1580nm / 1030 ~ 1120nm　最大出力: 40mW
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 狭線幅CWレーザー光源
『Koheras BASIK』は小型モジュール構成をしており、産業用システムへのOEM統合に適しています。
Koheras BASIK はその名の通り、Koheras シリーズの中で最もシンプルな構成となっており、他の Koheras シリーズのベースモデルとなっております。
製品のお問い合わせ･お見積
### 製品概要
Koheras BASIK は小型モジュール構成をしており、産業用システムへのOEM統合に適しています。Koheras BASIK はその名の通り、Koheras シリーズの中で最もシンプルな構成となっており、他の Koheras シリーズのベースモデルとなっております。例えば、Koherasのベンチトップ型シリーズである Koheras ADJUSTIK 内部には、Koheras BASIK が内蔵されています。
複数台のシングル縦モードレーザを組込み可能なマルチチャンネルシステムである Koheras ACOUSTIK を使うことで、3U 19インチラック筐体に、Koheras BASIK のレーザを最大 16 台分出力することができます。
NKT Photonicsが無償配布している CONTROL と呼ばれるPC用の ソフトウェアを用いることで、Koheras BASIKのピーク波長、出力、RIN抑圧度を読み出し、また直観的に制御できます。
### 特長
- 超低位相雑音と狭線幅
- 安定した単一周波数動作
- 産業向けOEMパッケージ
- マルチチャンネルシステム向け設計 ( ACOUSTIK )
- 高速波長変調を組み込み（オプション）
- PM出力（non-PM出力は要相談）
### 用途
Koheras BASIKは、高い周波数安定性と長いコヒーレンス長が求められる干渉用途で威力を発揮します。海外で多くの採用実績のある典型的な例としては、オイル＆ガスの探索/開発、油田周辺やパイプラインの安全確保のための感震センシングがあります。Koheras BASIKは強度ノイズが低いため（低RIN）でスペクトル安定性も高いため、宇宙産業や風力発電で使われるような LIDARシステムの光源に最適です。また、同じ理由で干渉計を用いるドップラ振動計の光源に用いた場合に振動の正確な計測が可能となります。
### Koheras ACOUSTIK マルチチャンネルプラットフォーム
Koheras ACOUSTIK はKoheras BASIK 単一周波数低ノイズファイバレーザを最大16台搭載可能な電源込のラックシステムです。ACOUSTIK は、搭載中の Koheras BASIK に電源を与え、それぞれを制御します。BASIKは簡単に ACOUSTIK に出し入れすることができます（ 上図は FC/APC コネクタ、モニタ出力なしの Koheras BASIK モジュールを 8台格納した Koheras ACOUSTIK ）。光増幅器モジュールである Koheras BOOSTIK の搭載も可能です。
Koheras ACOUSTIK は堅牢性が求められる産業用途に対応するためパッシブ冷却システムデザインとなっています。マルチチャンネルのセンサシステム用に設計されており、標準的な 3U 19インチラック筐体には、制御エレクトロニクスと電源が含まれています。各 BASIKや BOOSTIKレーザモジュール には、ACOUSTIK のフロントパネルから直接アクセスできます。Koheras ACOUSTIK と搭載したBASIKと BOOSTIKモジュール は NKT Photonicsが無償配布している CONTROL ソフトウェア を用いて制御することができます。
## 資料ダウンロード
- [データシート：Koheras BASIK](https://www.sevensix.co.jp/wp-content/uploads/Koheras_BASIK.pdf#view=Fit)
- [データシート：Koheras ACCOUSTIK](https://www.sevensix.co.jp/wp-content/uploads/Koheras_ACOUSTIK.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ