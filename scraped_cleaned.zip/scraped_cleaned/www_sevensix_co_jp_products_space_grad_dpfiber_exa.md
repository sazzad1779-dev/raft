# Source URL: https://www.sevensix.co.jp/products/space-grad-dpfiber_exail/

# 
# 【宇宙グレード】放射線硬化型ドープファイバ​
_メーカ：_ exail
- 光ファイバ素線 / 光ファイバパッチコード
- SMファイバ
- PMファイバ
- 希土類添加ファイバ (Yb/ Er)
Exail社の「放射線硬化型宇宙グレードドープファイバ」は、宇宙環境での使用を想定して設計された特殊な光ファイバです。
これらのファイバは、希土類元素でドープされており、放射線環境下でも優れた性能を維持します。
特に、宇宙ミッションにおける希土類ドープファイバ増幅器（REDFA）の性能最適化のために開発されました。
製品のお問い合わせ･お見積
## 特長
- 放射線耐性: 宇宙の放射線環境下でも高い耐性を持ち、信頼性の高い動作を保証
- 高性能: 希土類ドープにより、高効率な光増幅を実現
- 最適化設計: シミュレーションツールを活用し、宇宙ミッション向けの性能設計
Exail社は、特殊ファイバー、ブラッグ格子、光変調関連製品を主に光通信、センサー、航空・宇宙分野向けに提供しており、高い信頼性と性能を誇ります。
## 用途
- 宇宙ミッションにおける光ファイバー増幅器
- 放射線環境下での光通信システム
- 高信頼性が求められる光学機器
## 使用詳細
### Er Rad Hard Fibers
|     |     |
| --- | --- |
| 製品型番 | 製品概要 |
| **[IXF-RAD-AMP-1]( | Radiation hardened space grade Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>14 dB/m absorption @ 1530 nm<br>8 dB/m absorption @ 980 nm<br>< 1150 nm cutoff wavelength |
| **[IXF-RAD-AMP-1-PM]( | Radiation hardened space grade PM Erbium doped fiber<br>123 µm cladding diameter<br>245 µm coating diameter<br>18 dB/m absorption @ 1530 nm<br>< 1450 nm cutoff wavelength |
| **[IXF-RAD-AMP-2]( | Radiation hardened space grade Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>25 dB/m absorption @ 1530 nm<br>17 dB/m absorption @ 980 nm<br>< 1150 nm cutoff wavelength |
| **[IXF-RAD-AMP-2-80]( | Radiation hardened space grade Erbium doped fiber<br>80 µm cladding diameter<br>170 µm coating diameter<br>24 dB/m absorption @ 1530 nm<br>16 dB/m absorption @ 980 nm<br>< 1350 nm cutoff wavelength |
| **[IXF-RAD-AMP-2H]( | Radiation hardened space grade Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>35 dB/m absorption @ 1530 nm<br>17 dB/m absorption @ 980 nm<br>< 1350 nm cutoff wavelength |
| **[IXF-RAD-AMP-2H-80]( | Radiation hardened space grade Erbium doped fiber<br>80 µm cladding diameter<br>170 µm coating diameter<br>35 dB/m absorption @ 1530 nm<br>17 dB/m absorption @ 980 nm<br>< 1350 nm cutoff wavelength |
| **[IXF-RAD-AMP-2-PM]( | Radiation hardened space grade PM Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>15.5 dB/m absorption @ 1530 nm<br>< 1200 nm cutoff wavelength |
| **[IXF-RAD-AMP-2H-PM]( | Radiation hardened space grade PM Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>35 dB/m absorption @ 1530 nm<br>< 1350 nm cutoff wavelength |
| **[IXF-RAD-AMP-3]( | Radiation hardened space grade Erbium doped fiber<br>125 µm cladding diameter<br>245 µm coating diameter<br>13.5 dB/m absorption @ 1530 nm<br>16 dB/m absorption @ 980 nm<br>< 1150 nm cutoff wavelength |
### Er/Yb Rad Hard Fibers
|     |     |
| --- | --- |
| 製品型番 | 製品概要 |
| **[IXF-2CF-EY-O-6-130-LNF-RAD]( | 6 µm core diameter<br>Radiation hardened space grade double clad Erbium/Ytterbium co-doped fiber<br>125 µm cladding diameter<br>0.19 core NA<br>▶関連製品：Double clad passive fiber: [IXF-2CF-PAS-6-130-0.17-RAD]( |
| **[IXF-2CF-EY-PM-6-130-LNF-RAD]( | 6 µm core diameter<br>Radiation hardened space grade double clad PM Erbium/Ytterbium co-doped fiber<br>125 µm cladding diameter<br>0.19 core NA<br>PM Panda structure |
| **[IXF-2CF-EY-O-10-130-0.10-RAD-LL]( | 10 µm core diameter<br>Radiation hardened space grade double clad Erbium/Ytterbium co-doped fiber<br>125 µm cladding diameter<br>0.10 core NA |
| **[IXF-2CF-EY-O-12-130-RAD]( | 12 µm core diameter<br>Radiation hardened space grade<br>125 µm cladding diameter<br>0.19 core NA<br>▶関連製品：Double clad passive fiber: [IXF-2CF-PAS-12-130-0.17-RAD]( |
| **[IXF-2CF-EY-PM-12-130-RAD]( | 12 µm core diameter<br>Radiation hardened space grade double clad PM Erbium/Ytterbium co-doped fiber<br>125 µm cladding diameter<br>0.19 core NA<br>PM Panda structure<br>▶関連製品：<br>Double clad PM passive fiber: [IXF-2CF-PAS-PM-12-130-0.17-RAD]( [IXS-COMB-PM-2-1-1-12-130-RAD-A]( |
### Yb Rad Hard Fibers
|     |     |
| --- | --- |
| 製品型番 | 製品概要 |
| **[IXF-2CF-Yb-PM-6-130-RAD]( | 6 µm core diameter<br>Radiation hardened space grade double clad PM Ytterbium doped fiber<br>125 µm cladding diameter<br>0.14 core NA<br>PM Panda structure |
| **[IXF-2CF-Yb-PM-10-130-RAD]( | 10 µm core diameter<br>Radiation hardened space grade double clad PM Ytterbium doped fiber<br>125 µm cladding diameter<br>0.10 core NA<br>PM Panda structure |
## 関連動画
### ▼ EXAIL – Photonics solutions for Laser, Sensing, Communication, Quantum and Space applications
### ▼ Space Quality 変調器・特殊ファイバ│Vol.75
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 【宇宙グレード】位相変調器 \- 動作帯域: 950 ~ 1150 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙グレード】高消光比強度変調器 \- 動作帯域: 1535 ~ 1560 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙向け】低雑音光増幅器 \- 波長: 1550 ~ 1560 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙グレード】偏波保持ジャイロファイバ \- exail光ファイバ素線 / 光ファイバパッチコード