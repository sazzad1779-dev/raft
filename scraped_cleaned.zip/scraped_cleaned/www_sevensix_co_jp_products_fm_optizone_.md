# Source URL: https://www.sevensix.co.jp/products/fm_optizone/

# 
# ファラデーミラー
波長: 1064 ~ 1550nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- ファラデーミラー
- その他光ファイバ部品
中国の深センに拠点を構えるOptizone Technologiesのファラデーミラーです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 高リターンロス
- 高消光比
- 低挿入損失
#### **用途**
- ファイバセンサ
- 光増幅器
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 1064nm、1310nm、1480nm、1550nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、400umベアファイバ、900umルーズチューブ、3mmケーブル、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：1064nm Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-003B-FM-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-004B-FM-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Mini Fiber Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/MFM-1310nm-1480nm-1550nmCAT-10-008B.pdf#view=Fit)
- [データシート：1064nm Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-022B-PMFM-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-023B-PMFM-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Mini Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/MPMFM-1310nm-1480nm-1550nmCAT-09-038A-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ