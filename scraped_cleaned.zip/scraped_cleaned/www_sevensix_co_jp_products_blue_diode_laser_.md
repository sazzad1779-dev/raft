# Source URL: https://www.sevensix.co.jp/products/blue-diode-laser/

# 
# 青色半導体レーザー / ブルーレーザー
波長: 405 ~ 445nm　出力: 160mW ~ 200W
_メーカ：_ BWT Beijing LTD.
- 半導体レーザーダイオード（LD）
- 青色レーザー
✓ 組み込み用のモジュールタイプ
✓ ファイバとコネクタのカスタムが可能
✓ LDドライバについても相談が可能
製品のお問い合わせ･お見積
## 特長
- 高輝度、高出力、小径コア
- 広範囲なパワーレンジ
## 用途
- 高反射材料加工（銅や金）
- レーザーマーキング、3D プリント
- バイオ、医療
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| 製品名 | 型番 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| 405nm 160mW Coaxial Packaged MM Diode Laser | [K405E03CN-0.160W]( | 405 | 0.16 | 40 | 0.22 | Plate Printing – CTP |
| 405nm 30W Fiber Coupled Diode Laser | [K405EMSCN-30.00WN1N-40022]( | 405 | 30 | 400 | 0.22 | バイオ、Laser Direct Writing、3Dプリント |
| 405nm 50W Fiber Coupled Diode Laser | [K405EMSCN-50.00WN1N-40022]( | 405 | 50 | 400 | 0.22 | バイオ、Laser Direct Writing、3Dプリント |
| 445nm 3.5W Fiber Coupled Diode Laser | [K445H03FN-3.500WN0N-10522]( | 445 | 3.5 | 105 | 0.22 | 照明、3Dプリント |
| 445nm 10W Fiber Coupled Diode Laser | [K445HMTFN-10.00WN1N]( | 445 | 10 | 105 | 0.22 | レーザー彫刻、材料加工、3Dプリント |
| 445nm Spatial Light Output Blue Laser | [K445HSEWN Series]( | 445 | 10<br>15<br>20 | ー | ー | レーザー彫刻、科学研究 |
| 445nm 50W Fiber Coupled Diode Laser | [K445HR7FN-50.00W]( | 445 | 50 | 113 | 0.15 | 材料加工、3Dプリント 、科学研究 |
| 445nm 50W Fiber Coupled Diode Laser | [K445FMKFN-50.00WN1N-20022R55ESM]( | 445 | 50 | 200 | 0.22 | 材料加工、3Dプリント、照明 |
| 445nm Fiber Coupled Blue Laser | [K445HR6FN Series V1.1]( | 445 | 100<br>150<br>200 | 105 | 0.22 | 材料加工、3Dプリント |
解説・関連動画▼
『高出力青色レーザ』導入で加工の歴史が変わる！？│Vol.016
## 製品に関するお問い合わせ
この製品のお問い合わせ