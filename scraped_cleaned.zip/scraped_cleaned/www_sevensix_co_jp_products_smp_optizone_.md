# Source URL: https://www.sevensix.co.jp/products/smp_optizone/

# 
# シングルモードパッチコード
波長: 980 ~ 1550nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ素線 / 光ファイバパッチコード
- SMファイバパッチコード
- 光ファイバパッチコード
中国の深センに拠点を構えるOptizone Technologiesのシングルモードパッチコードです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間15,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低損失
- 高リターンロス
#### **用途**
- 研究開発
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 980nm、1064nm、1310nm、1480nm、1550nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、FERRULE、None |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：980nm、1064nm、1310nm、1480nm、1550nm Patchcord](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-007C-Patchcord-405nm2000nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ