# Source URL: https://www.sevensix.co.jp/products/sld_innolume/

# 
# SLD光源
波長: 830 ~ 1250nm
_メーカ：_ Innolume GmbH
- ファイバーレーザー・その他光源
- UV光源/ LED光源/ SLD光源
✓ 超広帯域のASEスペクトル
✓ 波長と用途に合わせたピグテールファイバを選択可能
✓ 14ピンバタフライタイプのモジュール
✓ RoHS規制対応
製品のお問い合わせ･お見積
## 特長
SLD (Superluminescent Light emitting Diode) は半導体レーザーとよく似た半導体光源です。
広帯域スペクトルを持つSLD光源のピーク波長と平均出力は半導体の活性層の組成と注入電流レベルに依存します。
SLD は導波路に沿って自然放出光が大きく増幅 (> 30 dB) されるように設計されています。(シングルパスです)
半導体レーザーと違い、増幅された光は活性層にほとんど戻らないためレーザー発振しません。
これは、活性層の光の端面に対して導波路が斜めになるように造られており、端面にARコーティングが施されているためです。
半導体レーザーに比べて広いスペクトルを持つ光源 (時間コヒーレンスが低い) ですが、ハロゲンランプなどの白色光源 (同じく時間コヒーレンスが低い) と異なり高い空間コヒーレンスを持っているので、シングルモード光ファイバ (SMF) に効率よく結合することができます。OCTなど 白色干渉を用いる用途では、低い時間コヒーレンスを持つ光源で高い空間分解能を持つイメージングを実現できます。
(コヒーレンス長といえば多くの場合は光源の時間コヒーレンスを指します)
Innolume の SLD 光源は通常 14ピンバタフライタイプのモジュールで出荷されます。150 mW の高出力タイプ、100 nm を超える広帯域幅タイプ、OCTなどの用途にも適した広帯域で 低リップル (典型値  0.02 dB RMS) モデルのご用意があります。
量子ドット技術を用いて、他社では難しい 1100 ~ 1250 nm の波長帯の SLD 光源のラインナップも用意しています。
SLD のピグテールファイバは、波長と好みによって 780-HP, HI1060, SMF-28, PM780, PM980, PM1300 からお選びいただけます。PMF をご選択いただいた場合の PER は 20 dB です。
Innolume は、SLD 光源と一緒にお使いいただけるコンパクト設計の温度コントローラ内蔵のドライバをご用意しています。
操作用のドライバソフトもインストール済みで、複数のピンアサインに対応しています。
## 用途
- ファイバセンサー、計測器、分光器
- スペクトラムドメインを用いた干渉測定
## 仕様詳細
|     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 用途 | 製品概要 | 平均波長(nm) | スペクトル幅 (3dB)nm | 出力(mW) | スペクトルディップ(dB) | ASEリップル (RMS)dB | 順電流(A) | 順電圧(V) | 偏光消光比(dB) |
| [SLD0830010YY050MXXXX]( | OCT, material processing, sensing, research | Superluminescent diode at 830nm in BTF package | 830 | 10 | 50 | – | 0.05 | 350 | 1.8 | 17 |
| [SLD1000100YY015MXXXX]( | sensing, research | Superluminescent diode at 1000nm in BTF package | 1000 | 100 | 15 | 1 | 0.02 | 400 | 1.6 | 20 |
| [SLD1030110YY012MXXXX]( | sensing, research | Superluminescent diode at 1030nm in BTF package | 1030 | 110 | 12 | 4 | 0.03 | 400 | 1.7 | 19 |
| [SLD1030025YY130MXXXX]( | material processing, sensing, research | Superluminescent diode at 1030nm in BTF package | 1030 | 25 | 130 | – | 0.06 | 800 | 1.8 | 21 |
| [SLD1050120YY040MXXXX]( | sensing, research | Superluminescent diode at 1055nm in BTF package | 1055 | 120 | 40 | 5 | 0.04 | 700 | 1.7 | 20 |
| [SLD1060020YY120MXXXX]( | sensing, research | Superluminescent diode at 1060nm in BTF package | 1060 | 20 | 120 | – | 0.04 | 800 | 1.8 | 20 |
| [SLD1060015YY250MXXXX]( | medical devices, sensing, research | Superluminescent diode at 1060nm in BTF package | 1060 | 15 | 250 | – | 0.1 | 1500 | 1.9 | 21 |
| [SLD1064020YY300MXXXX]( | sensing, research | Superluminescent diode at 1064nm in BTF package | 1064 | 20 | 300 | – | 0.8 | 800 | 1.9 | 18 |
| [SLD1090030YY100MXXXX]( | sensing, research | Superluminescent diode at 1090nm in BTF package | 1090 | 30 | 100 | – | 0.06 | 800 | 1.7 | 15 |
| [SLD1120020YY030MXXXX]( | OCT, sensing, research | Superluminescent diode at 1120nm in BTF package | 1120 | 20 | 30 | – | 0.03 | 300 | 1.5 | 20 |
| [SLD1140080YY0D5MXXXX]( | sensing, research | Superluminescent diode at 1140nm in BTF package | 1140 | 80 | 0.5 | 4 | 0.02 | 250 | 1.3 | 19 |
| [SLD1190090YY0D5MXXXX]( | sensing, research | Superluminescent diode at 1190nm in BTF package | 1190 | 90 | 0.5 | 5 | 0.01 | 315 | 1.4 | 19 |
| [SLD1250110YY004MXXXX]( | communication, sensing, research | Superluminescent diode at 1250nm in BTF package | 1250 | 110 | 4 | 6 | 0.01 | 800 | 1.5 | 19 |
## 製品に関するお問い合わせ
この製品のお問い合わせ