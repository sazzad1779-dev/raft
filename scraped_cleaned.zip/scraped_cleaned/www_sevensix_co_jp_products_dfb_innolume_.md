# Source URL: https://www.sevensix.co.jp/products/dfb_innolume/

# 
# DFB 単一周波数レーザー
波長: 968 ~ 1330nm　SMF / PMF　出力: 25 ~ 100mW
_メーカ：_ Innolume GmbH
- 半導体レーザーダイオード（LD）
- シードLD
- DFBレーザー
✓ ファイバピグテール DFB レーザー
✓ 専用の温調機能付きドライバあり
✓ RoHS 指令準拠
製品のお問い合わせ･お見積
## 特長
- モードホップフリーの連続チューニング
- 自社製ミラーコーティング技術による高信頼性
- PM980 / HI1060 or PM1300 / SMF28 ファイバより選択
- バーンイン、温度サイクル試験後に出荷
- 光モニタリング PD 内蔵
また、DFBレーザー用の温調機能付きドライバもご用意しております。お気軽にお問合せください。
## 用途
- ガスセンシング用光源
- ファイバレーザのシード光源
- 光学測定器の組み込み
## 仕様詳細
|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | ピーク波長(nm) | 出力(mW) | 順電流(mA) | 順電圧(V) | 閾値電流(mA) | サイドモード抑圧比(dB) | 波長温度可変(pm/K) | 波長電流可変(pm/mA) | 偏光消光比(dB) | 備付け光アイソレータ |
| [DFB09XX000YY030MFXXX]( | Fiber coupled DFB laser diode at 980nm | 968 – 986 | 30 | 100 | 1.35 | 20 | 55 | 90 | 1.5 | 18 |  |
| [DFB10XX000YY050MFXXX]( | Fiber coupled DFB laser diode at 1060nm | 1020 – 1120 | 50 | 200 | 1.7 | 30 | 55 | 100 | 2 | 18 |  |
| [DFB10XX000YY025MFVXX]( | Fiber coupled DFB laser diode at 1060nm | 1020 – 1120 | 25 | 200 | 1.7 | 30 | 55 | 100 | 2 | 18 | YES |
| [DFB11XX000YY050MFXXX]( | Fiber coupled DFB laser diode at 1160nm | 1120 – 1200 | 50 | 300 | 1.5 | 30 | 50 | 110 | 2 | 18 |  |
| [DFB11XX000YY025MFVXX]( | Fiber coupled DFB laser diode at 1160nm | 1120 – 1200 | 30 | 300 | 1.5 | 30 | 50 | 110 | 2 | 18 | YES |
| [DFB12XX000YY050MFXXX]( | Fiber coupled DFB laser diode at 1240nm | 1200 – 1280 | 50 | 350 | 1.7 | 50 | 50 | 120 | 2 | 18 |  |
| [DFB12XX000YY050MFVXX]( | Fiber coupled DFB laser diode at 1240nm | 1200 – 1280 | 50 | 350 | 1.7 | 50 | 50 | 120 | 2 | 18 | YES |
| [DFB13XX000YY050MFXXX]( | Fiber coupled DFB laser diode at 1300nm | 1280 – 1330 | 50 | 350 | 1.7 | 50 | 50 | 120 | 2.5 | 18 |  |
| [DFB13XX000YY050MFVXX]( | Fiber coupled DFB laser diode at 1310nm | 1280 – 1330 | 50 | 350 | 1.7 | 50 | 50 | 120 | 2.5 | 18 | YES |
| [DFB13XX000YY100MFVXX]( | Fiber coupled DFB laser diode at 1310nm | 1300 – 1330 | 100 | 800 | 2.6 | 60 | 50 | 120 | 4 | 18 | YES |
## 製品に関するお問い合わせ
この製品のお問い合わせ