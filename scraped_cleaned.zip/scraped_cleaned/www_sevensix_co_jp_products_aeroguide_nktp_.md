# Source URL: https://www.sevensix.co.jp/products/aeroguide_nktp/

# 
# aeroGUIDE ラージモードエリアフォトニック結晶ファイバパッチコード
波長：400 ~ 2000nm
_メーカ：_ NKT Photonics A/S
- 光ファイバ素線 / 光ファイバパッチコード
- PCFパッチコード
- 光ファイバパッチコード
ラージモードエリアフォトニック結晶ファイバを用いたパッチコード
製品のお問い合わせ･お見積
aeroGUIDE
ラージモードエリアフォトニック結晶ファイバパッチコード
## ◆ aeroGUIDE シリーズ
ラージモードエリア（LMA）フォトニック結晶ファイバのLMA-PM-5、LMA-8、LMA-PM-10,、LMA-PM-15 の4ファイバの両端をFC/APCコネクタ付けしたパッチコードとなります。
パッチコードの耐久パワーは2W CWとなります。
## ◆ aeroGUIDE Power シリーズ
LMAフォトニック結晶ファイバのLMA-PM-15 の4ファイバの両端をSMA905コネクタ付けしたパッチコードとなります。
## 特長
- シングルモード伝送
- 400~2000nmの広帯域伝送が可能
## 資料ダウンロード
- [データシート：aeroGUIDE](https://www.sevensix.co.jp/wp-content/uploads/aeroGUIDE.pdf#view=Fit)
- [データシート：aeroGUIDE Power](https://www.sevensix.co.jp/wp-content/uploads/aeroGUIDE-Power.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ