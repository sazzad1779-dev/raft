# Source URL: https://www.sevensix.co.jp/products/%e2%80%bbks-photonics%e2%80%bb%e3%80%80%e9%80%9a%e4%bf%a1%e5%b8%af-%e3%83%a2%e3%83%bc%e3%83%89%e5%88%86%e5%89%b2%e3%83%9e%e3%83%ab%e3%83%81%e3%83%97%e3%83%ac%e3%82%af%e3%82%b5-%e3%83%87%e3%83%9e//

# 
# 通信帯 モード分割マルチプレクサ/デマルチプレクサ
波長: 1515 ~ 1590nm
_メーカ：_ KS Photonics Inc.
- 光ファイバ部品
- その他光ファイバ部品
KS Photonics社のフューモードファイバ( Few Mode Fiber )関連の研究に最適なマルチプレクサ / デマルチプレクサです。内部に長周期グレーティングを使用しております。
製品のお問い合わせ･お見積
## 特長
- 全ファイバ型
- 低損失の マックス/デマックス
- 通信帯域に最適化
- コネクタの有無選択可能
- モード数のカスタマイズ可能
## 用途
- 光通信におけるモード分割多重化
- 高次モードの励起
## 仕様詳細
| 動作波長 **(nm)** | 1515 ～ 1590 |
| コネクタ | FC/APC, FC/PC, FC/UPC, FC/SPC |
| **バンド最適化 (nm)** | 1530 – 1565 (C Band) |
| **寸法** | 50(H)×220(W)×250(D) |
KS Photonicsのモード分割デマルチプレクサ/マルチプレクサ (MDDM) は シングルモードファイバ ( SMF : Single Mode Fiber ) 中のLP01 モードをフューモードファイバ ( FMF : Few Mode Fiber ) に導くことで所望の高次モードを得ることができる全ファイバ型の双方向でお使いいただける装置です（逆にフューモードファイバ中の高次モードを LP01 に変換することもできます）。
モード多重通信や、センサシステムに有用なデバイスです。
側面研磨された SMF と FMFの2つのファイバからなる50/50カプラは、エバネッセントモードが効率的に結合されるように配置されています。モード数は LP01 / LP11 a, b / LP21 a, b / LP02 の中から、 2 – 6 の範囲でお選びいただけます（発注時固定、他のモードもカスタム可能）。
広い波長に渡って高い結合効率と高い消光比を実現しています。結合効率と消光比はモードに依存します。
ページ上部の資料ダウンロードにて、データシート及びマニュアルにて詳細ご覧ください。
KS Photonics mode division multiplexer - YouTube
Photo image of KS PHOTONICS
KS PHOTONICS
32 subscribers
KS Photonics mode division multiplexer
KS PHOTONICS
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 0:37
•Live
•
■ 同様構成の MDDM オープンアクセスの論文 Opt. Express 25, 5734-5741 (2017).
>\> All-fiber 6-mode multiplexers based on fiber mode selective couplers
## 資料ダウンロード
- [モード分割マルチプレクサ/デマルチプレクサ MDDM データシート](https://www.sevensix.co.jp/wp-content/uploads/%E9%80%9A%E4%BF%A1%E5%B8%AF-%E3%83%A2%E3%83%BC%E3%83%89%E5%88%86%E5%89%B2%E3%83%9E%E3%83%AB%E3%83%81%E3%83%97%E3%83%AC%E3%82%AF%E3%82%B5%E3%83%87%E3%83%9E%E3%83%AB%E3%83%81%E3%83%97%E3%83%AC%E3%82%AF%E3%82%B5-%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0.pdf#view=Fit)
- [モード分割マルチプレクサ/デマルチプレクサ MDDM マニュアル](https://www.sevensix.co.jp/wp-content/uploads/%E9%80%9A%E4%BF%A1%E5%B8%AF-%E3%83%A2%E3%83%BC%E3%83%89%E5%88%86%E5%89%B2%E3%83%9E%E3%83%AB%E3%83%81%E3%83%97%E3%83%AC%E3%82%AF%E3%82%B5%E3%83%87%E3%83%9E%E3%83%AB%E3%83%81%E3%83%97%E3%83%AC%E3%82%AF%E3%82%B5-%E3%83%9E%E3%83%8B%E3%83%A5%E3%82%A2%E3%83%AB.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ