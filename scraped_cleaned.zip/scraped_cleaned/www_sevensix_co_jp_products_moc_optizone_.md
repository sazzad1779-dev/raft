# Source URL: https://www.sevensix.co.jp/products/moc_optizone/

# 
# マルチモード光コリメータ
波長: 850 ~ 1550nm　入力パワー: 500mW
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- MMコリメータ
- 光コリメータ
中国の深センに拠点を構えるOptizone Technologiesのマルチモード光コリメータです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間80,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特徴**
- 低挿入損失
- 高リターンロス
#### **用途**
- ファイバーセンサ
- 研究用途
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 850nm、980nm、1064nm、1310nm、1480nm、1550nm、その他も対応可 |
| 入力パワー | 500mW |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、 その他も対応可 |
| ファイバ長 | 1.75mその他も対応可 |
## 資料ダウンロード
- [データシート：850nm、980nm、1064nm、1310nm、1480nm、1550nm Multimode Fiber Collimator](https://www.sevensix.co.jp/wp-content/uploads/CAT-08-001C-MMC-850nm1064nm-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ