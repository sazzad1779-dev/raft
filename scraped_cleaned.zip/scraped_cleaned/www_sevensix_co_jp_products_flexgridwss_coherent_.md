# Source URL: https://www.sevensix.co.jp/products/flexgridwss_coherent/

# 
# Flexgrid 波長選択型 光スイッチ (WSS)
周波数レンジ：4.8THz ~ 10THz (C+L band)
_メーカ：_ Coherent (旧 II-VI)
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光スイッチ
LCoS(Liquid Crystal on Silicon)技術を利用したFlexgrid対応のWSS(波長選択型光スイッチ)です。周波数レンジは4.8THz～10THz(C+L band)をサポート。
ポート構成も1×N、2x1xN、4x1xN構成に対応しています。
製品のお問い合わせ･お見積)
## 特長
- 多様なポート構成に対応可能　2x1xN, 4x1xN, Colorless/Directionless 2xNxM, 1xN (N≦20)
- 4.8～10 THz(C+L band)の周波数レンジをサポート
- LCoS(Liquid crystal on silicon)をベースに構成されているため、可動部がなく安定で堅牢
- オルタネートコモンポート
- Flexgrid対応でチャンネル幅の動的制御に対応 (ITUフレキシブルグリッドG.694.1準拠))
– 6.25GHz 幅分解能（デフォルト、3.125GHz はオプション）
– スーパーチャンネルに割り当てる周波数に制約を受けない
– 6.25GHzの分解能で、ヒットレスなチャンネルのワイド化、ナロー化、マイグレーションが可能
- Flexgrid対応でチャンネル等価制御可能
– 66.25 GHz 分解能
– 0 – 20dB レンジ
– ヒットレス・チャネルおよびチャネル内パワーイコライゼーション
2021 Lightwave Innovation Reviewsを受賞しました。
Flexgrid(R) C+L Wavelength Selective Switch
Flexgrid(R) Quad Wavelength Selective Switch
- ROADM Node on a blade – 1枚のブレードで複数の度数を実現。
- マルチファイバーDWDMネットワーク – 方向ごとに複数のファイバーペア
- カラーレス ディレクショナルレス アド/ドロップ
- 1 + Tb/s トランスポートレディ
- マルチキャリア・スーパーチャネル
- 波長ルーティングを揃える
- フレックスグリッドと固定グリッド ITU 50GHZと100GHz
## 用途
- データセンター
- 基幹系インフラ
- 通信
## 仕様詳細
近年DWDM光ネットワークにおいて、光パスをより柔軟にフレキシブルなものにする必要性から、
ROADM(Reconfigurable Optical Add/Drop Multiplexers)システムはますます重要性を増しています。
Flexgrid技術は、400Gb/sや1Tb/s信号などの極めて高いデータレートや変調方式において、
光の帯域の利用効率を最大化するために必要不可欠なものとなっています。
新しい伝送方式をネットワークへ適用するために、チャネル間隔を柔軟に変更したり、
チャネル数をリアルタイムに増やしたりといった、フレキシブルな拡張性が求められるためです。
colorless directionless(CD) ROADMsやcolorless, directionless, contentionless(CDC)は、
route & select(R&S) ROADMアーキテクチャにより実現が可能です。
これは、1方向に2つのWSSを必要とするbroadcast & select(B&S) ROADMと異なり、
1方向に1つのWSSのみで構成することができます。
二つのWSSを一つのモジュールに組み込んだDual WSSは、R&S ROADMシステムに最適な製品です。
またDual WSSは、CD 2xNxM Add/Dropモジュールとして使用することもできます。
また4つのWSSを1つのモジュールに組み込んだQuad WSSにも対応しています。
LCoS(Liquid Crystal on Silicon)技術を利用したFlexgrid対応のWSS(波長選択型光スイッチ)です。
周波数レンジは4.8THz～10THz(C+L band)をサポート。
ポート構成も1×N、2x1xN、4x1xN構成に対応しています。
## 資料ダウンロード
- [カタログ：Flexgrid 波長選択型 光スイッチ (WSS) Dual WSS](https://www.sevensix.co.jp/wp-content/uploads/Finisar-WSS-Dual-Wavelength-Selective-Switch-WSS.pdf#view=Fit)
- [カタログ：Flexgrid 波長選択型 光スイッチ (WSS) Single WSS](https://www.sevensix.co.jp/wp-content/uploads/Finisar-WSS-Single-Wavelength-Selective-Switch-WSS.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ)