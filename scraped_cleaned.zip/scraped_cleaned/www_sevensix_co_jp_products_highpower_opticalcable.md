# Source URL: https://www.sevensix.co.jp/products/highpower-opticalcable_optizone/

# 
# 高出力レーザー用 光ファイバケーブル
波長: 915 ~ 1080nm　入力パワー: 1000 ~ 20000W
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- 高出力伝送用ファイバ
中国の深センに拠点を構えるOptizone Technologiesの高出力レーザー用 光ファイバケーブルです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- 水冷
- クラッドポンプストリッパー
- インターロック機能搭載
#### **用途**
- ファイバレーザー
- レーザー加工（切断/溶接）
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 915nm、950nm、975nm、1064nm、1080nm、その他も対応可 |
| 入力パワー | 1000W、1500W、2000W、3000W、3500W、4000W、6000W、8000W、10000W、12000W、20000W、その他も対応可 |
| ファイバタイプ | Nufern GDF-20/400-M、Coractive DCF-50/400、Nufern BD-S100/120/360-STN、Nufern BD-S400/440/660-STN、Nufern BD-S1000/1100-STN、Nufern MM-S400/480、その他も対応可 |
| ファイバ被膜長 | 10m、20m、30m、その他も対応可 |
| ファイバ長 | 1m、2m、3m、その他も対応可 |
#### **パッケージタイプ**
Type Q1
Type Q4
Type Q8
Type Q16
Type Q27
Type Q28
Type Q29
Type Q30
Type D1
### 解説・関連動画▼
高出力用CWレーザーの最重要コンポーネントFOC/End Cap│Vol.46
## 資料ダウンロード
- [データシート：Type Q1 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-068B-FOC-06-QB-1000-22-H-10-Q1.pdf#view=Fit)
- [データシート：Type Q8 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/cd26816b1168ac71d216adbfe0a0c740.pdf#view=Fit)
- [データシート：Type Q16 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/FOC-Q16-CAT-05-078D-1.pdf#view=Fit)
- [データシート：Type Q4 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-071D-FOC-Q4-1.pdf#view=Fit)
- [データシート：Type Q27、Q28、Q29、Q30 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-079B-FOC-Q27Q28Q29Q30-1.pdf#view=Fit)
- [データシート：Type D1 Fiber Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-081B-Fiber-Optical-Cable-Type-D1-QD-Indirect-water-cooling-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ