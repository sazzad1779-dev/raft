# Source URL: https://www.sevensix.co.jp/products/uvlaser_agiltron/

# 
# 紫外線硬化樹脂用 固体UV光源
波長: 365 ~ 440nm
_メーカ：_ Agiltron Inc.
- ファイバーレーザー・その他光源
- UV光源/ LED光源/ SLD光源
本製品は紫外線硬化樹脂を使用される際の光源として最適な光源となります。樹脂の特性に応じて、365nm, 385nm, 405nm, 440nmの中心波長よりご選択頂けます。
製品のお問い合わせ･お見積
#### **特長**
- 長時間連続動作
- 小型
- ハイパワー
- 低ランニングコスト
- 長寿命
- リモートUSB個別電源制御
#### **用途**
- UV接着剤硬化
- UV照射実験
#### **仕様詳細**
■ [4ヘッド UV光源](　(4-Head Solid-State UV Spot Light)
|     |     |     |
| --- | --- | --- |
| パラメータ | 内容 | 単位 |
| 波長 | 365±5, 385±5, 405, 440 | nm |
| UV放射照度 | 2.0 ~ 3.2 \* | W/cm2 |
| 硬化時間 | 1秒 ~ 18 時間 | 秒 / 時間 |
| UVスポットサイズ | Φ4 | mm |
| 動作距離 | 20 | mm |
| 冷却方式 | 強制空冷、ファン |  |
| 動作寿命 | 30,000 | 時間 |
■ [UV flood 光源](　(Solid-State UV Flood Light)
|     |     |     |
| --- | --- | --- |
| パラメータ | 内容 | 単位 |
| 波長 | 380±5 | nm |
| UV放射照度 | 0.8 \* | W/cm2 |
| 硬化時間 | 10 ~ 60 | 分 |
| UVスポットサイズ | 50 ~ 100 | mm |
| UV硬化距離 | 30 ~ 100 | mm |
| 動作寿命 | 30,000 | 時間 |
■ [UV Spot 光源](　(Ultra High Power Deep UV Curing Spot Light/Lamp/System)
|     |     |     |
| --- | --- | --- |
| パラメータ | 内容 | 単位 |
| 波長 | 365±5 | nm |
| UV放射照度 | 4.0 – 5.0 \* | W/cm2 |
| 硬化時間 | Max. 60 Sec. or 60 Min | 分 |
| UVスポットサイズ | Φ4 ~ 50 | mm |
| UV硬化距離 | 20 ~ 100 | mm |
| 冷却方式 | 送風 |  |
| 動作寿命 | 25,000 | 時間 |
## 資料ダウンロード
- [4ヘッド UV光源『SUVA-03』データシート](https://www.sevensix.co.jp/wp-content/uploads/%E7%B4%AB%E5%A4%96%E7%B7%9A%E7%A1%AC%E5%8C%96%E6%A8%B9%E8%84%82%E7%94%A8-%E5%9B%BA%E4%BD%93UV%E5%85%89%E6%BA%90-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
- [UV flood 光源『SUVA-02』のデータシート](https://www.sevensix.co.jp/wp-content/uploads/%E7%B4%AB%E5%A4%96%E7%B7%9A%E7%A1%AC%E5%8C%96%E6%A8%B9%E8%84%82%E7%94%A8-%E5%9B%BA%E4%BD%93UV%E5%85%89%E6%BA%90-SUVA-380nm-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
- [UV Spot 光源『SUVA-01』のデータシート](https://www.sevensix.co.jp/wp-content/uploads/%E7%B4%AB%E5%A4%96%E7%B7%9A%E7%A1%AC%E5%8C%96%E6%A8%B9%E8%84%82%E7%94%A8-%E5%9B%BA%E4%BD%93UV%E5%85%89%E6%BA%90-SUVA%E3%80%80365nm-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ