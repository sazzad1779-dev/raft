# Source URL: https://www.sevensix.co.jp/products/sdoct_lumedica/

# 
# 眼底検査の研究用 SD-OCT システム
波長: 840 ~ 1310 nm
_メーカ：_ Lumedica, inc.
- その他・アクセサリ
- OCTシステム
スペクトル領域光コヒーレンス・トモグラフィー（SD-OCT）は、光を使って試料の層を画像化するものです。OCTはライフサイエンス研究および産業界で多くのアプリケーションを有しています。ルメディカは、コンパクトで手頃な価格のOCTエンジンを再設計し、OCTを科学者に身近なものにしました。
製品のお問い合わせ･お見積
## 特長
- リーズナブル
OQ LabScopeの価格は、他のOCTシステムの数分の一です。これでようやく、多くの研究者がこの技術を手に入れることができるようになりました
- 高精度
OQ Labscopeは512×512ピクセルの画像を生成し、3倍の価格のOCTシステムに匹敵する性能を有しています。
- 簡単な操作性
セットアップではなく、サイエンスに集中する。ソフトウェアは簡単に習得できるので、箱から出してすぐに画像を生成することができます。
## 用途
- 眼底検査の研究用
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
|  | OQ LabScope 2.0 | OQ LabScope 2.0/X | OQ LabScope 2.0/R | OQ LabScope 2.0/XR | OQ LabScope 2.0/SX | OQ StrataScope1.0 |
| 中心波長 | 840 nm | 840 nm | 850 nm | 850 nm | 880 nm | 1310 nm |
| 深さ分解能 空気/組織 | 7/5μm | 7/5μm | 5/3μm | 5/3μm | 3/2μm | 14/10μm |
| 横分解能 | 18 μm | 18 μm | 18 μm | 18 μm | 18 μm | 20 μm |
| リニアスキャン範囲 | 7 mm | 7mm | 7mm | 7mm | 7mm | 7mm |
| Aスキャンラインレート | 13,000/sec | 40,000/sec | 13,000/sec | 40,000/sec | 40,000/sec | 18,000/sec |
| Bスキャン画像レート | 20/sec | 50/sec | 20/sec | 50/sec | 50/sec | 30/sec |
Lumedica Final - YouTube
Photo image of Andy Wiersma
Andy Wiersma
No subscribers
Lumedica Final
Andy Wiersma
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
More videos
## More videos
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:03
0:03 / 6:58
•Live
•
■　**OQ Labscope 1.0 の用途**
Photonics West 2019 - LabScope 2.0 Announcement - YouTube
Photo image of Lumedica
Lumedica
77 subscribers
Photonics West 2019 - LabScope 2.0 Announcement
Lumedica
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:59
0:59 / 1:11
•Live
•
■ **LabScope 2.0 Announcement**
## 製品に関するお問い合わせ
この製品のお問い合わせ