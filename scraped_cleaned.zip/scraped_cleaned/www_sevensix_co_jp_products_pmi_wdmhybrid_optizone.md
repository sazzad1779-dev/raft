# Source URL: https://www.sevensix.co.jp/products/pmi_wdmhybrid_optizone/

# 
# 偏波保持アイソレータ / WDMハイブリッド
波長: 1530 ~ 1580nm / 1530 ~ 1565nm
_メーカ：_ Optizone Technology Limited
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光フィルタ
- 光ファイバアイソレータ
- WDM付きアイソレータ
- 光ハイブリッド
- 光ファイバ部品
- 光フィルタ
- 光ファイバアイソレータ
- WDM付きアイソレータ
- 光ハイブリッド
中国の深センに拠点を構えるOptizone Technologiesの偏波保持アイソレータ/WDMハイブリッドです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間20,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 低挿入損失
## 用途
- ファイバレーザ
- ファイバセンサ
- 光増幅器
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 1530-1580nm、1530-1565nm |
| ステージ | シングル、デュアル |
| 光軸アライメント | Fast Axis Blocked、Both Axis Working |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
﻿
### パッケージ
　　　　　　　　　　標準タイプ
　　　　　　　　　　小型タイプ
## 資料ダウンロード
- [データシート：1530-1580nm PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-028F-PMIWDM-15301565nm-new.pdf#view=Fit)
- [データシート：1530-1565nm High Power PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-050D-HPMIWDM-15301565nm.pdf#view=Fit)
- [データシート：1530-1565nm Mini PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/MPMIWDM-CAT-09-039B.pdf#view=Fit)
- [データシート：1530-1565nm PM Tap Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-031F-PMTIWDM-5598nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ