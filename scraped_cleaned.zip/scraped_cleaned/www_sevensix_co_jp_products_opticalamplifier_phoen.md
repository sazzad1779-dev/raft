# Source URL: https://www.sevensix.co.jp/products/opticalamplifier_phoenix/

# 
# フューモード用光増幅器
波長: 1535 ~ 1560nm
_メーカ：_ Phoenix Photonics Ltd.
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光増幅器
- 光ファイバアンプ
空間分割多重(SDM)用に開発されたクラッド励起タイプのフューモードエルビウム添加ファイバ増幅器(FM-EDFA)です。
動作波長域はC-band帯、現在3モードと6モードに対応。同製品はヨーロッパの共同R&DプロジェクトであるMODE-GAPの伝送実験用に開発されました。
製品のお問い合わせ･お見積
#### **特長**
- USBインターフェース経由で利得を制御可能で19インチラックに搭載
- 6モード(LP01, LP11a, LP11b, LP21a, LP21b, LP02)ファイバシステムに対応
- 全てのモードに対して低い雑音指数、高い利得(C-band帯全域を通してフラット)を実現
#### **用途**
- MODE-GAPの伝送実験用
#### **仕様詳細**
|     |     |
| --- | --- |
| パラメータ | 内容 |
| 波長範囲 | 1535 – 1560nm (C-band) |
| 入力電力範囲 | -10 to 0 dBm per mode |
| 空間モード数 | 3 or 6 |
| 小信号利得 | \> 20dB |
| ポンプポート数 | 1-4 |
| 最大出力電力 | 17dBm |
| 差動モード利得 | < 4dB |
| 雑音指数 | < 6dB |
| 入出力コネクタ | Bare fiber or FC/PC or FC/APC |
| 制御電子部寸法 | 19” Rack Unit |
| 動作電圧 | 110-230 VAC |
| 回線周波数 | 50 to 60 Hz |
## 資料ダウンロード
- [フューモード用光増幅器　データシート](https://www.sevensix.co.jp/wp-content/uploads/Few-modeEDFA_V1_01409.pdf#view=Fit)
- [ホワイトペーパー](https://www.sevensix.co.jp/wp-content/uploads/Fontaine-cladding-pumped-paper-OFC-2015-PD.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ