# Source URL: https://www.sevensix.co.jp/products/switch_rome_nttat/

# 
# 光スイッチ ROMEシリーズ
光配線切替のリモート制御を実現
_メーカ：_ NTT AT
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光スイッチ
ROME(Robotic Optical Management Engine)は、ネットワーク開発ラボやデータセンター運用上の機器間の光配線切替の、リモート制御環境を実現する光スイッチです。ROMEを導入することにより、リモート制御できるラボ環境の構築、機器稼働率・利用効率の向上、配線管理の省力化を実現できます。
デモ機もございますのでお問合せください。
製品のお問い合わせ･お見積
## 特長
- フロントパネルのポートに各々接続され網目のように縦横に配列されたスイッチング機構により、ポート経路を切り替え可能
## 用途
### ■ ユースケース①　ラボの自動化、リモート制御
例えば、光関連の実験ラボの場合、光源、光フィルタ類(フィルタ、アッテネータ)、測定器(光スペアナ、ＰＤ等)をROME及びネットワークへ接続することで、 **遠隔地から実験** を行ったり、 **お客様へリモートで製品デモ** を実施したりすることが可能となります。伝送試験ラボにおいては、伝送装置(光トランシーバ)、光合分波器、光アンプ、光分散シミュレータ、光スペアナ、ダミーファイバ、光アッテネータ等をROMEへ接続しておくことで、 **自在に試験環境・トポロジの構築・組み変え** たり、遠隔地から実験を行ったりすることが可能となります。
### ■ ユースケース②　データセンター内の回線開通作業の自動化
ROME in the Data Center - YouTube
Photo image of wave2wavesolution
wave2wavesolution
77 subscribers
ROME in the Data Center
wave2wavesolution
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 16:42
•Live
•
### ■ 導入メリット①：スイッチング方式の比較
MEMS型光スイッチは高速なスイッチング速度が特徴ですが、リモート制御環境構築用のスイッチング機構としてはコストや光損失に課題があります。ROMEはこれらの弱点を克服し、光配線のリモート制御環境実現に最適化された製品です。
### ■ 導入メリット②：新たな価値の提供
従来のマニュアルによる試験系構築には、都度 **機材の搬出入やセッティングに工数** が掛かり、また物理的な制約により **機材の流動性・利用効率に限界** がありました。ラボで個別に設置・運用されている試験・実験用機材の光インターフェースをROMEへ接続しておくことで、試験機材を **ネットワークへのコネクテッドな環境に** おくことができます。これにより、パソコン上のGUI操作で繋ぎたい機器同士を接続し **試験系・実験系を構築** したり、ネットワーク試験環境において **トポロジを自在に構成** したりできるようになります。
## 仕様詳細
### ■ ROME mini
### ■ ROME500
## ■ 動作の仕組み
フロントパネルのポートに各々接続され網目のように縦横に配列されたスイッチング機構により、ポート経路を切り替えます。
## ■ 製品ライブデモ動画
## 資料ダウンロード
- [カタログ：『ROME500』](https://www.sevensix.co.jp/wp-content/uploads/ROME500-%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0.pdf#view=Fit)
- [データシート：『ROME mini』](https://www.sevensix.co.jp/wp-content/uploads/ROMEmini-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
- [ご紹介資料：光配線切替ロボットROME](https://www.sevensix.co.jp/wp-content/uploads/ROMEseries.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ