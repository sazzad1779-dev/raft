# Source URL: https://www.sevensix.co.jp/products/lma_sm_nktp/

# 
# ラージモードエリアフォトニック結晶ファイバ /SMF
波長: 400 ~ 1700nm　SMF
_メーカ：_ NKT Photonics A/S
- 光ファイバ素線 / 光ファイバパッチコード
- SMファイバ
- フォトニック結晶ファイバ
最大400~1700 nmの広帯域の光をシングルモードで、かつ低ロスで伝搬が可能な唯一のファイバ（フォトニック結晶ファイバ）です。
製品のお問い合わせ･お見積
## 特長
- シングルモード伝送
- 高出力＆高パルスエネルギー対応
- 低非線形性
- 5~25umコア径と幅広い製品ラインナップ
## 仕様詳細
## 資料ダウンロード
- [データシート：LMAファイバ (SMF)](https://www.sevensix.co.jp/wp-content/uploads/LMA-fibers.pdf#view=Fit)
- [データシート：LMAファイバ (PMF)](https://www.sevensix.co.jp/wp-content/uploads/LMA-PM-fibers.pdf#view=Fit)
- [データシート：LMAファイバ (PM-1550)](https://www.sevensix.co.jp/wp-content/uploads/PM-1550.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ