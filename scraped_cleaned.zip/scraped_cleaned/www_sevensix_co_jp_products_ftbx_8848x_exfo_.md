# Source URL: https://www.sevensix.co.jp/products/ftbx-8848x_exfo/

# 
# 小型多ポート400GbEネットワークテスター 『FTBx-8848x』シリーズ
SFP112 / QSFP112 対応
_メーカ：_ EXFO
- 光計測器
- その他
小型多ポート構成可能で、112G Electrical laneにも対応した
400GbEネットワークテスターです。
製品のお問い合わせ･お見積
## 特長
- 既存のFTBx-88460シリーズに比べて小型化、多ポート化(400GbE×2～4)を実現
- 次世代オプティクスで採用予定の112G electrical(SFP112/QSFP112)をサポート
- DCOはQSFP-DD及びOSFP の400G ZR及びOpenZR+をサポート ※CFP2-DCOは非サポート
- TA(ターミナルアダプタ)はTA-QSFP28、TA-SFP28、及びTA-CFP4をサポート
- ラックマウントシャーシであるLTB-8(3Uサイズ)には最大4モジュール=400GbE×8ポートまで実装可能
- コンパクトなFTB-1 HPDCシャーシに実装可能
- ポート構成の異なる3種類のモデル
FTBx-88480：QSFP-DD×2 ＋ SFP-DD×1 + TA×1
FTBx-88481：QSFP-DD×1 + OSFP×1 + TA×1 ※CY2023/2Qリリース予定
FTBx-88482：QSFP-DD×3 ＋ OSFP×1 + SFP-DD×1 + TA×2 ※CY2023/2Qリリース予定
※ソフトウェアオプションはモジュール単位で購入、全ポートに適用可能(one module one option)
## 用途
- EtherBERT,EtherSAM,TGen,RFC2544 and Smart loopback
@400GbE,200GbE,100GbE等の各種ネットワーク試験
- Dual Port での400G/200G/100G Ethernet Layer 2試験
## 仕様詳細
メーカリンク　＞＞＞ FTBx-88480
|     |     |
| --- | --- |
| メカニカル仕様 |  |
| サイズ | 51 mm x 159 mm x 187 mm ( 2 in x 6 1/4 in x 7 3/8 in) |
| 重さ | 0.85 kg (1.87 lb) |
| 温度<br>\*動作<br>\*保管 | 0 °C to 40 °C (32 °F to 104 °F)<br>-40 °C to 70 °C (-40 °F to 158 °F) |
|     |     |
| --- | --- |
| REF-OUT インタフェース |  |
| Tx pulse amplitude | 200 mVpp to 1300 mVpp, depending on frequency |
| Transmission frequency | 155 MHz to 3.50 GHz |
| Output configuration | AC-coupled |
| Load impedance | 50 Ω |
| Connector type | SMA |
| External cable | Maximum 1 meter cable length (RG178 cable with 3.1 dB/m attenuation at 3.5 GHz) |
### ＜使用イメージ＞
## 解説・関連動画
世界初のポータブル式800Gテスター│Vol.82
生成AIクラウド構築に潜む罠 【MPOコネクター編】│Vol.139
生成AIクラウドやデータセンターの高帯域ネットワークでは、MPOコネクタの需要が急増しています。 しかし品質管理が不十分なMPOコネクタを使用すると、反射減衰量不足やリンクダウンといった深刻なトラブルを招く可能性があります。
解決策④ BERT・光トランシーバ検査
業界で唯一、可搬型でQSFP112/OSFP112のテストに対応したネットワークテスターで、光トランシーバの動作チェック機能もサポートしています。400G QSFP112/OSFP56/QSFP-DD, 800G QSFP112-DD/OSFP112をサポートしています。光トランシーバの動作チェック機能であるiOpticsが付いています。
## 資料ダウンロード
- [スペックシート：『FTBx-8848x』シリーズ](https://www.sevensix.co.jp/wp-content/uploads/%E5%B0%8F%E5%9E%8B%E5%A4%9A%E3%83%9D%E3%83%BC%E3%83%88400GbE.pdf#view=Fit)
- [パンフレット：『FTBx-8848x』シリーズ](https://www.sevensix.co.jp/wp-content/uploads/EXFO_ftbx-88480_-JP.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 800GbEネットワークテスター『FTBx-888xx』シリーズ - 800GbE対応EXFO光計測器
- イーサネットテスター『FTBx-88460』 - 400G / 200G / 100Gbps イーサネットEXFO光計測器
- 光コンポーネントテスタ『CTP10』 - IL / RL / PDL 測定評価用EXFO光計測器
- ビットエラーレートテスター(BERT)『BA-4000』 - 400G / 800GEXFO光計測器