# Source URL: https://www.sevensix.co.jp/products/pbc_s_optizone/

# 
# 偏光ビームコンバイナ/スプリッタ
波長: 1064 ~ 2000nm　ポート数: 1×2 / 2×2
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- 偏波ビームコンバイナ/スプリッタ
- 光コンバイナ/スプリッタ
中国の深センに拠点を構えるOptizone Technologiesの偏光ビームコンバイナ/スプリッタです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- 高消光比
- 高リターンロス
#### **用途**
- EDFA&ラマン分光
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可 |
| ポート数 | 1×2、2×2 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：1064nm 1x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-007D-PBCS-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 2x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-006C-PBCS-1064nm-2x2-1.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-009D-PBCS-1310nm1550nm-1x2-2.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 Polarization Beam Combiner/Splitter (High Extinction Ratio)](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-049B-High-ER-PBCS-1310nm1550nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-052C-HPBCS-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-053C-HPBCS-1310nm1550nm-1x2-1.pdf#view=Fit)
- [データシート：2000nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-055C-HPBS-20.pdf#view=Fit)
- [データシート：1064nm 1x2 High Power Polarization Beam Combiner/Splitter (Ultra-Fast Fiber Lasers)](https://www.sevensix.co.jp/wp-content/uploads/CAT-11-004B-HPBCS-1064nm-1x2-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ