# Source URL: https://www.sevensix.co.jp/products/mux_demux_3coptics/

# 
# MUX/DEMUX (光合分波器)
波長: 1529.55 ~ 1560.61nm
_メーカ：_ 3Coptics
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- MUX/DEMUX
- 光フィルタ
DWDM C-band光波長多重伝送用の合分波フィルタモジュールです。ガウシアンタイプのAAWG素子を採用しており、
低損失(<3.2dB)、高アイソレーション(隣接CH >30dB)、高信頼性の伝送路構築を可能にします。
1Uラックマウント型でライン側のファイバ1芯で最大16CHまで収容可能です。
その他のチャンネル構成(8CH/16CH/32CH/40CH/48CH)、波長のカスタマイズも柔軟に対応しております。
製品のお問い合わせ･お見積)
## 特長
- AAWG(Athermal Array Waveguide Grating)を合分波素子として採用
- ガウシアンタイプの透過スペクトル形状により低損失(<3.2dB)、高アイソレーション(隣接CH ＞30dB)、
小型・高密度実装を実現
## 用途
- DWDM C-band光波長多重伝送用
- DWDMシステム
- PONネットワーク
- CATVリンク
- 光ファイバーアンプ
- 波長ルーティング
## 仕様詳細
■ **DWDM C-band 16CH (ライン側1芯)**
|     |     |
| --- | --- |
| 型番 | 3C-DWDM-16CH-1U |
| チャンネル構成 | 16CH (C21-C36 / C45-C60) |
| ライン側芯数 | 1芯 |
| 動作波長範囲 | 1529.55 nm ~ 1560.61 nm |
| 光コネクタタイプ | LC / UPC |
| 中心波長 | ITU, C-band |
| 対応光ファイバ | SMF |
| チャンネル間隔 | 100 GHz　0.8 nm |
| パッケージタイプ | 1Uラックマウント |
| 挿入損失 | ＜ 3.2dB |
| ベンダ名 | 3Coptics |
| アイソレーション | 隣接CH：≧ 30dB |
| 動作温度範囲 | -20 ~ 75 ℃ |
## 資料ダウンロード
- [データシート：MUX/DEMUX(光合分波器)](https://www.sevensix.co.jp/wp-content/uploads/3Coptics%E3%80%80MAXdeMAX-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ)