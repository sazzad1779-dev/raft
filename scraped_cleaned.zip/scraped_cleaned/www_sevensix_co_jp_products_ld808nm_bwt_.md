# Source URL: https://www.sevensix.co.jp/products/ld808nm_bwt/

# 
# ファイバ付 高出力 半導体マルチモードレーザー
波長: 808nm　出力: 4 ~ 150W
_メーカ：_ BWT Beijing LTD.
- 半導体レーザーダイオード（LD）
- ポンプLD
- MMファイバ
- ファブリペローレーザー
✓ シングルエミッター、マルチエミッター、バンドルファイバモジュールから選択可能
✓ 設計に合わせたパッケージやカスタムが可能
✓ 電源付きのシステムでもご提案が可能
製品のお問い合わせ･お見積
## 特長
- コンパクトなパッケージデザインのファイバ付半導体レーザ
- 広範囲なパワーレンジ
## 用途
- ファイバーレーザー構築
- レーザ加工
- 医療（OCT以外）
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| 製品名 | 型式 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| 808nm 4W Multi-Function <br>Detachable Diode Laser | [K808F11CA-4.000W]( | 808 | 4 | 200 | 0.22 | 医療 |
| 808nm 4W Fiber Coupled <br>Diode Laser | [K808DB2RN-4.000W]( | 808 | 4 | 105 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 8W Multi-Function <br>Detachable Diode Laser | [K808F14CC-8.000W]( | 808 | 8 | 400 | 0.22 | 医療 |
| 808nm 8W Fiber Coupled Diode Laser | [K808DB2RN-8.000W]( | 808 | 8 | 105 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 25W Fiber Coupled Diode Laser | [K808DAHRN-25.00W]( | 808 | 25 | 400 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 30W Fiber Coupled <br>Diode Laser | [K808DAERN-30.00W]( | 808 | 30 | 200 / 400 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 40W Fiber Coupled<br>Diode Laser | [K808DA5RN-40.00W]( | 808 | 40 | 105 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 50W Fiber Coupled<br>Diode Laser | [K808DA5RN-50.00W]( | 808 | 50 | 200 / 400 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 60W Fiber Coupled<br>Diode Laser | [K808DA5RN-60.00W]( | 808 | 60 | 105 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 70W Fiber Coupled Diode Laser | [K808DA5RN-70.00W]( | 808 | 70 | 105 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
| 808nm 150W Fiber Coupled<br>Diode Laser | [K808DL9RN-150.0W]( | 808 | 150 | 200 / 400 | 0.22 | 固体レーザー増幅、医療、<br>材料加工 |
## 製品に関するお問い合わせ
この製品のお問い合わせ