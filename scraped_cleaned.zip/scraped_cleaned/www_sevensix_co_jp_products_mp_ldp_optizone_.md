# Source URL: https://www.sevensix.co.jp/products/mp_ldp_optizone/

# 
# マルチモードポンプLDプロテクタ
波長: 915 / 980nm　入力パワー: 6W / 10W
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- ポンプLDプロテクタ
- その他光ファイバ部品
中国の深センに拠点を構えるOptizone TechnologiesのマルチモードポンプLDプロテクタです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- レーザ保護
## 用途
- ファイバレーザ
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 915nm、980nm、その他も対応可 |
| 入力パワー | 6W、10W、その他も対応可 |
| NA | 0.15、0.22、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、3mmケーブル、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：915nm、980nm Multimode Pump Laser Protector](https://www.sevensix.co.jp/wp-content/uploads/CAT-08-004C.pdf#view=Fit)
- [データシート：915nm、980nm Multimode Pump Laser Protector for EDFA](https://www.sevensix.co.jp/wp-content/uploads/MMPLPE-915nm980nm-15001620nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ