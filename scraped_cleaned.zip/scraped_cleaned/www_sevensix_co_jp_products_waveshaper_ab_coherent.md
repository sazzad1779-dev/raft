# Source URL: https://www.sevensix.co.jp/products/waveshaper_ab_coherent/

# 
# 通信帯域 スペクトル・分散制御プロセッサ WaveShaper A/Bシリーズ
O / S / C / L / U-band対応
_メーカ：_ Coherent (旧 II-VI)
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光任意波形成形器(Wave Shaper)
- 光フィルタ
O / S / C / L / U 帯の光スペクトルの強度と位相、群遅延を、独立に高い自由度で制御できる光フィルタです。
LCoS(Liquid crystal on silicon)をベースに構成されているため、可動部がなく安定で堅牢です。
1 x 31, 4 x 28, 8 x 24. 12 x 20, 16 x 16 など、様々な組み合わせが可能なマルチポートにも対応しています。
さらに、弊社ではWaveShaperのポテンシャルを最大限に引き出す
当社オリジナル・ソフトウェアのサポートをご提供しております。
製品のお問い合わせ･お見積
## 特長
- 業界オンリーワンの任意波形整形機能 (フィルタ帯域幅10GHzから同時に複数の任意形状フィルタ設定可能)
- アッテネーション(レンジ 0~40 dB)と位相を独立に制御可能
- 動作周波数帯域別に幅広いラインナップ (O-band, S-band、C-band、L-band、C+L-band、拡張L-band、U-band, 1μm)
- 高解像度LCoS(Liquid Crystal on Silicon)技術で構成、可動部が無く安定で堅牢
- 多ポート構成にも対応 (1 x 31, 4 x 28, 8 x 24. 12 x 20, 16 x 16)
- Ethernet接続による遠隔制御にも対応
### Bシリーズの機能追加ついて
高速フィルタ更新レートのサポート
・最大10Hzのフィルタ更新レートを実現（フィルタ設定による）
・高速スイッチングやフィルタの高速スキャニングが求められるアプリケーションに最適
例えば、異なるフィルタ形状の高速切替が求められるシステム試験や製造工程において、処理効率の向上が可能
高分解能モードのサポート
・Double pass configurationによる高分解能モード：フィルタ帯域幅：8GHz（FWHM）＠Super C-band
※通常モードでは10GHz
### 動作原理
WaveShaperの任意波形整形機能は、回折格子とLCoSにより実現されています。入力光源は回折格子によって波長分解され、波長毎にLCoSの各ピクセルに照射されます。LCoSでステアリング(方向を制御されて反射)された光は出力ファイバに結合されます。光強度制御は光を出力ファイバへ入射するときの結合率を制御することでコントロールします。位相(群遅延)制御は、LCoSでステアリングされたビームパスを制御することで実現します。
## 用途
- 波長多重通信光のレベル等価制御、位相・分散制御、光スペクトル制御、光源生成
- 量子通信における単一光子信号周波数変換時の励起光パルス整形、周波数多重化による光子ペアの生成
- 短パルスレーザーの波長分散制御によるパルス圧縮、パルス形状制御
- 波長合分波(MUX/DEMUX)、De-/Interleaving
## アプリケーション事例
モードロックレーザー、光ファイバ増幅器と一緒に用いることで性能をフルに発揮できます。WaveShaperの性能をフルに発揮できる光源としては、① 光周波数コム光源『Frush』, ② 超短パルスファイバレーザー『iQoM』 がお勧めです。
### アプリケーション事例①：波長広帯域化とフェムト秒パルスの生成​
### アプリケーション事例②：超短パルス光の出力​
## 仕様詳細
※ WaveShaper『1000A/SP』の詳細ページはこちら
※下記リンクをクリックいただくと、データシートをご確認いただけます。
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| シリーズ名 | モデル番号 | ポート | 動作波長範囲 | フィルタ波形 |
| [WaveShaper Short-Pulse Shaping]( | WS-01000A/SP | 1×1 | 1μ,<br>C-band,<br>C+L band | 減衰と位相が任意 |
| [WaveShaper A-Series]( | WS-01000A/S,<br>WS-04000A/S Series | 1×1, 1×4 | S-band | 減衰と位相が任意 |
|  | WS-01000A/U, <br>WS-04000A/U Series | 1×1, 1×4 | U-band | 減衰と位相が任意 |
| [WaveShaper B-Series]( | WS 500B-Series | 1×1 | Super C-band,<br>Super L-band | 減衰が任意 |
|  | WS 1000B-Series | 1×1 | Super C-band,<br>Super L-band,<br>C+L-band, O-band | 減衰と位相が任意 |
|  | WS 4000B-Series | 1×4 | Super C-band,<br>Super L-band,<br>C+L-band, O-band | 減衰と位相が任意減衰と位相が任意 |
|  | WS 3200xB-Series | 1×31, 4×28, 8×24,<br>12×20, 16×16 | Super C-band,<br>Super C + Super L-band | 減衰と位相が任意 |
### 波長帯域別ラインナップ
## セブンシックスの技術サポート
導入前・導入後のご相談、承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyze のポテンシャルを最大限に引き出す当社 [オリジナル・ソフトウェア]( のサポート
- WaveShaper・WaveAnalyze の修理対応 (電源系、ファン、ファイバ端面等の交換・修理)
### 解説・関連動画📢
### Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
エクセルと一緒にご使用いただく Python ベースのソフトウェアを新たに開発しました！Matlabベースのソフトとの違いなど、詳細ついては下記動画をご視聴ください。
▼ 『WaveShaper』セブンシックス製ソフト①～③ 任意スペクトル・パルス生成 │ Vol.010～012 (Matlabベース)
複雑なフィルタ形状を簡単に設定
目的のスペクトル形状を生成する
光パルスを最短パルス化させる
▼ WaveShaper/光任意波形整形器：これ1台で自由自在？！ │Vol.008
▼ Coherent社 Super C-band WaveShaper/Analyzer新登場│Vol.77
### アプリケーション・ノート
- [Creating Simple Filter Shapes in Excel, Labview and Matlab](
- [Double Pulse Generation in pSec and fSec Lasers](
- [Group Delay Ripple Compensation](
- [Automated Gain Flattening in an Optical Amplifier](
- [Short Pulse Shaping](
- [Pulse Burst Generation](
- [Filter Bandwidth Definition](
- [Dispersion Trimming](
## 資料ダウンロード
- [カタログ：WaveShaper Aシリーズ](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-a-series-family-br.pdf#view=Fit)
- [カタログ：WaveShaper Bシリーズ](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-b-series-family-br.pdf#view=Fit)
- [ユーザマニュアル：WaveShaper](https://www.sevensix.co.jp/wp-content/uploads/WaveShaper-Help-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 1 μｍ 超短パルスファイバレーザー用 時間・スペクトルプロセッサ WaveShaper『1000A/SP』 - 1 μｍ, C-Band, C+L-BandCoherent (旧 II-VI)光増幅器/ 光変調器/ PD/ 光フィルタ他
- C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』 - 帯域幅：1527.8 ~ 1610.05nmCoherent (旧 II-VI)光計測器
- ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』 - Super C-band帯 (1523.9 ~ 1572.7nm)対応Coherent (旧 II-VI)光計測器
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバーCoherent (旧 II-VI)光計測器