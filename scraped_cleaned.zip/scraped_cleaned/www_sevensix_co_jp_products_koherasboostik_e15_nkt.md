# Source URL: https://www.sevensix.co.jp/products/koherasboostik_e15_nktp/

# 
# 狭線幅レーザー『Koheras』用 光増幅モジュール『Koheras Boostik』
波長: 1545 ~1565nm 出力: 2W
_メーカ：_ NKT Photonics A/S
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光増幅器
- 光ファイバアンプ
NKT Photonics社の低出力の単一周波数の超低雑音＆狭線幅レーザであるKoheras BASIK用のコンパクトサイズの光増幅器となります。対応波長は1.5um帯の1545 - 1565 nmで、出力は2 Wとなります。マルチチャンネルシステムである Koheras ACOUSTIKへの搭載も可能です。
製品のお問い合わせ･お見積
NKT Photonics社の Koheras BASIK や BASIK MIKRO のシードレーザを2Wまで増幅可能な光増幅器モジュールとなります。
**特長**
- 強度・位相雑音と線幅を維持したままの増幅が可能
- 産業向けOEMパッケージ
- マルチチャンネルシステム向け設計 ( ACOUSTIK )
- メンテナンスフリー
- PM出力（non-PM出力は要相談）
- Koheras BASIKの強度雑音を20 dBほど下げるオプションもあり
**Koheras Boostik 仕様**
### Koheras ACOUSTIK マルチチャンネルプラットフォーム
Koheras ACOUSTIK は Koheras BASIK 単一周波数低ノイズファイバレーザ と Koheras BOOSTIK 光増幅器を搭載可能な電源込のラックシステムです。ACOUSTIK は、搭載中の Koheras BASIK やKoheras BOOSTIK に電源を与え、それぞれを制御します。 BASIK とBOOSTIK は簡単に ACOUSTIK に出し入れすることができます（ 上図は FC/APC コネクタ、モニタ出力なしの Koheras BASIK モジュール を 8台格納した Koheras ACOUSTIK ）。
Koheras ACOUSTIK は堅牢性が求められる産業用途に対応するためパッシブ冷却システムデザインとなっています。マルチチャンネルのセンサシステム用に設計されており、標準的な 3U 19インチラック筐体には、制御エレクトロニクスと電源が含まれています。各 BASIKやBOOSTIKレーザモジュールには、ACOUSTIK のフロントパネルから直接アクセスできます。Koheras ACOUSTIK と搭載したBASIKとBOOSTIKモジュールは NKT Photonicsが無償配布している CONTROL ソフトウェア を用いて制御することができます。
## 資料ダウンロード
- [『Koheras BOOSTIK 』データシート](https://www.sevensix.co.jp/wp-content/uploads/Koheras_BOOSTIK.pdf#view=Fit)
- [『Koheras ACOUSTIK』データシート](https://www.sevensix.co.jp/wp-content/uploads/Koheras_ACOUSTIK-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ