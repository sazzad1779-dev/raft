# Source URL: https://www.sevensix.co.jp/products/pulseldd_trimatiz/

# 
# 短パルス駆動 LDドライバ
パルス幅: 2 ~ 50ns　繰返し周波数: 5k ~ 1MHz　電流値: 8 ~ 150A
_メーカ：_ 株式会社トリマティス
- 半導体レーザーダイオード（LD）
- LDコントローラ/ ドライバ
「大電流」と「短パルス」のそれぞれの良さを活かしたLDドライバです。LiDAR光源の他、各種センシング途や産業用に適した小型のパルスドライバボードとなっています。
製品のお問い合わせ･お見積
#### **特長**
- 繰り返し周波数: 5k～1MHz
- 対応LD: CANパッケージ(様々な帯域、ピンアサインに対応)
- 基板サイズ: 60×60mm
※対象製品には半導体レーザは含まれません。
#### **用途**
- LiDARパルス光源
- 各種分析計測機器
#### **仕様詳細**
■　**オーダーインフォメーション**
## 資料ダウンロード
- [短パルス駆動 LDドライバ『LDD-PU-xxx』2ns～50ns カタログ](https://www.sevensix.co.jp/wp-content/uploads/2-50ns-LD%E3%83%89%E3%83%A9%E3%82%A4%E3%83%90.pdf#view=Fit)
- [12 ns, 70A 短パルス駆動 LDドライバ『LDD-PU-100』カタログ](https://www.sevensix.co.jp/wp-content/uploads/70A-LD%E3%83%89%E3%83%A9%E3%82%A4%E3%83%90.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ