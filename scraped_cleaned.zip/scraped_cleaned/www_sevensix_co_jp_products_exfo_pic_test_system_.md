# Source URL: https://www.sevensix.co.jp/products/exfo_pic-test-system/

# 
# PIC(光集積回路)テストソリューション
測定したい光集積回路をカスタマイズ
_メーカ：_ EXFO
- 光計測器
- その他
パッシブおよびアクティブコンポーネントテストやBERテスターなど幅広いPICテスト環境をご提供いたします。
製品のお問い合わせ･お見積%E3%83%86%E3%82%B9%E3%83%88%E3%82%BD%E3%83%AA%E3%83%A5%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3)
お客様のご要望に応じて、測定したい光集積回路 (PIC：Photonic Integrated Circuit) 毎に最適な構成を都度カスタマイズしてご利用いただけます。
## 特長
- パッシブ部品、アクティブ部品、量子フォトニクスチップ（ダイ）、AWG、トランシーバー（伝送、BER）
など幅広い光集積回路を、ウェハーレベル、ダイレベル、コンポーネントレベルでのテスト環境を提供
- 自動化ソフトウェア、プローブシステムから光学/電気/パフォーマンス測定系までワンストップでご提供
## 用途
- 光集積回路(PIC)の特性テスト(IL、RL、PDL)
- スペクトル分析(波長、光パワー、OSNR等)
- 機能テスト(BERT、アイダイアグラム測定等)
## 製品仕様
パッシブおよびアクティブコンポーネントテストやBERテスターなど幅広いPICテスト環境をご提供いたします。
＜代表的なPICテストシステムセットアップ＞
## 資料ダウンロード
- [カタログ＜英語版＞：EXFO-PIC-Test-Solutions\_EN](https://www.sevensix.co.jp/wp-content/uploads/EXFO-PIC-Test-Solutions.pdf#view=Fit)
- [カタログ＜日本語版＞：EXFO-PIC-Test-Solutions\_JP](https://www.sevensix.co.jp/wp-content/uploads/EXFO-_pic-testingsolutions-JP-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%E3%83%86%E3%82%B9%E3%83%88%E3%82%BD%E3%83%AA%E3%83%A5%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3)
%E3%83%86%E3%82%B9%E3%83%88%E3%82%BD%E3%83%AA%E3%83%A5%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3)
## 関連製品
(1/2)
- 狭線幅 波長可変レーザ『T200S』 - >90dBワイドダイナミックレンジEXFOファイバーレーザー・その他光源
- 波長可変レーザー『T500S』 - O/E/S/C/L/U-bandをフルサポートEXFOファイバーレーザー・その他光源
- ビットエラーレートテスター(BERT)『BA-4000』 - 400G / 800GEXFO光計測器
- 超高速サンプリング・オシロスコープ『EA-4000』 - 波長: 830 ~ 1600nm　帯域幅: 33GHzEXFO光計測器
- クロックデータリカバリ(CDR)『CD-4000』 - 56GBd / 28GBdEXFO光計測器