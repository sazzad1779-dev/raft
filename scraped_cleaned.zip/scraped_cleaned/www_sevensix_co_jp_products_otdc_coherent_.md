# Source URL: https://www.sevensix.co.jp/products/otdc_coherent/

# 
# 400G CFP2-DCO デジタルコヒレント 光トランシーバ
波長: C-band full tunable
_メーカ：_ Coherent (旧 II-VI)
- 光通信/ 同軸・RF関連
- 光トランシーバ
超長距離大容量伝送用のCFP2-DCO光トランシーバモジュールです。C-band full tunable 400Gでの1,000km伝送をサポート致します。
製品のお問い合わせ･お見積
## 特長
- デジタルコヒーレント光学モジュール、CFP2フォームファクター
- マルチレートIEEEイーサネットまたはITU-T OTN/FlexO準拠のホストインターフェイス
- 400Gで最大1000kmの伝送距離、200G（2000km）、100G（5000km）で伝送距離の延長が可能
- レイヤ1暗号化（AES-256）機能搭載
- フルCバンドチューナブル、フレキシブルグリッド対応（オプション）
- 送信出力電力 0dBm
- ケース温度範囲 0℃～70℃
- 許容損失＜26W
## 用途
- データセンター
- 基幹系インフラ
- 通信
- メトロ/ロングホール伝送
- データセンター・インターコネクト
## 仕様詳細
## 解説・関連動画
『 II-VI（FINISAR）社製 光トランシーバ』 400G/800G新製品紹介│Vol.13
『 II-VI（FINISAR）社製 光トランシーバ』400G/800G新製品紹介│Vol.13 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
『 II-VI（FINISAR）社製 光トランシーバ』400G/800G新製品紹介│Vol.13
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 9:29
•Live
•
## 製品に関するお問い合わせ
この製品のお問い合わせ