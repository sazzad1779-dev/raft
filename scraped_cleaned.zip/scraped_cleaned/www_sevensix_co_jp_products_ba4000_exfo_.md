# Source URL: https://www.sevensix.co.jp/products/ba4000_exfo/

# 
# ビットエラーレートテスター(BERT)『BA-4000』
400G / 800G
_メーカ：_ EXFO
- 光計測器
- BERT
- BERT
800GbE/400GbE等のPAM4変調方式を用いた高速伝送規格の対応デバイス（光トランシーバ・OSA・FPGA等）の試験・評価に最適な、ビットエラーレートテスターです。
製品のお問い合わせ･お見積%E3%80%8EBA-4000%E3%80%8F)
## 特長
- 800G/400G/200G/100Gの伝送規格向けテストをフルサポート (～56GBd, NRZ/PAM4, ～8チャネル)
- バーストエラー分析に必須のFECシミュレーション機能
- 生成信号の高品質なアイパターン
- RFインターフェースに着脱容易なO-SMPMコネクタ採用
- PRBS 7/9/11/13/15/23/31/13Q/31Q, SSPRQをサポート
## 用途
- 光トランシーバ、OSA(Optical Sub Assembly)の試験、評価
- FPGA、MCB(Module Compliance Board)、HCB(Host Compliance Board)の試験、評価
## 仕様詳細
### ■ FECシミュレーション機能
400GbE/800GbE等のPAM4変調を適用した高速伝送規格では、伝送品質を確保するためにFEC(前方誤り訂正)を使用することが定められており、伝送品質評価においても、FECによるエラー訂正を含めた評価が必要になります。BA-4000のFECシミュレーション機能は、バーストエラーに対する様々な分析機能を提供します。
〇 PRBSエラーチェック及び訂正
〇 Pre-FEC及びpost-FEC BER
〇 KP4/KR4及び低遅延FECプロトコル
〇 FEC lane striping 昨日
〇 FECシンボルエラー分布表示 : codewords vs. シンボルエラー
〇 FECマージン自動計算
### ■ O-SMPMコネクタ
測定系構築時の着脱操作が容易に可能、各種高周波コネクタ(K, 2.4mm, SMPM, 1.85mm)に対応したケーブルもサポートしております。
### ■ 高品質なアイパターン
53GBd PAM4の生成信号においてアイ幅 > 6psと、高品質なアイパターンの生成が可能です。
### ■ 使いやすいGUI
ユーザーフレンドリーなGUI設計です。詳しくは参考動画①の1分22秒以降もご参照ください。
### ■ 参考動画①: 特徴のご紹介
### ■ 参考動画②: FECシミュレーション機能のご紹介
## 資料ダウンロード
- [スペックシート：ビットエラーレートテスター(BERT) – 『BA-4000』](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_ba-4000_v7_ja.pdf#view=Fit)
- [パンフレット：光トランシーバテスト製品ラインナップ \- 最大800G伝送速度](https://www.sevensix.co.jp/wp-content/uploads/c0e90febf49b7bdbef1693a146c5fa68-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%E3%80%8EBA-4000%E3%80%8F)
%E3%80%8EBA-4000%E3%80%8F)