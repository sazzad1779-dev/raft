# Source URL: https://www.sevensix.co.jp/products/qsfp_ot_coherent/

# 
# 400GbE/100GbE QSFP 光トランシーバ
400G/100Gbps
_メーカ：_ Coherent (旧 II-VI)
- 光通信/ 同軸・RF関連
- 光トランシーバ
最新の400G/100Gbpsイーサネット通信規格(IEEE802.3bs, IEEE802.3ba)に対応した光トランシーバです。
製品のお問い合わせ･お見積
## 用途
- データセンター
- 光アクセス
- 基幹系インフラ
- 通信
## 仕様詳細
■ [400GbE-FR4 QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD4313E1PCL |
| 対応プロトコル | 400GBASE-FR4 |
| 伝送レート | 4 x 100Gbps PAM4 |
| 伝送距離 | 2km |
| 光コネクタ／対応ファイバ | LC／SMF |
| LD種類・構成・波長 | CWDM LD x 4 |
■ [400GbE-DR4+ QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD4533E2PxM |
| 対応プロトコル | 400GBASE-DR4+ |
| 伝送レート | 4 x 100Gbps PAM4 |
| 伝送距離 | 2km |
| 光コネクタ／対応ファイバ | MPO／SMF |
| LD種類・構成・波長 | 1310nm LD x 4 |
■ [400GbE-DR4 QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD4523E2PxM |
| 対応プロトコル | 400GBASE-DR4 |
| 伝送レート | 400Gbps(4 x 100Gbps) |
| 伝送距離 | 500m |
| 光コネクタ／対応ファイバ | MPO／SMF |
| LD種類・構成・波長 | 1310nm LD x 4 |
■ [100GbE-FR QSFP28](
■ [100GbE-DR QSFP28](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTLC4351RJPL |
| 対応プロトコル | 100GBASE-FR |
| 伝送レート | 100Gbps PAM4 |
| 伝送距離 | 2km |
| 光コネクタ／対応ファイバ | LC／SMF |
| LD種類・構成・波長 | 1310nm LD |
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTLC4351RHPL |
| 対応プロトコル | 100GBASE-DR |
| 伝送レート | 100Gbps PAM4 |
| 伝送距離 | 500m |
| 光コネクタ／対応ファイバ | LC／SMF |
| LD種類・構成・波長 | 1310nm LD |
■ [400GbE-LR8 QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD1323E1PCL |
| 対応プロトコル | 400GBASE-LR8 |
| 伝送レート | 8 x 50Gbps PAM4 LAN-WDM DFB |
| 伝送距離 | 10km |
| 光コネクタ／対応ファイバ | LC／SMF |
| LD種類・構成・波長 | LAN-WDM DFB x 8 |
■ [400GbE-FR8 QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD1333E1PCL |
| 対応プロトコル | 400GBASE-FR8 |
| 伝送レート | 8 x 50Gbps PAM4 |
| 伝送距離 | 2km |
| 光コネクタ／対応ファイバ | LC／SMF |
| LD種類・構成・波長 | LAN-WDM DFB x 8 |
■ [400GbE-SR8 QSFP-DD](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FTCD8613E1PCM |
| 対応プロトコル | 400GBASE-SR8 |
| 伝送レート | 8 x 50Gbps PAM4 |
| 伝送距離 | 100m |
| 光コネクタ／対応ファイバ | MPO16／OM4 |
| LD種類・構成・波長 | 850nm VCSEL x 8 |
■ [400GbE AOC](
|     |     |
| --- | --- |
| ベンダ名 | Finisar |
| 型番 | FCBR850QE1Cxx |
| 対応プロトコル | N/A |
| 伝送レート | 400Gbps |
| 伝送距離 | 1m～70m |
| 光コネクタ／対応ファイバ | N/A／N/A |
| LD種類・構成・波長 | N/A |
### 解説・関連動画▼
『 II-VI（FINISAR）社製 光トランシーバ』400G/800G新製品紹介│Vol.13
## 資料ダウンロード
- [スペックシート：400G QSFP-DD Active Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-850-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-LR8 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-1323-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-FR8 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-1333-Specifications.pdf#view=Fit)
- [スペックシート：100GBASE-FR QSFP28 Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4351-Specifications.pdf#view=Fit)
- [スペックシート：100GBASE-DR QSFP28 Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4351R-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-DR4 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4523-Specifications.pdf#view=Fit)
- [スペックシート：400G-DR4+ QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4533-Specifications.pdf#view=Fit)
- [スペックシート：400G-FR4 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-8519-1-Specifications.pdf#view=Fit)
- [スペックシート：400G-SR8 QSFP-DD](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-8613-Specifications.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ