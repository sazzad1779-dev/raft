# Source URL: https://www.sevensix.co.jp/products/taperamplifier_eagleyard/

# 
# テーパーアンプ
波長: 650 ~ 980nm　出力: 0.25 ~ 3W
_メーカ：_ Toptica Eagleyard
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光増幅器
- テーパーアンプ
テーパーアンプは、1つのエミッターで優れたビームと最高の出力を兼ね備えています。モノリシックデザインで、シングルモードのリッジ導波管部分をテーパー構造にしています。マスターオシレーターのパワーアンプのセットアップに最適です。全ての製品は、ISO 9001:2015で要求される厳格な品質基準に準拠しています。
製品のお問い合わせ･お見積
## 特長
- 線幅が小さく、サイドモード抑制比（SMSR）が強いなど、種レーザーの良好なスペクトル特性を維持します。
- マスターオシレーターのパワーアンプのセットアップに最適で、シードソースの特性をすべて受け継いでいます。
- パッケージは、 C-Mount / 14 Pin Butterfly Package です。
## 用途
- 量子技術
- 分光法
## 仕様詳細
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| 製品名 | 波長 (nm)<br>\*(typ) | 出力 (W)<br>\*推奨環境 | モード | パッケージ |
| [EYP-TPA-0650-00250-2007-CMT02-0000]( | 650 | 0.25 | CW | C-Mount Package |
| [EYP-TPA-0765-01500-3006-CMT03-0000]( | 765 | 1.5 | CW | C-Mount Package |
| [EYP-TPA-0765-01500-3006-BTU02-0000]( | 765 | 1.5 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0780-01000-3006-CMT03-0000]( | 780 | 1.0 | CW | C-Mount Package |
| [EYP-TPA-0780-03000-4006-CMT04-0000]( | 780 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0780-03000-4006-BTU02-0000]( | 780 | 3.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0795-02000-4006-CMT04-0000]( | 795 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0795-02000-4006-BTU02-0000]( | 795 | 2.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0808-02000-4006-CMT04-0000]( | 808 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0830-01000-4006-CMT04-0000]( | 830 | 1.0 | CW | C-Mount Package |
| [EYP-TPA-0845-02000-4006-CMT04-0000]( | 845 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0850-00500-3006-CMT03-0000]( | 850 | 0.5 | CW | C-Mount Package |
| [EYP-TPA-0850-02000-4006-BTU02-0000]( | 850 | 2.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0850-02000-4006-CMT04-0000]( | 852 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0870-00500-3006-CMT03-0000]( | 880 | 0.5 | CW | C-Mount Package |
| [EYP-TPA-0960-02000-4006-CMT04-0000]( | 960 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0970-02500-4006-CMT04-0000]( | 970 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0980-00500-3006-CMT03-0000]( | 980 | 0.5 | CW | C-Mount Package |
## 製品に関するお問い合わせ
この製品のお問い合わせ