# Source URL: https://www.sevensix.co.jp/products/koherasseries_nktp/

# 
# 超低ノイズ 狭線幅ファイバレーザー ラインナップ『Koheras』シリーズ
波長: 1030 ~ 1120nm / 1535 ~ 1580nm / 766 ~ 780nm
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 狭線幅CWレーザー光源
『Koheras』シリーズはこれまで研究用途に使われていた高価な Hz レンジの線幅のレーザとは一線を画すレーザとなっております。Koheras シリーズは真のシングル縦モードDFBファイバレーザ（単一モード DFBベース　ファイバレーザ）構成を採用しているため、モードホップフリーで安定度が非常に優れています。
製品のお問い合わせ･お見積
### Koheras シリーズラインナップ
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| Model | C15 | E15 | X15 | Y10 |
| <br>BASIK (OEM) | 10 mW \*<br>@ 1535 ~ 1580 nm | 40 mW <br>@ 1535 ~ 1580 nm | 30 mW \*<br>@ 1535 ~ 1580 nm | 10 mW \*<br>@1030 ~ 1120 nm |
| <br>BASIK MIKRO (OEM) | – | 40 mW <br>@ 1530 ~ 1580 nm | – | – |
| <br>ADJUSTIK (Benchtop) | 10 mW \*<br>@ 1535 ~ 1580 nm | 40 mW <br>@ 1535 ~ 1580 nm | 22.5 mW <br>@ 1535 ~ 1580 nm | 10 mW \*<br>@ 1030 ~ 1120 nm |
| <br>ADJUSTIK HP (Benchtop) | 2 W / 0.2 W <br>@ 1545 ~ 1565 nm | 2 W <br>@ 1545 ~ 1565 nm | 0.2 W <br>@ 1545 ~ 1565 nm | 0.2 W <br>@ 1060 ~ 1075 nm |
| <br>BOOSTIK HP (Benchtop) |  | 5W / 10W / 15W<br>@ 1550 ~ 1570 nm |  | 5W / 10W / 15W <br>@ 1050 ~ 1090 nm |
| <br>HARMONIK (Benchtop) | \> 4 W @ λ/2, λ<br> \> 7 W @ λ/2, λ | \> 4 W @ λ/2, λ<br> \> 7 W @ λ/2, λ |  | \> 7 W @ λ/2, λ |
### OEM / Benchtop
筐体は OEM と Bentchtop タイプの 2 つに分類できます。OEM タイプはさらにマルチチャンネルプラットフォームに最適な筐体と、機能を制限して無駄を排した非常に小型な筐体に分かれます。ベンチトップタイプは、OEM タイプと同程度の出力を持つものと、光ファイバ増幅器と組み合わせることで高出力を達成しているものに分けられます。
###### C15, E15, X15, Y10 の違い
**C15**: C15 は波長 1535 – 1580 nm の範囲で動作するEr/Yb添加ファイバレーザです。Koheras シリーズの中で最も RIN レベルが低いモデルとなっており、業界で最も低RINレベルのレーザです。C15 を用いた場合はショット雑音限界のシステムを構築できます。
**E15/X15**: E15とX15 は波長1535 – 1580 nm の範囲で動作するエルビウム添加ファイバレーザです。Koheras シリーズで最も位相雑音と周波数雑音が低く、最も線幅が狭いレーザです。E15/X15は多くの場合、数10 km のコヒーレンス長や、非常に優れた周波数安定性が求められる干渉計ベースのセンサ用途に採用されます。X15 は特に波長安定性が優れており、1.5 um 帯の Koheras シリーズの最上位モデルとなっております。
**Y10**: Y10は波長 1030 – 1120 nm の範囲で動作するYb添加ファイバレーザです。線幅が低く、強度雑音が低いのが特徴です。Y10 はこれまでになかった狭線幅レーザとして安定化レーザ、原子物理、度量衡額、分光、核融合などの研究用途に採用されるだけでなく、従来のNd:YAGレーザの置き換えレーザとしても選ばれています。
各シード光源の波長安定性については、下記のホワイトペーパー内で詳しく説明されています。
>\> [Laser phase noise](
>> [Laser spectral linewidth(2013)](
>\> [Wavelength tuning of Koheras fiber lasers](
>> [Analysis of laser frequency stability using beat-note measurement(2013)](
### チューニング / PM出力
**PM出力**：Koheras ファイバレーザの出力ポートは通常はPM(偏波保持)ファイバです。これにより、出力レーザの偏光方向はSlow軸のみとなります。PM出力オプションはレーザの出力を外部変調したい場合や、波長変換したい場合に必要とされます。 non-PMファイバでのご案内も可能な製品はございます 。
**温度による波長チューニング**：Koheras ファイバレーザシステムはデフォルトで波長の温度チューニングが可能となっています。指定した波長に発振波長を安定化させることができます。温度によるチューニングなので指定した発振波長が指定した波長になるまでに時間がかかります。
**高速波長チューニング**：高速波長チューニングオプションは、フリーランニングレーザ（レーザを非同期している場合）よりも高い波長安定性が求められる用途で必要とされています。高速波長チューニングオプションの用途の一つとして、Koheras ファイバレーザを分子外部の原子スペクトル線や干渉計との同期があります。
今試したい研究、開発にどのシード光源、どの筐体が適しているのかを判断するのはなかなか難しいと思います。必要な仕様、機能などをご教示いただければ、Koheras 専門の担当者より最適な製品をご案内させていただきます。また、弊社にデモ機、デモ用の測定器もございます。デモのご興味をお持ちいただけましたら、いつでもお気軽にご相談ください。
NKT Photonics のウェブサイトでは、Koheras シリーズを用いた研究の論文データベースが公開されています。Barium、Beryllium、Magnesium、Rubidium、Strontium、Ytterbium、の 原子トラッピング、冷却 の事例や、分光、波長変換の事例は下記のリンク先からご覧いただけます。
NKT Photonics 公式ウェブ： ATOMIC TRAPPING AND COOLING
### Koheras BOOSTIK HP : Benchtop / OEM 高出力
Koheras BOOSTIK HP はメンテナンスフリーの単一周波数ファイバレーザです。 Koheras BOOSTIK HP のBenchtop タイプは、Koheras ADJUSTIK と Koheras 専用の EDFA / YDFAが組み合わさったモデルとなっております。
Koheras BOOSTIK は狭線幅、優れたビーム品質と高出力性を兼ね備えている唯一のレーザです。ターンキーシステムの 19インチラックシステムには、制御エレクトロニクス、電源が搭載されており、メトロロジーに代表されるようなラボ内での実験、研究用途に最適なレーザとなっております。ビーム品質が非常にすぐれているので、周波数変換（高調波発生）において高い変換効率を実現できます。詳細は Koheras HARMONIK シリーズ をご参照くださいませ。
※カスタムとしてC15タイプ、X15タイプでのご案内も可能です。
## 資料ダウンロード
- [アプリケーションノート：Koherasレーザの位相ノイズについて](https://www.sevensix.co.jp/wp-content/uploads/laser-phase-noise-application-note-version-1-0-october-2013.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの線幅について](https://www.sevensix.co.jp/wp-content/uploads/linewidth-application-note-version-1-1-october-2013.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの波長チューニングについて](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの周波数安定性について](https://www.sevensix.co.jp/wp-content/uploads/frequency-stability-application-note-version-1-1-.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ