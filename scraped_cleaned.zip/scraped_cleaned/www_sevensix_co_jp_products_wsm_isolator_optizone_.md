# Source URL: https://www.sevensix.co.jp/products/wsm_isolator_optizone/

# 
# 広帯域シングルモードアイソレータ
波長: 850 ~ 1064nm　入力パワー: 300mW ~ 5W
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- SMアイソレータ
- 光ファイバアイソレータ
中国の深センに拠点を構えるOptizone Technologiesの広帯域シングルモードアイソレータです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- 高アイソレーション
#### **用途**
- 光ファイバ増幅器
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 850m、1064nm、その他も対応可 |
| 入力パワー | 300mW、500mW、1W、5W、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
#### パッケージタイプ
Type C40
 Type C8
## 資料ダウンロード
- [データシート：850nm Broadband Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-022C-BI-850nm.pdf#view=Fit)
- [データシート：1064nm Broadband Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/BI-HPMBI-1064nm-Type-C8-1W20WCAT-05-020C.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ