# Source URL: https://www.sevensix.co.jp/products/nkt_tm_fiber/

# 
# Tm添加ダブルクラッドフォトニック結晶ファイバ
波長: 2um帯
_メーカ：_ NKT Photonics A/S
- 光ファイバ素線 / 光ファイバパッチコード
- PMファイバ
- PMファイバ
- 希土類添加ファイバ (Yb/ Er)
- フォトニック結晶ファイバ
高ピークパワーの超短パルスファイバレーザ増幅器用のTm添加ダブルクラッドファイバです。
モードフィールド径が38 um、励起クラッド径が250 umのTm添加ダブルクラッド PM フォトニック結晶ファイバです。
製品のお問い合わせ･お見積
## 特長
- 最大38 umのモードフィールド径
- 高ピークパワー＆高パルスエネルギー対応
## 用途
ファイバレーザ増幅器用
## 仕様詳細
|     |     |     |
| --- | --- | --- |
| Signal core |  |  |
|  | Mode properties | Single-mode |
|  | Mode-field diameter, 1/e2 @ 1930 nm \[µm\] | 38.0 ± 2.5 |
| Multi-mode pump core |  |  |
|  | Numerical aperture @ 800 nm | ≥ 0.5 |
|  | Pump absorption @ 1180 nm \[dB/m\] | 1.35 ± 0.30 |
|  | Pump absorption, typical @ 793 nm \[dB/m\] | ≈ 5.5 |
| Polarization parameters |  |  |
|  | Birefringence Δn @ 2 µm | ≥ 1 x 10-4 |
| Physical properties |  |  |
|  | Signal core diameter \[µm\] | ≈ 50 |
|  | Pump cladding diameter \[µm\] | 250 ± 5 |
|  | Outer cladding diameter \[µm\] | 560 ± 30 |
|  | Coating diameter \[µm\] | 640 ± 40 |
|  | Outer and pump cladding material | Pure silica |
|  | Coating material, single-layer | High-temperature acrylate |
## 資料ダウンロード
- [データシート：DC-250/50-PM-Tm](https://www.sevensix.co.jp/wp-content/uploads/DC250-50-PM-Tm-Datasheet.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ