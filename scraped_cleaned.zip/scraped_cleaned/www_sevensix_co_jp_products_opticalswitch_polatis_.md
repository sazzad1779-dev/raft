# Source URL: https://www.sevensix.co.jp/products/opticalswitch_polatis/

# 
# ピエゾアクチュエータ式マトリックス光スイッチ
波長: 1260 ~ 1675nm　ポート数: 最大 576x576
_メーカ：_ HUBER+SUHNER Polatis
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光スイッチ
ピエゾアクチュエータを採用してビームを直接出射側ファイバへ結合することで、損失を最小限に抑えて振動にも強い構造の光スイッチとなります。
8x8～576x576と様々なポート構成へ対応、またユーザー側で自由自在にポート構成の組み換えが可能なsingle-sided NxCC構成にも対応しております。
製品のお問い合わせ･お見積
## 特長
- 8×8 ～ 最大576×576のNon-blockingマトリックス光スイッチ
- ユーザー側で自由自在にポート構成の組み換えが可能なsingle-sided NxCCに対応
- 低挿入損失
- オプションで光パワーモニタリング、VOA、シャッター機能に対応
- NETCONF及びRESTCONFコントロールI/F対応
## 用途
- Software-defined networking　(ソフトウェアデファインドネットワーキング)
- Data center aggregation　(データセンターアグリゲーション)
- Automated access, metro and long-haul network operations　(自動アクセス、メトロおよび長距離ネットワーク運用)
- Centralized equipment sharing and automated network testing　(機器の一元共有とネットワークテストの自動化)
- Colocation peering and demarcation　(コロケーションピアリングとデマケーション)
- High performance computing　(ハイパフォーマンスコンピューティング)
- UHD Video distribution　(UHDビデオ配信)
- Automated systems verification testing　(自動システム検証試験)
- Fast automatic provisioning and protection switching　(高速な自動プロビジョニングと保護切り替え)
- Network monitoring and automatic fault location　(ネットワーク監視と自動障害位置特定)
## 製品ラインナップ
### ■　スイッチ構成例
### 解説・関連動画▼
ピエゾアクチュエータ式マトリックス光スイッチ│Vol.98
## 資料ダウンロード
- [データシート：Polatis\_576\_Prelim](https://www.sevensix.co.jp/wp-content/uploads/POLATIS_576_Data_Sheet_Prelim.pdf#view=Fit)
- [データシート：Polatis\_6000i\_Instrument](https://www.sevensix.co.jp/wp-content/uploads/Polatis_6000i_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_6000n\_Network](https://www.sevensix.co.jp/wp-content/uploads/Polatis_6000n_Network_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_7000i\_Instrument](https://www.sevensix.co.jp/wp-content/uploads/Polatis_7000i_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_7000n\_Network](https://www.sevensix.co.jp/wp-content/uploads/Polatis_7000n_Data_Sheet-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ