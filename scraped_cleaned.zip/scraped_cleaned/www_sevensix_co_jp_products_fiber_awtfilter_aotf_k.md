# Source URL: https://www.sevensix.co.jp/products/fiber_awtfilter_aotf_ksp/

# 
# ファイバ型音響光学波長可変フィルタ AOTF
波長: 1500 ~ 1600nm
_メーカ：_ KS Photonics Inc.
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 波長帯域幅可変光フィルタ
- 光フィルタ
全光ファイバを用いた音響光学チューナブルフィルタ（AOTF）は，高効率のノッチフィルタを実質的に光損失なしに実現するものです。単一モード光ファイバに進行性の音響波が引き起こす数百の周期的なマイクロベンドにより、シャープなノッチフィルタ（半値幅4nm）が生成されます。高周波信号の周波数と振幅を調整することで、フィルターの中心波長とノッチの深さを調整することができます。数モード光ファイバ（FMF）に使用することで、周波数シフタやモードコンバータとして動作させることができます。
製品のお問い合わせ･お見積
#### **特長**
- 高効率ノッチフィルタリング
- オールファイバデザイン
- 低損失
- 電気制御による中心波長/ノッチ深さ調整可能
#### **用途**
- ノッチフィルタ
- 周波数シフタ
- スペクトル整形
#### **仕様詳細**
AOTFが設置され、その後、利得平坦化フィルター、ノッチフィルター、モードロックファイバーレーザー、掃引レーザーなど多様な用途に使用されています。また、少数モードファイバ(FMF)で使用する場合は、周波数シフタや高次モードコンバータとして動作します。
ATOFには、ユーザーの実験目的に応じて2つのタイプがあります。1つはパッケージタイプ、もう1つは研究用のモジュールです。フィルター用途であればパッケージタイプがお勧めです。モジュールタイプでは、直径125mmの光ファイバをユーザー自身が装置に取り付けることができます。
モジュールタイプの場合、ガラスホーンの先端が非常に鋭く、破損しやすいので、ユーザーの慎重な判断が必要です。AOTF-A2は取り扱いに熟練を要するため、AOTFモジュールの使用経験があるエンドユーザーにお勧めします。
ALL-FIBER ACOUSTO-OPTIC TUNABLE FILTER - YouTube
Photo image of KS PHOTONICS
KS PHOTONICS
32 subscribers
ALL-FIBER ACOUSTO-OPTIC TUNABLE FILTER
KS PHOTONICS
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 1:10
•Live
•
## 資料ダウンロード
- [カタログ：ファイバ型音響光学波長可変フィルタ AOTF](https://www.sevensix.co.jp/wp-content/uploads/%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E5%9E%8B%E9%9F%B3%E9%9F%BF%E5%85%89%E5%AD%A6%E6%B3%A2%E9%95%B7%E5%8F%AF%E5%A4%89%E3%83%95%E3%82%A3%E3%83%AB%E3%82%BF%EF%BC%88AOTF%EF%BC%89%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ