# Source URL: https://www.sevensix.co.jp/products/hopmb_fi_hybrid_optizone/

# 
# 高出力 偏波保持 バンドパスフィルタ / アイソレータ ハイブリッド
波長: 1030 ~ 1064nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- PMアイソレータ
- 光ファイバアイソレータ
中国の深センに拠点を構えるOptizone Technologiesの高出力偏波保持バンドパスフィルタ/アイソレータハイブリッドです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 高消光比
- 低損失
- 高アイソレーション
#### **用途**
- 超短パルスレーザ
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 1030nm、1064nm、その他も対応可 |
| パスバンド幅 | 25nm、その他も対応可 |
| ストップバンド幅 | 35nm、その他も対応可 |
| 入力パワー | 3W、10W、20W、30W、その他も対応可 |
| 光軸アライメント | Fast Axis Blocked、Both Axis Working |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、3mmルーズチューブ、3mmアーマードケーブル、その他も対応可 |
| ファイバ長 | 標準2m、その他も対応可 |
## 資料ダウンロード
- [データシート：1030nm、1064nm High Power PM Band Pass Filter Isolator](https://www.sevensix.co.jp/wp-content/uploads/9121e812043b6af989796ddb00af95d7-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ