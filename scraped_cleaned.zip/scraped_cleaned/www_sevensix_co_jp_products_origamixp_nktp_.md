# Source URL: https://www.sevensix.co.jp/products/origamixp_nktp/

# 
# 最大70uJ フェムト秒レーザー『ORIGAMI XP(-S)』
波長：343nm / 515nm / 1030nm　平均出力：1.5W / 2.5W / 5W　パルスエネルギー：20uJ / 35uJ / 70uJ
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 超短パルスレーザー(ナノ秒/ピコ秒/フェムト秒)光源
『ORIGAMI XP』,『ORIGAMI XP-S』は、レーザーヘッド、コントローラ、冷却装置はワンボックスのコンパクトサイズに全て搭載され、最大70 uJのパルスエネルギーを空冷タイプにてご案内できるフェムト秒レーザーです。
製品のお問い合わせ･お見積%E3%80%8F)
## 製品概要
NKT Photonics社のORIGAMI XP, ORIGAMI XP-S シリーズはNKT Photonics社独自の超高安定で低位相雑音の Origami フェムト秒シードレーザー をシンプルでコンパクトなチャープパルス増幅器で増幅した構成となっております。
レーザーヘッド、コントローラ、冷却装置はワンボックスのコンパクトサイズ（292 mm x 176 mm x 508 mm）に全て搭載され、最大70 uJのパルスエネルギーを空冷タイプにてご案内できるフェムト秒レーザーとなります。
パルス幅 400 fs における最大平均出力は 5 W、最大パルスエネルギーは 70 uJです。繰返し周波数は single-shot から 1 MHz です。オプションとして、1030 nm, 515 nm, 343 nmの最大3波長出力のご案内も可能です。
## 特長
- ワンボックス搭載の超コンパクトサイズ
- \+ 24 Ddc入力が必要なだけの容易な操作性
- Single shot – 1MHz, Pulse-on demand
- SHG結晶、THG結晶を用いた最大3波長出力が可能
- 堅牢な産業向けの構造
- 全ての設置方向に柔軟に対応
- リアルタイムのパルスエネルギーの測定・診断・制御
- 高信頼性
- 高いビームポインティングスタビリティ : < 30 urad rms (12 h)
- 水冷オプションあり
## 用途
- 眼科用途
- 医療機器の製造
- フェムト秒微細加工
- 薄膜パターニング
- サファイア・ガラス・ポリイミドの切断と穴あけ
- セラミックの穴あけとスクライビング
- 多光子顕微鏡
- FPDピクセルの修復
- ホイル切断
- LCDパターニング
- OLEDディスプレイの修理
- PCB加工
- 光パラメトリック増幅器の励起光
## アプリケーションノート
- [Precision polymer cutting with femtosecond UV laser](
- [Micromachining of thermally sensitive PET film](
- [Femtosecond lasers ensure higher quality polyimide micromachining](
- [Laser micromachining of thin PMMA film](
- [Laser micromachining of thin glass](
- [Laser micromachining of Nitinol stents](
- [Laser micromachining of glass for biomedical applications](
- [Laser cutting of polymer tubes for biomedical applications](
- [Integration of an ORIGAMI XP with galvanometer scanners](
- [Laser marking of polymer tubes for biomedical applications](
- [Sub-surface marking of glass](
- [Unique device identification black marking for the medical industry](
## 仕様詳細
### ■　ORIGAMI 10XP / 10XP-S
### ■　ORIGAMI 5XP / 5XP-S　\*DUAL WAVELENGTH SHG タイプ
### ■　ORIGAMI 03XP / 03XP-S
### ■　ORIGAMI 03XP-3P　\*IR、Green、UV
## 資料ダウンロード
- [データシート：ORIGAMI XP-S (1030 nmのみ と 1030 & 515 nm)](https://www.sevensix.co.jp/wp-content/uploads/onefive-origami-10xp.pdf#view=Fit)
- [データシート：ORIGAMI XP-S (1030 & 343 nm)](https://www.sevensix.co.jp/wp-content/uploads/OneFive_ORIGAMI_03XP-2P.pdf#view=Fit)
- [データシート：ORIGAMI XP-S (1030 & 515 & 343 nm)](https://www.sevensix.co.jp/wp-content/uploads/OneFive_ORIGAMI_03XP-3P.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%E3%80%8F)
%E3%80%8F)