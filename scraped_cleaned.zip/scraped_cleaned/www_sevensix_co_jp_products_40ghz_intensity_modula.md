# Source URL: https://www.sevensix.co.jp/products/40ghz_intensity_modulator_hyperlight/

# 
# 薄膜LN 40GHz Ultra-low Vπ光強度変調器
C / L-band
_メーカ：_ HyperLight
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 強度変調器
- 光変調器
従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現する
薄膜LN方式の光変調器メーカ：Hyperlight社の40GHz Ultra-low Vπ 強度変調器です。
製品のお問い合わせ･お見積
## 特長
- \> 40 GHz bandwidth
- Low Vπ 0.7V
- High extinction ratio
- C/L-band support
- Compact footprint, stable DC biasing
- Dual outputs for balanced detection
## 用途
- Radio-over-fiber and satellite links
- Wireless, 5G/6G
### 解説・関連動画▼
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 5:30
•Live
•
## 資料ダウンロード
- [カタログ：薄膜LN 40GHz Ultra-low Vπ光強度変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-40GHz-Ultra-low-Vpai-Intensity-Modulator.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ