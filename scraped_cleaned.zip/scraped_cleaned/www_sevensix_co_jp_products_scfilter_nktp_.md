# Source URL: https://www.sevensix.co.jp/products/scfilter_nktp/

# 
# 白色レーザー光源用 高機能波長選択フィルタ
波長選択範囲：400 ~ 2300nm
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 広帯域白色レーザー光源
- 波長帯域幅可変光フィルタ
- 光フィルタ
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 広帯域白色レーザー光源
- 波長帯域幅可変光フィルタ
- 光フィルタ
白色スーパーコンティニューム光源用の高機能フィルタ、
『SuperK SPLIT』『SuperK SELECT』『LLTF』『SuperK VARIA』『SuperK CONNECT』のご紹介です。
製品のお問い合わせ･お見積
Supercontinuum 光源の用途のほとんどは、広いスペクトルの中から限られた領域を選択的に抜きだして使います。
このような用途のために、 NKT Photonics は必要なフィルタリング機能を提供する Plug ＆ Play の SuperK アクセサリ
をご用意しております。
NKT Photonics社のSuperK シリーズの白色スーパーコンティニューム光源と SuperK 専用のフィルタアクセサリは、15-pin sub-D ケーブル
(デジタル通信を行えるバスインターフェイス)で接続します。フィルタのバンド幅、中心周波数などの各種制御は PCの専用
ソフトウェアを介して行います 。
(PC – SuperK 白色スーパーコンティニューム光源 – SuperK アクセサリ という順番で接続します)
### ■　SuperK アクセサリの比較表
## ◆　VIS / nIR or IR 分割フィルタ : 『SuperK SPLIT』
SuperK SPLITは 400 – 2400 nm に及ぶ Supercontinuum レーザーのスペクトルを、可視域と近赤外領域の 2 つに分割するダイクロイックミラーベースのフィルタです。
主な用途は、蛍光イメージング、ナノ構造の特性評価、光学機器の評価です。
### SuperK SPLITの特長
- 標準で830 nm もしくは、1120 nm 付近でスペクトルを分割
- ファイバ出力可能 ( FCコネクタ or コリメータ出力 )
- [SuperK SPLIT のデータシート](
※デモ機のご用意ございます。
## ◆　任意の波長を同時に選択 : 『SuperK SELECT』
SuperK SELECT は、Supercontinuum レーザのスペクトル帯域の中から 多波長を同時に選択肢に出力できる
AOTF (Acousto-optic Tunable Filter) ベースのフィルタアクセサリです。
取り出す波長の中心波長と出力は独自に制御できます。PDを用いたフィードバックオプションを付けていただくことで、
取り出した波長の出力安定性を ± 0.5 % ( 典型値 ) とすることができます。
主な用途は走査型レーザ検眼鏡、超解像イメージング、フローサイトメトリーです。
### SuperK SELECTの特長
- スペクトル幅 0.5 – 19.8 nm (中心波長による)
- VIS, nIR, IR 領域から任意の1～16色を出力
- 各色の出力バランスを制御可能
- 波長選択の高速スイッチング可能
- 出力安定性 ± 0.5 % (中心波長による )
- ファイバ出力可能 ( FCコネクタ or コリメータ出力 )
- 直線偏光出力
- 専用ソフトウェアでPC制御
- [SuperK SELECT のデータシート](
※デモ機のご用意ございます。
### SuperK SELECTのライブデモ動画
SuperK SELECT は使用したい波長領域、スペクトル幅に応じて複数のモデルをご用意しております。モデルの選択時は専門の日本人技術スタッフとご相談の上、ご決定いただけます。
## ◆　中心波長 可変シングルラインフィルタ : 『LLTF』
LLTF は高分解能かつ連続的に中心波長を可変できるバンドパスフィルタです。Supercontinuum レーザと LLTF を一緒にお使いいただくことで、Supercontinuum レーザは、広範囲で中心波長可変のピコ秒レーザになります。
LLTF は透過率は帯域外スペクトル抑圧比に優れたフィルタです。
可視領域 ( 400 – 1000 nm ) と赤外領域 ( 1000 – 2300 nm ) の 2つのモデルをご用意しています。
###### LLTF の特長
- 対応波長 400 – 1000 nm or 1000 – 2300 nm
- 狭帯域 ＆ 高分解能
- 帯域外スペクトル抑圧比 \> 60 dB
( VISタイプは中心波長から ±40 nm 離れた波長、SWIRタイプは中心波長から ±80 nm 離れた波長 )
- 非常に優れたビーム位置安定性
- ファイバ出力可能 ( FCコネクタ or コリメータ出力 )
- 無偏光出力
- 専用ソフトウェアで PC制御
- [LLTFのデータシート](
※デモ機のご用意ございます。
## ◆　中心波長・バンド幅 可変シングルラインフィルタ : 『SuperK VARIA』
SuperK VARIAは 400 – 840 nmの可視領域で、任意の中心波長でスペクトル幅 10 – 100 nm ( カスタム 200 nm ) で取り出すことができるチューナブルなバンドパスフィルタ ( シングルラインフィルタ )です。偏波由来の損失がない高い透過率で、帯域外スペクトル抑圧比が高いため、FLIM など高感度の検出器を用いたアプリケーションに最適なフィルタアクセサリです。
取り出す光のスペクトル幅を大きくすればするほど、高い出力を取り出すことができます。またスペクトルを広くするほど
コヒーレンスが低下するため、スペックルの無いイメージングを行えます。
主な用途は、蛍光イメージング、ナノ構造の特性評価、光学機器の評価です。
### SuperK VARIAの特長
- 対応波長 400 – 840 nm
- 高出力可能 ( スペクトル幅に依存 )
- 帯域外スペクトル抑圧比 \> 50 dB
- 高透過率 70 – 90 % ( スペクトル幅 50 nm 時の平均値 )
- ファイバ出力可能 ( FCコネクタ or コリメータ出力 )
- 無偏光出力 ( 偏光子追加オプションにより直線偏光可能 )
- 専用ソフトウェアで PC制御
- カスタム対応可能
- [SuperK VARIAのデータシート](
※デモ機のご用意ございます。
SuperK VARIAのライブデモ動画 ▼
『SuperK VARIA』、弊社でも使ってます ▼
## ◆　ファイバ結合ユニット：『SuperK CONNECT』
上記4つのSuperK フィルタアクセサリ( SuperK SPLIT、SuperK SELECT、LLTF、SuperK VARIA)内部は
空間光学系で構成されており、基本的に出力はコリメートビームとなっております。
SuperKのフィルタアクセサリ と一緒に ファイバ結合ユニット SuperK CONNECT をお使いいただくことで、
フィルタリング後のコリメートビームを再度 Photonic Crystal Fiber ベースの シングルモードファイバ(non-PM or PM)に高効率で再結合することもできます。
出力端は、FC/PC コネクタ、 FC/APC コネクタ、コリメータの3種類からお選びいただけます。
[SuperK CONNECT のデータシート](
NKT Photonics社製 広帯域 白色レーザー光源との接続方法（英語） ▼
SuperK CONNECTを用いた SuperKのフィルタアクセサリとシングルモードファイバのアライメント方法（英語）▼
## 資料ダウンロード
- [データシート：SuperK SPLIT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-SPLIT-Datasheet.pdf#view=Fit)
- [データシート：SuperK SELECT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-SELECT-Datasheet.pdf#view=Fit)
- [アプリケーションノート：SuperK SELECTを用いたパワーロックオプションの説明](https://www.sevensix.co.jp/wp-content/uploads/application_note_-_SuperK_Power_Lock_and_modulation_V01-2.pdf#view=Fit)
- [データシート：SuperK LLTF](https://www.sevensix.co.jp/wp-content/uploads/SuperK-LLTF-Datasheet.pdf#view=Fit)
- [データシート：SuperK VARIA](https://www.sevensix.co.jp/wp-content/uploads/SuperK-VARIA-Datasheet-1.pdf#view=Fit)
- [データシート：SuperK CONNECT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-CONNECT-Datasheet.pdf#view=Fit)
- [データシート：SuperK Accessories](https://www.sevensix.co.jp/wp-content/uploads/SuperK-Accessories-Datasheet-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ