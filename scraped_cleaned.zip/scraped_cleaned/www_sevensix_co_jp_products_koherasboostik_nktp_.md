# Source URL: https://www.sevensix.co.jp/products/koherasboostik_nktp/

# 
# ベンチトップ型 超低ノイズ 狭線幅 高出力ファイバレーザー『Koheras BOOSTIK HP』
波長: 1050 ~ 1090nm / 1550 ~ 1570nm　最大: 出力 15W
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 狭線幅CWレーザー光源
『Koheras BOOSTIK』 のBenchtop タイプは、Koheras ADJUSTIK と Koheras 専用の EDFA / YDFAが組み合わさったモデルとなっております。
製品のお問い合わせ･お見積
Koheras BOOSTIK HP はメンテナンスフリーの単一周波数ファイバレーザーです。Koheras BOOSTIK HP のBenchtop タイプは、 Koheras ADJUSTIK と Koheras 専用の EDFA / YDFAが組み合わさったモデルとなっております。
Koheras BOOSTIK HP は狭線幅、優れたビーム品質と高出力性を兼ね備えている唯一のレーザーです。ターンキーシステムの 19インチラックシステムには、制御エレクトロニクス、電源が搭載されており、メトロジーに代表されるようなラボ内での実験、研究用途に最適なレーザーとなっております。ビーム品質が非常にすぐれているので、周波数変換（高調波発生）において高い変換効率を実現できます。
※カスタムとしてC15タイプ、X15タイプでのご案内も可能です。
### 特長
- 15 W @ 動作波長1 um 、1.5 um 最大出力
- 単一波長、狭線幅
- 超低周波数ノイズ、超低強度ノイズ
- 広範囲の波長チューニング、kHz モジュレーション
- 周波数変換に最適な優れたビーム品質
- Optically isolated
- 堅牢、メンテナンスフリーなファイバレーザー
### 用途
Koheras BOOSTIK HP レーザーは超低雑音と狭線幅でありながら高出力であるため、広範で多様な用途にお使いいただけます。Koheras BOOSTIK HP はカスタムにより最大 4チャンネルのレーザー出力にも対応します（波長は同一です）。各チャンネルのレーザー出力の低雑音特性と狭線幅特性は Koheras BASIK 1台使用時と同じです。複数の **異なる波長** のレーザーが必要な場合は、 Koheras ACOUSTIK マルチチャンネルプラットフォームをご検討ください。
- 周波数標準
- 量子光学
- 光トラッピング
- 光格子
- ボーズアインシュタイン凝縮
- 原子干渉計
- スクイージング
- レーザーメトロロジー
- 光ヘテロダイン / コヒーレント通信
- コヒーレントビーム結合
- 非線形光学励起光源（SHG, DFG, OPO）
## 資料ダウンロード
- [データシート：Koheras BOOSTIK HP](https://www.sevensix.co.jp/wp-content/uploads/Koheras_BOOSTIK_HP.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ