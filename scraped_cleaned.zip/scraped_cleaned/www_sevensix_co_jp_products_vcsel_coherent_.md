# Source URL: https://www.sevensix.co.jp/products/vcsel_coherent/

# 
# 顔認証システム/3Dセンサ（VCSEL）
波長: 940nm
_メーカ：_ Coherent (旧 II-VI)
- 半導体レーザーダイオード（LD）
- VCSEL(面発光レーザー)
✓ 940nmマルチモードVCSEL
✓ 安定した出力パワー、高いビーム品質
✓ CW/パルス
✓ パルス幅(ns) 10 ns
製品のお問い合わせ･お見積
## 特長
- 940nm マルチモード VCSEL
- 酸化膜絶縁技術
- 高効率
- 10μm開口、30μmピッチ、537エミッター、3.5×3.5×1.6mmパッケージ、110×85Degディフューザー付き
- ケース動作温度：-40℃～105
## 用途
- 赤外 3Dイメージング
- コンシューマー向け携帯電話用
- 先進運転支援システム（ADAS)
- 3Dマシンビジョン
- ジェスチャ認識アプリケーション
## 仕様詳細
- CW 及び パルス動作対応（Rise/Fall times<1ns）
- ベア・ダイ または 各種表面 実装パッケージ対応
- 均一六角パターンのレイアウト
- ビーム広がり角　～15-20°
- 効率 ＞ 35％ @60℃ （40％ @60℃・パルスモード）
## 資料ダウンロード
- [データシート：顔認証システム/3Dセンサ VCSEL【HVS7000】](https://www.sevensix.co.jp/wp-content/uploads/FInisasr-VCEL-an-2109_high_power_vcsel_for_gesture_recognition-master-RGB-web.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ