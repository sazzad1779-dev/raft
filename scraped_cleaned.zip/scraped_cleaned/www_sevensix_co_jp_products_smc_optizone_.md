# Source URL: https://www.sevensix.co.jp/products/smc_optizone/

# 
# シングルモードサーキュレータ
波長: 850 ~ 1610nm　ポート数: 1×2 / 2×2
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- SMサーキュレータ
- 光サーキュレータ
中国の深センに拠点を構えるOptizone Technologiesのシングルモードサーキュレータです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 低挿入損失
- 高アイソレーション
## 用途
- 光増幅器
- FBGアプリケーション
- ファイバーセンサ
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 850nm、1064nm、1310nm、1550nm、1610nm、その他も対応可 |
| ポート数 | 1×2、2×2 |
| 入力パワー | 300mW、500mW、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、 250umパンダファイバ、400umベアファイバ、 900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準0.8m、1m、その他も対応可 |
## パッケージタイプ
 　　　　　　　　　標準タイプ
　　　　　　　　　Type C139
## 資料ダウンロード
- [データシート：850nm Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-076B-FCIR-85-C139-1-NNN-BBB-1-112.pdf#view=Fit)
- [データシート：1064nm Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-003F-FCIR-1064nm.pdf#view=Fit)
- [データシート：1310nm、1550nm、1610nm 1x2 Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-002E-FCIR-1310nm1550nm.pdf#view=Fit)
- [データシート：1550nm 2x2 Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-005A-2x2-FCIR-1550nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ