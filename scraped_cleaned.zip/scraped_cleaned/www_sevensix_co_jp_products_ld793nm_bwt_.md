# Source URL: https://www.sevensix.co.jp/products/ld793nm_bwt/

# 
# ファイバ付 高出力 半導体マルチモードレーザー
波長: 793nm　出力: 4 ~ 180W
_メーカ：_ BWT Beijing LTD.
- 半導体レーザーダイオード（LD）
- ポンプLD
- MMファイバ
- ファブリペローレーザー
✓ Tmファイバレーザ、TDFA の励起用光源として使用可能
✓ コンパクト、高輝度、高出力
✓ 1900-2100nm Feedback Protection付き
製品のお問い合わせ･お見積
## 特長
- 2 umで発振するツリウムファイバレーザのおよびその増幅器( TDFA : Tm Doped Fiber Amplifier )に使用可能
- 広いパワーレンジ
## 用途
- ファイバーレーザーの励起
- 固体レーザーの励起
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| 製品名 | 型番 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| 793nm 4W Fiber Coupled Diode Laser | [K793DB2RN-4.000WN0N-10522F10EFF]( | 793 | 4 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 8W Fiber Coupled Diode Laser | [K793DA2RN-8.000WN0N-10522F10EFF]( | 793 | 8 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 22W Fiber Coupled Diode Laser | [K793DAHRN-22.00W]( | 793 | 22 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 30W Fiber Coupled Diode Laser | [K793DA5RN-30.00WN0N-10522F10EFF]( | 793 | 30 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 50W Fiber Coupled Diode Laser | [K793DA5RN-50.00WN0N-10522F20EFF]( | 793 | 50 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 90W Fiber Coupled Diode Laser | [K793DN1RN-90.00WN0N-10522F20EFF]( | 793 | 90 | 106.5 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 100W Fiber Coupled Diode Laser | [K793DN1RN-100.00WN0N-10522F20EFF]( | 793 | 100 | 106.5 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 140W Fiber Coupled Diode Laser | [K793DN1RN-140.0WN0N-20022F20EFF]( | 793 | 140 | 200 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 180W Fiber Coupled Diode Laser | [K793DN2RN-180.0WN0N-20022F20EFF]( | 793 | 180 | 200 | 0.22 | ファイバーレーザー増幅 |
## 製品に関するお問い合わせ
この製品のお問い合わせ