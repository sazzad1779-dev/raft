# Source URL: https://www.sevensix.co.jp/products/vcsel_kyosemi/

# 
# VCSEL（垂直共振器型面発光レーザー）
発光波長: 850nm
_メーカ：_ デクセリアルズ株式会社（旧:京都セミコンダクター）
- 半導体レーザーダイオード（LD）
- VCSEL(面発光レーザー)
本VCSEL（Vertical Cavity Surface Emitting Laser）は、
短距離の高速データ通信システム光源として最適です。
4GHzまでの変調信号に対応します。
製品のお問い合わせ･お見積
#### **特長**
- 垂直共振器型面発光レーザ
- LC-TOSA / キャップ絶縁型2ピンミニキャン
- 出力（１ｍW / 2.5mW）
- 帯域幅（4GHz)
- VCSELレーザ発信モニター用フォトダイオード搭載　　　　　他
#### **用途**
- 短距離光通信
- 高速データ通信
#### **仕様詳細**
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| 形名 | 発光波長<br>Typ.\[nm\] / 条件 | 光出力<br>Typ.\[mW\] / 条件 | 帯域幅<br>Typ.\[GHz\] / 条件 | パッケージ |
| [KLD085VC-LTH32]( | 850 / λp=ピーク波長  CW  <br>IF=7mA | 1 / <br>CW  IF=7mA | 4 / <br>PO=1.0mW | LC-TOSA |
| [KLD085VC-S]( | 850 / λp=ピーク波長  CW  <br>IF=7mA | 2.5 / <br>CW  IF=7mA | 4 / <br>PO=1.0mW | TO-CAN |
| [KLD085VC-H32]( | 850 / λp=ピーク波長  CW<br>PO=2.5mW | 2.5 / <br>CW  IF=7mA | 4 / <br>PO=2.5mW | TO-CAN |
## 製品に関するお問い合わせ
この製品のお問い合わせ