# Source URL: https://www.sevensix.co.jp/products/15ummodulator_erim_ixbue/

# 
# 1.5 um帯 10GHz/20GHz/40GHz 高消光比 強度変調器
波長: 1530 ~ 1625nm　帯域幅: 最大 40GHz
_メーカ：_ iXBlue SAS
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 強度変調器
- 光変調器
10～40GHzのアナログ伝送に適したLN変調器です。高ER変調器は短パルス発生やパルスピッキングへの使用に最適で、バイアスコントローラ、RFアンプ等と合わせて提案可能です。
製品のお問い合わせ･お見積
## 特長
- 高消光比：40 dB
- 広帯域
- X-cut で高安定
- 低い駆動電圧
- 低い挿入損
### ■ 高ER特性
MXER-LN シリーズの LN 強度変調器 ( Intensity modulator ) は非常に高い消光比 ( ER : Extingcion Ratio ) を有した マッハツェンダ変調器です。このLN変調器の高ER特性は Photoline Technologiesの特許技術である “Magic Junction” 法にあります。
LN変調器に用いる導波路チップの製造方法には、Ti-In Defusion法と Proton Exchange 方があります。Ti-In Defusion法は、2軸の偏波に対応します。よって、導波路チップの前方にあるレンズと光ファイバのアラインメントがズレると導波路チップの意図しない偏波モードに光が入ってしまい、ER が低くなってしまいます。
一方、iXblue Photolineが MXER-LN シリーズで採用しているProton Exchange 法では、TEモードしか同派しないためERが高いという特長があります。他社もこの Proton Exchange法を用いているところがありますが、数十mW程度のパワーの光入力で不安定になってしまいます。これは、導波路チップから光が漏れてしまうためです。iXBlue Photlineは独自の特許技術 Magic Junction法により、100 mWの光入力でも安定な ERを達成できます。
MXER-LN シリーズでは、ERを 30 – 35 dB, 35 – 40 dB, > 40 dB 以上の 3タイプからお選びいただけます。ご発注時に必要なER特性をご指示いただければ、要求仕様を満たす LN変調器のチップを選別してLN変調器を製造します。ERの出荷時の測定は通常 1550 nm のレーザで行われます。他の波長を用いた測定をご要望の場合はお気軽にご相談ください。
### ■ iX Blueの信頼性
iXBlue Photonics には、LN変調器と RFエレクトロニクスを製造している iXBlue Photlineブランドと、特殊ファイバファイバブラッググレーティングを製造している iXBlue Fiberブランド があります。iXBlue Photonicsは、センシング、計測、防衛、通信、宇宙（iXBlue Fiber は Space qualified された唯一のファイバメーカです。）、ファイバレーザ、研究用途の製品を世界中で販売しているワールドワイドな企業です。こちらで、iXBlue の製造能力、品質管理情報をご覧いただけます。
iXBlue Photlineの LN変調器は　NASAなど宇宙開発システムにも携わっています。宇宙開発では、品質（Quality）、堅牢さ(Robust)、高い安定性（High reliability）が求められます。LN変調器の納品時には、湿度、バキュームなど9つの指標のテストをパスして納めています。
iXblue photonics - YouTube
Photo image of iXblue Photonics
iXblue Photonics
30 subscribers
iXblue photonics
iXblue Photonics
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 6:35
•Live
•
## 用途
MXER-LN シリーズは高消光比（コントラスト）と広いバンド幅が求められるような用途に最適なデバイスです。例えば、パルスレーザにおけるアンプ前のパルスピッキングや、パルスジェネレータでは高ERな LN変調器ほど光ファイバ増幅器での信号のゲインを稼ぐことができます。LIDARベースのセンシングシステム、ブリルアン散乱を用いた光ファイバセンサでも有用です。
MXER-LN シリーズは、バンド幅 10 GHz と 20 GHzのモデルがございます。その他、ピグテールファイバの種類、コネクタの種類をお選びいただくことができます。
- バンド幅 : 10 10 GHz 20 20 GHz
- フォトダイオード内蔵：Yes or No
- 入出力ファイバ：偏波保持ファイバ、Standard SMファイバ
- 入出力コネクタ：素線、FC/APC、FC/SPC コネクタ（ナローキー）
- 消光比：30 – 35 dB, 35 – 40 dB
iXBlue Photline のLN変調器は多くのレーザメーカのパルスレーザに採用されているため、どのようなレーザであれば、どの種類モジュレータを使えばよいかという知見があります。エンドユーザに推奨品を提案することができます。お問合せの際には、レーザの 波長 / パルス幅 / 繰り返し周波数 / パルスエネルギー / 平均出力 / 求めるER をご連絡いただけると幸いです。
### ■ **使用方法 / RFデバイスの提供**
マッハツェンダ型のLN強度変調器は完全にバランスしておらず、フィードバック制御をしない状態では、周囲の温度変化、チップ（筐体）の温度不均一性、エイジング、フォトリフラクティブ効果、静電気の蓄積によってドリフトしてしまいます。よって、LN変調器の性能を生かすためには、LN変調器に適切なDCバイアス電圧を与えるRFドライバ、エレクトロニクスを用意しなければいけません。iXBlue Photline は競合他社と違いLN変調器を製造・販売するだけにとどまらず、バイアスコントローラからRFドライバまでエレクトロニクスの全てを提供できるため、自社の LN変調器の性能をフルに発揮することができます。iXBlue Photline のユーザは、購入いただく LN変調器に合った RFデバイスを入手できるため、スムースな研究開発/システムの構築が可能です。
iXBlue Photlineは、はじめて LN変調器をお使いいただける方にもスムースに実験を行っていただけるよう、アプリケーションノ-トの公開等も行っております。
>> [RFドライバとRFアンプに関するアプリケーションノート](
>> [低周波数 LN変調器のアプリケーションノート](
>> [バイアスコントローラの使い方](
## 仕様詳細
| 対応波長(nm) | 1530 ～ 1625 |
| 耐光出力(mW) | 100 |
| 変調帯域(GHz) | 10 ～ 40 |
| 消光比(dB) | 20 ～ 40 |
| 挿入損失(dB) | 0 ～ 4 |
## 資料ダウンロード
- [データシート：1.5 um帯 10GHz/20GHz/30GHz 高消光比 強度変調器](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A0-1.pdf#view=Fit)
- [データシート：RFドライバの紹介資料](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A1.pdf#view=Fit)
- [アプリケーションノート：低周波数駆動時](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A2.pdf#view=Fit)
- [紹介資料：バイアスコントローラの紹介資料](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A4.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ