# Source URL: https://www.sevensix.co.jp/products/400_100_opm_ppi/

# 
# 400G/100G 光パワーメータ
400GbE / 100GbE高速光通信規格をサポート
_メーカ：_ PPI Inc.
- 光計測器
- パワーメータ
400GbE/100GbEなどの高速光通信規格に対応した、ハンディで直感的な操作感の光パワーメータです。100GbE-LR4/ER4/CWDM4や400GbE-FR4の波長多重された信号光のレベルを波長毎に測定・表示したり、100GbE-SR4/400GbE-DR4のMPOケーブルの多芯ファイバの光レベルをレーン毎に同時に測定・表示することができます。
製品のお問い合わせ･お見積
#### **特長**
- 通常の光パワーメータでは測定の難しい400GbE/100GbE規格の波長毎・レーン毎の光パワー測定が可能
- 通常の光パワーメータとしても使用可能(850/1310/1550nm) ※NSK-LCOPM
- バッテリ駆動7時間(USB充電式)
- ハンディタイプ小型軽量
- USB接続でPCへデータ転送(データファイル形式csv)
#### **用途**
- 光通信用信号光のレベル測定
#### **仕様詳細**
- NSK-LCOPMの仕様、ディスプレイ表示例
- PPI-MPO-12の仕様、ディスプレイ表示例
## 資料ダウンロード
- [カタログ：NSK-LCOPM (LR4/ER4/CWDM4/FR4用)](https://www.sevensix.co.jp/wp-content/uploads/%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0_PPI%E8%A5%BF%E5%B7%9D%E8%A8%88%E6%B8%AC_NSK-LCOPM.pdf#view=Fit)
- [カタログ：PPI-MPO-12 (SR4/DR4用)](https://www.sevensix.co.jp/wp-content/uploads/%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0_PPI_MPO%E3%83%91%E3%83%AF%E3%83%BC%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BB%E5%85%89%E6%BA%90.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ