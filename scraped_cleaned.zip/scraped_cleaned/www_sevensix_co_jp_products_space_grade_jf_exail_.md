# Source URL: https://www.sevensix.co.jp/products/space-grade-jf_exail/

# 
# 【宇宙グレード】偏波保持ジャイロファイバ
_メーカ：_ exail
- 光ファイバ素線 / 光ファイバパッチコード
- シングルクラッドファイバ
- PMファイバ
Exail社の「宇宙グレード偏波保持ジャイロファイバ」は、光ファイバジャイロスコープ（FOG）への統合を目的として設計された高性能な偏波保持（PM）ファイバです。
同社は、宇宙環境での使用に適した高品質な光ファイバソリューションを提供しており、特に高精度な慣性計測やナビゲーションシステムにおいて信頼性の高い製品を提供しています。
製品のお問い合わせ･お見積
## 特長
- 高信頼性: 宇宙環境での使用に適した設計により、過酷な条件下でも安定した性能
- 優れた偏波保持能力: 高い偏波消光比（PER）を持ち、光信号の偏波状態を効果的に維持
- 低損失: 低挿入損失により、システム全体の効率を向上
## 用途
- 宇宙用光ファイバジャイロスコープ（FOG）
- 高精度慣性計測装置
- その他、宇宙環境下での高精度光学計測システム
## 使用詳細
|     |     |
| --- | --- |
| 製品型番 | 製品概要 |
| **[IXF-PMG-1550-80-019-E]( | 1550 nm operation Tiger design<br>Polarization maintaining fiber for gyroscope<br>80 µm cladding diameter<br>170 µm coating diameter |
| **IXF-PMG-1550-80-019-E-LS**<br> | 1550 nm operation Tiger design Reduced coating<br>Polarization maintaining fiber for gyroscope<br>80 µm cladding diameter<br>170 µm coating diameter |
## 関連動画
### ▼ EXAIL – Photonics solutions for Laser, Sensing, Communication, Quantum and Space applications
### ▼ Space Quality 変調器・特殊ファイバ│Vol.75
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 【宇宙グレード】位相変調器 \- 動作帯域: 950 ~ 1150 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙グレード】高消光比強度変調器 \- 動作帯域: 1535 ~ 1560 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙向け】低雑音光増幅器 \- 波長: 1550 ~ 1560 nmexail光増幅器/ 光変調器/ PD/ 光フィルタ他
- 【宇宙グレード】放射線硬化型ドープファイバ​ \- exail光ファイバ素線 / 光ファイバパッチコード