# Source URL: https://www.sevensix.co.jp/products/ox1_exfo/

# 
# 光ファイバチェッカー『OX-1』
シングルモードファイバ
_メーカ：_ EXFO
- 光計測器
- その他
シングルエンド接続で光ファイバの線路長/損失/反射をわずか3秒で同時測定できる光ファイバチェッカーです。光ファイバ配線の工事・メンテナンスに携わる幅広いお客様へ、設備投資・運営コストの削減をご提案いたします。
製品のお問い合わせ･お見積
## 特長
- シングルエンド接続のみで測定可能
- SMFのケーブル長・損失・反射を同時に3秒以内に測定可能
- 独自のアルゴリズムにより線路品質の五つ星判定表示
- コネクタ接続部交換可能でメンテナンス性が大幅に改善
- 自動で線路の障害要素を検出・分析も可能
- パワーモニタと光源を内蔵
## 用途
- FTTx、アクセスネットワーク
- データセンター
- 5Gファイバ ロールアウト
- 光ファイバ線路品質チェック
## 仕様詳細
### ■ 製品ラインナップ
| モデル | 型番 | 仕様 |
| --- | --- | --- |
| ベーシックモデル(設置工事用) | OX1-I-xx-xx | ベーシックモデル、1310/1550 nm |
| ベーシックモデル(監視・メンテ用) | OX1-M-xx-xx | プロフェッショナルモデル、1650nm |
| プロモデル(設置工事用) | OX1-PRO-I-xx-xx | プロフェッショナルモデル、1310/1550nm |
| プロモデル(監視・メンテ用) | OX1-PRO-M-xx-xx | プロフェッショナルモデル、1650nm |
### ■ ファイバエクスプローラ
|     |     |
| --- | --- |
| 波長 | 1310 nm ± 30 nm<br>1550 nm ± 30 nm<br>1650 nm ± 10 nm: Integrated filter isolation: 50 dB from 1265 nm to 1617 nm |
| 最大リンク損失 (dB) | 15 |
| 測定時間 | Flash Advisor (Distance, IL, ORL): 3秒<br>Fault Explorer (Distance, IL, ORL, fault exploration): down to 5 秒b<br>Link Mapper (Distance, IL, ORL, mapping of detectable elements): down to 10秒 b |
| 不確定距離 | ±1.5 m c |
| キャリブレーション間隔(年) | 10 |
### ■ 接続性とスプリッターのチェック
|     |     |
| --- | --- |
| スプリッタータイプ | Up to 1:64 |
| 最大リンク長 (km) | 20 |
| 最大ラストマイル・ファイバー長 (km) | 5 |
| 最大ラストマイルファイバ損失 (dB) | 2.5 |
| スプリッタ後の最短ファイバ長e<br>1:2 splitter<br>1:4 splitter<br>1:8 splitter<br>1:16 splitter<br>1:32 splitter<br>1:64 splitter | 25 m<br>35 m<br>150 m<br>250 m<br>500 m<br>1000 m |
### ■ パワーチェッカー
|     |     |
| --- | --- |
|  |  |
| 波長 (nm) | 1310, 1490, 1550, 1577, 1625, 1650 |
| パワーレンジ (dBm) d | –60 to 15 |
| 最大入力電力 (dBm) | 15 |
| 不確定パワー e | ±0.7 dB at –20 dBm |
| トーン検出f | 270 Hz, 330 Hz, 1 kHz, 2 kHz |
### ■ 光源
|     |     |
| --- | --- |
| 波長 (nm) | 1310 nm ± 30 nm<br>1550 nm ± 30 nm<br>1650 nm ± 10 nm |
| 出力パワー (dBm) g,h | \> –8 |
| 出力の安定性 | ±0.2 dB after 30-minute warmup (\[Max. – Min.\]/2) |
| ソース変調 | CW, 270 Hz, 330 Hz, 1 kHz, 2 kHz |
### ■ 一般特性
|     |     |
| --- | --- |
| デイスプレイ | 4-inch touch screen |
| サイズ (H x W x D) | 171 mm x 93 mm x 48 mm |
| 重さ | 0.5 kg |
| バッテリー寿命 | 10 時間 |
| 充電時間 | < 5-hour charge time when unit is off USB Type-C charging port connector AC/DC charger/adapter input: 100 – 240 V; 50/60 Hz; 1.0 A max, output: 5 V; 2 A |
| インターフェース | WiFi 802.11 b/g/n 2.4 GHz, up to WPA2 encryption<br>Bluetooth 4.2 with BLE, Class 2 (compatible with 4.0 smartphones) |
| ストレージ容量 | 1000 test results |
| レポート機能 | • Single test: PDF on TestFlow mobile app<br>• Batch of tests: online (TestFlow account required) |
| 使用環境　<br>・作動中<br>・保管 | —10 °C to 45 °C (14 °F to 113 °F)<br>—40 °C to 70 °C (—40 °F to 158 °F) a |
| 湿度範囲 | ≤ 93 %, non-condensing |
| 落下耐性強度 | 1 m (39 in) |
| ディスプレイミラーリング機能 | From VNC clien |
備考
a. すべての仕様は、特に指定のない限り、23℃±2℃における代表値です
b. リンク上の障害の数およびリンクロスに応じて、測定時間は5秒～40秒（代表値）となります
c. 5kmのリンクでは、屈折率に関連する不確実性を除き、全挿入損失は3dB、反射率は-42dB（屈折率に関する不確実性を除く）
d. 範囲外の高さと低さを表示する
e. 光出力診断で5つ星の評価を受けたOptical Explorerコネクタの品質を有すること
f. EXFO社製の光源を使用した場合
g. 測定範囲が15dBm以上のパワーメータ／チェッカを使用すること
h. デューティサイクル1%での平均パワー
## 解説・関連動画
## 資料ダウンロード
- [データシート：光ファイバチェッカー『OX-1』](https://www.sevensix.co.jp/wp-content/uploads/EXFO%E3%80%80%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90%E3%83%BC%E3%83%81%E3%82%A7%E3%83%83%E3%82%AB%E3%83%BC%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
- [関連紹介資料：データセンターテストキット](https://www.sevensix.co.jp/wp-content/uploads/exfo_data-center-test-kit_interactive_v2_ja-2.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- PIC(光集積回路)テストソリューション - 測定したい光集積回路をカスタマイズEXFO光計測器