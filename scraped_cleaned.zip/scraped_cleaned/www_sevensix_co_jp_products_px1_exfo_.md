# Source URL: https://www.sevensix.co.jp/products/px1_exfo/

# 
# 光パワーメータ『PX-1』
多機能な汎用光パワーメータ
_メーカ：_ EXFO
- 光計測器
- パワーメータ
1台で最大45波長(850nm/1310nm/1550nm/CWDM/PON他)の光パワー測定が可能な多機能汎用光パワーメータです。
製品のお問い合わせ･お見積
## 特長
- 最大45波長(850nm/1310nm/1550nm/CWDM/PON他)の測定が可能
- 手のひらサイズで小型軽量(133 x 78 x 30 mm / 225g)
- バッテリ駆動8時間(USB充電式)
- USB及びBluetooth接続でPC・スマホへデータ転送
- IP54防塵・防水規格対応
- 自動波長認識、スイッチング機能搭載
## 用途
- 光パワーの測定(850nm/1310nm/1550nm/CWDM/PON他)
## 仕様詳細
### 解説・関連動画▼
## 資料ダウンロード
- [スペックシート：光パワーメータ『PX-1』](https://www.sevensix.co.jp/wp-content/uploads/%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0_EXFO_PX1.pdf#view=Fit)
- [関連紹介資料：データセンターテストキット](https://www.sevensix.co.jp/wp-content/uploads/exfo_data-center-test-kit_interactive_v2_ja-3.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- CWDM/DWDMネットワーク用光スペクトラムアナライザ『FTBx-5235』 - 波長: 1270 ~ 1610nm　周波数: 50GHz / 100GHzEXFO光計測器
- OPAL-MD：フォトニック集積回路 (PIC) 向け自動プローブステーション​ - EXFO光計測器
- OPAL-EC：フォトニック集積回路 (PIC) 向けエッジカップリング自動プローブステーション - EXFO光計測器
- OPAL-SD：フォトニック集積回路 (PIC) 向けシングルダイ自動プローブステーション - EXFO光計測器