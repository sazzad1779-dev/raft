# Source URL: https://www.sevensix.co.jp/products/smfc_optizone/

# 
# シングルモードフューズドカプラ
波長: 980 ~ 2000nm　ポート数: 1×2 / 2×2
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- 光ファイバカプラ
- フューズドカプラ(溶融延伸型)
中国の深センに拠点を構えるOptizone Technologiesのシングルモードフューズドカプラです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間20,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 広帯域
- 低挿入損失
## 用途
- 研究開発
- 光増幅器
- CATV Network
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 980nm、1030nm、1060nm、1310nm、1480nm、1550nm、1940nm、2000nm、その他も対応可 |
| ポート数 | 1×2、2×2 |
| カップリング比率 | 0.1：99.9、1：99、2：98、3：97、5：95、10：90、20：80、30：70、<br>40：60、50：50、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、LC/UPC、LC/APC、MU/UPC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：980nm、1060nm 1×2、2×2 Single Mode Standard Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03012C-SMC-980nm1060nm.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2×2 Single Mode Standard Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03005F-SMC-1310nm1550nm-1.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2×2 Single Mode Broadband Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03001E-SBC-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2×2 Single Mode Dual Window Wavelength Flattened Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03003B-SDC-1310nm1550nm.pdf#view=Fit)
- [データシート：980nm、1030nm、1060nm、1310nm、1550nm、1940nm、2000nm 1×2、2×2 High Power Single Mode Standard Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03016B-HPSMC-980nm2000nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1×2、2×2 Mini Size Single Mode Standard Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03020B-MSMC-1310nm1550nm.pdf#view=Fit)
- [データシート：980nm、1030nm、1060nm、1310nm、1550nm、1940nm、2000nm 1×2、2×2 Mini Size Single Mode Broadband Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03018B-MSBC-980nm2000nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1×2、2×2 Mini Size Single Mode Dual Window Broadband Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT03019B-MSDC-1310nm1550nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ