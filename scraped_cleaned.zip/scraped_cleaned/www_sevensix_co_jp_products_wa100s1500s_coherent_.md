# Source URL: https://www.sevensix.co.jp/products/wa100s1500s_coherent/

# 
# 高性能光スペクトラムアナライザ : WaveAnalyzer
C-Band フルカバー
_メーカ：_ Coherent (旧 II-VI)
- 光計測器
- 光スペクトラムアナライザ
WaveAnalyzerはリアルタイム かつ 高分解能で1527 – 1612 nmの波長帯を測定できる光スペクトラムアナライザです。光通信分野の研究用途や、光通信関連部品の工場での検査用途に最適です。
さらに、弊社ではWaveAnalyzer のポテンシャルを最大限に引き出す
当社オリジナル・ソフトウェアのサポートをご提供しております。
製品のお問い合わせ･お見積
## 特長
- C-band/L-band 高い分解能帯域幅／ 1500S : 180MHz
- リアルタイム測定／1500S : 4 update/s
- 小型軽量／1500S : 4kg
- USB, Ethernet 接続
## 用途
WaveAnalyzer は コヒーレント検波方式の光スペクトラム・アナライザです。WaveAnalyzer の内部には Finisar社の高速掃引可能なローカルオシレータとコヒーレントレシーバが内蔵されています。非常に高分解能な測定ができるため、LN変調器の試験、LN変調器のバイアス調整、トランシーバの試験にお使いいただけます。また、リアルタイムでの測定が可能なため、モードロックレーザの調整時に、リアルタイムで調整結果を確認できます。
以下のモデルのデモ機がございますのでお申し付けください。
・WaveAnalyzer 1500S　(C-band)
・WaveAnalyzer 1500S　(L-band)
・WaveAnalyzer 200A　 (ポータブルタイプ)
## 仕様詳細
| 波長(nm) | 1527 ～ 1612 |
| 耐光出力(dBm) | 10 ～ 23 |
| サンプリング分解能(MHz) | 20 ～ 312.5 |
| 分解能帯域幅(MHz) | 180 ～ 1750 |
### ■ WaveAnalyzer
WaveAnalyzer には、 WaveAnalyzer 100S と WaveAnalyzer 1500S の 2 モデルがあります。WaveAnalyzer 1500S は 分解能が180 MHz と非常に高く、-80 dBm までの信号を測定可能です。 _スプリアスフリーダイナミックレンジ_( _SFDR_) が \> 50 dBと高く、x偏波とy偏波を別々に測定することができます。Ethernet 接続が可能です。最先端の光通信の研究用途でのご使用に最適です。
WaveAnalyzer 100S は 分解能 1.75 GHz と WaveAnalyzer 1500S には劣りますが 一般的な光スペクトラムアナライザよりも数十倍高分解能です。非常にコンパクト（ 108 mm x 163 mm x 26 mm）、軽量で安価な製品となっています。光通信の研究用途だけでなく、通信帯域をカバーする製品の検査測定器として最適です。ソフトウェアは WaveAnalyzer 1500Sと共通のものをお使いいただけます。下記は、WaveAnalyzer 1500S と 100S の比較表です。
### ■ ブロックダイアグラム
1500S と 100S は基本的に同じ構成です。WaveAnalyzer 1500S では、Coherent Receiver の前に 1:99 の分岐光ファイバカプラがあります。WaveAnalyzer 1500S では +23 dBmまで入力できる Normal Port と、+3dBmまで入力できる High Sense Port があります。それぞれのポートが、99:1 分岐光ファイバカプラの 1%のポートと 99% のポートに対応します。また、WaveAnalyzer 1500S では ギガビット Ethernet を用いることで、Windows PC だけでなく Linux、Android OS、iOS で測定結果を表示できます（世間一般で使われているウェブブラウザを用います）。
### ■ 使い勝手
WaveAnalyzer 100S と 1500Sにはディスプレイがありませんが、PCのディスプレイと直観的GUIにより、ストレスなく光スペクトルを測定できます。日々進化し続ける無料の専用ソフトウェア WaveAnalyzer を用いてOSNR、SMSR（サイドモード抑圧比）、FWHM、WDM解析、波長計解析など各種解析が可能です。専用ソフトウェアの他、LabVIEW、Matlab、C言語を用いての測定も可能で、必要なAPIやサンプルコードを配布しています。ウェブブラウザとHTTPコマンドを用いて任意の波長域を測定・記録することもできます。WaveAnalyzer 1500S と Wi-FiルータをEthernetケーブルで繋げることで、複数のAndroid端末で同時に測定結果を確認できます。下の動画では、WaveAnalyzerを実際に使いながら説明しています。
光周波数コムのスペクトル測定、モード同期レーザのスペクトル測定をはじめとした先進的な光通信領域の研究用途に最適です。
## セブンシックスの技術サポート
導入前・導入後のご相談、承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyze のポテンシャルを最大限に引き出す当社 [オリジナル・ソフトウェア]( のサポート
- WaveShaper・WaveAnalyze の修理対応 (電源系、ファン、ファイバ端面等の交換・修理)
### 解説・関連動画📢
### ▼ Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
エクセルと一緒にご使用いただく Python ベースのソフトウェアを新たに開発しました！Matlabベースのソフトとの違いなど、詳細ついては下記動画をご視聴ください。
▼ 『WaveAnalyzer』超高分解能スペアナ登場！
│Vol.009
▼ 『WaveShaper』セブンシックス製ソフト②
任意スペクトル・パルス生成 │ Vol.011 (Matlabベース)
## 資料ダウンロード
- [カタログ：Waveanalyzerシリーズ](https://www.sevensix.co.jp/wp-content/uploads/20250314_Waveanalyzer_family.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ