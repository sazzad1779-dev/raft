# Source URL: https://www.sevensix.co.jp/products/pompld_sm_innolume/

# 
# シングルモード半導体レーザー
波長: 1000 ~ 1340nm　出力: 200 ~ 700mW
_メーカ：_ Innolume GmbH
- 半導体レーザーダイオード（LD）
- ポンプLD
- SMファイバ
- ファブリペローレーザー
✓ 空間出力 (TO-can)
✓ ファイバ出力 (14 ピンバタフライパッケージ)
✓ 最大出力600mW
✓ モニターフォトダイオード（\*オプション）
製品のお問い合わせ･お見積
## 特長
Innolume 社は 高出力、空間シングル―モード (SM) のファブリ・ペロー型半導体レーザを製造しています。
半導体レーザのパッケージは、9 mm TO-can タイプと、PMF (偏波保持ファイバ) 付きの 14ピンバタフライパッケージからお選びいただけます。
パルス駆動に適したモデルと、ファイバブラッググレーティング (FBG) を用いてスペクトルを安定化させたモデルの用意もございます。
MOPA構成のファイバレーザの種光源の用途には、 SBS (Stimulated Brillouin Scattering) を抑えるためにスペクトルを広げた 低ノイズピークの 出力 1.2 W 高出力モデルがお勧めです。
全ての LDは個別にスクリーニング工程を経て詳細な検査レポートを作成のうえ出荷されるので高い信頼性が約束されています。780 ~ 1330 nm の範囲であれば出力波長のカスタマイズが可能です。お気軽にお問合せください。
Innolume 社は本ページで紹介しているファブリ・ペロータイプのLDだけでなく、DFB/DBR レーザとも共通してお使いいただける温調機能付きドライバもご用意しております。お気軽にお問合せください。
## 用途
- MOPA型のファイバーレーザのシード用光源
- パルス駆動に適したモデル
## 仕様詳細
### ■ ファブリペロー
|     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | 平均波長(nm) | 出力 (mW) | 順電流 (mA) | 順電圧 (V) | 閾値電流 (mA) | スペクトル幅 (3dB)nm | 偏光消光比 (dB) |
| [SML1000B50YY250MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1000B50YY250MXXXX.pdf?_gl=1*wgb92e*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1000nm | 1000 | 250 | 450 | 1.7 | 25 | 0.2 | 17 |
| [SML1020B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1020B50YY400MXXXX.pdf?_gl=1*wgb92e*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1020nm | 1020 | 400 | 800 | 1.9 | 60 | 0.2 | 17 |
| [SML1020B50YY600MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1020B50YY600MXXXX.pdf?_gl=1*1x84htw*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1020nm | 1020 | 600 | 1000 | 2.1 | 70 | 0.2 | 17 |
| [SML1025B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1025B50YY400MXXXX.pdf?_gl=1*1x84htw*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1025nm | 1025 | 400 | 800 | 1.7 | 80 | 0.2 | 18 |
| [SML1030B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1030B50YY400MXXXX.pdf?_gl=1*ohskqm*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1030nm | 1030 | 400 | 800 | 1.7 | 80 | 0.2 | 18 |
| [SML1050B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1050B50YY400MXXXX.pdf?_gl=1*1nbp3j0*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5f#view=Fit) | Fiber-coupled single-mode laser diode at 1050nm | 1050 | 400 | 800 | 1.8 | 50 | 0.2 | 17 |
| [SML1050B50YY600MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1050B50YY600MXXXX.pdf?_gl=1*1nbp3j0*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1050nm | 1050 | 600 | 1000 | 2 | 50 | 0.2 | 17 |
| [SML1064B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1064B50YY400MXXXX.pdf?_gl=1*18v1add*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1064nm | 1064 | 400 | 800 | 1.7 | 70 | 0.2 | 17 |
| [SML1064B50YY600MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1064B50YY600MXXXX.pdf?_gl=1*18v1add*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1064nm | 1064 | 600 | 1000 | 1.8 | 70 | 0.2 | 17 |
| [SML1064B50YY670MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1064B50YY670MXXXX.pdf?_gl=1*c91grn*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1064nm | 1064 | 670 | 1100 | 1.9 | 70 | 0.2 | 17 |
| [SML1080B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1080B50YY400MXXXX.pdf?_gl=1*c91grn*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1080nm | 1080 | 400 | 800 | 1.7 | 70 | 0.2 | 17 |
| [SML1100B50YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1100B50YY400MXXXX.pdf?_gl=1*r4zxhg*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1100nm | 1100 | 400 | 800 | 1.6 | 80 | 0.2 | 17 |
| [SML1120B50YY600MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1120B50YY600MXXXX.pdf?_gl=1*17309f9*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1120nm | 1120 | 600 | 1100 | 1.7 | 80 | 2 | 17 |
| [SML1125005YY400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1125005YY400MXXXX.pdf?_gl=1*16orme9*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1125nm | 1125 | 400 | 900 | 1.6 | 80 | 4 | 17 |
| [SML1140005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1140005YY500MXXXX.pdf?_gl=1*16orme9*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1140nm | 1140 | 500 | 1200 | 1.6 | 70 | 4.5 | 18 |
| [SML1155005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1155005YY350MXXXX.pdf?_gl=1*5my4zn*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1155nm | 1155 | 350 | 1200 | 1.6 | 180 | 4.5 | 18 |
| [SML1155005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1155005YY500MXXXX.pdf?_gl=1*kcrn3*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1155nm | 1155 | 500 | 1500 | 1.7 | 180 | 5 | 18 |
| [SML1155005YY600MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1155005YY600MXXXX.pdf?_gl=1*kcrn3*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1155nm | 1155 | 600 | 1500 | 1.85 | 100 | 5 | 18 |
| [SML1180005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1180005YY350MXXXX.pdf?_gl=1*13tfm6l*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1180nm | 1180 | 350 | 900 | 1.6 | 100 | 4.5 | 18 |
| [SML1180005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1180005YY500MXXXX.pdf?_gl=1*13tfm6l*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1180nm | 1180 | 500 | 1200 | 1.75 | 100 | 4.5 | 18 |
| [SML1190005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1190005YY500MXXXX.pdf?_gl=1*1hxx756*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1195nm | 1195 | 500 | 1200 | 1.6 | 110 | 4.5 | 18 |
| [SML1190005YY700MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1190005YY700MXXXX.pdf?_gl=1*m5wwp4*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1195nm | 1195 | 700 | 1700 | 1.75 | 110 | 5.5 | 18 |
| [SML1195005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1195005YY500MXXXX.pdf?_gl=1*m5wwp4*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1195nm | 1195 | 500 | 1200 | 1.6 | 110 | 4.5 | 18 |
| [SML1195005YY700MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1195005YY700MXXXX.pdf?_gl=1*rk0ma8*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1195nm | 1195 | 700 | 1700 | 1.75 | 110 | 5.5 | 18 |
| [SML1200005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1200005YY500MXXXX.pdf?_gl=1*rk0ma8*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1200nm | 1200 | 500 | 1200 | 1.6 | 110 | 4.5 | 18 |
| [SML1200005YY700MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1200005YY700MXXXX.pdf?_gl=1*rk0ma8*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1200nm | 1200 | 700 | 1700 | 1.75 | 110 | 5.5 | 18 |
| [SML1210005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1210005YY350MXXXX.pdf?_gl=1*6fml8t*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1210nm | 1210 | 350 | 900 | 1.5 | 100 | 4.5 | 18 |
| [SML1210005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1210005YY500MXXXX.pdf?_gl=1*16xgtf3*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1210nm | 1210 | 500 | 1200 | 1.7 | 100 | 4.5 | 18 |
| [SML1215005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1215005YY350MXXXX.pdf?_gl=1*16xgtf3*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1215nm | 1215 | 350 | 900 | 1.6 | 150 | 4 | 18 |
| [SML1240005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1240005YY350MXXXX.pdf?_gl=1*1nqpymg*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1240nm | 1240 | 350 | 900 | 1.6 | 100 | 4 | 18 |
| [SML1240005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1240005YY500MXXXX.pdf?_gl=1*1nqpymg*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1240nm | 1240 | 500 | 1200 | 1.6 | 100 | 5 | 18 |
| [SML1240005YY700MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1240005YY700MXXXX.pdf?_gl=1*p7fdd6*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1240nm | 1240 | 700 | 1700 | 1.8 | 100 | 6 | 18 |
| [SML1260005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1260005YY350MXXXX.pdf?_gl=1*p7fdd6*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1260nm | 1260 | 350 | 1000 | 1.6 | 120 | 4.5 | 18 |
| [SML1260005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1260005YY500MXXXX.pdf?_gl=1*l85tmu*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1260nm | 1260 | 500 | 1500 | 1.8 | 120 | 5 | 18 |
| [SML1270005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1270005YY350MXXXX.pdf?_gl=1*l85tmu*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1270nm | 1270 | 350 | 1000 | 1.6 | 100 | 5 | 18 |
| [SML1270005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1270005YY500MXXXX.pdf?_gl=1*1hk5dpg*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1270nm | 1270 | 500 | 1500 | 1.7 | 100 | 5.5 | 18 |
| [SML1300005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1300005YY350MXXXX.pdf?_gl=1*1336b43*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1300nm | 1300 | 350 | 1200 | 1.7 | 150 | 5 | 18 |
| [SML1300005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1300005YY500MXXXX.pdf?_gl=1*e2k9t*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1300nm | 1300 | 500 | 1500 | 1.95 | 150 | 6 | 18 |
| [SML1310005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1310005YY350MXXXX.pdf?_gl=1*18hdq57*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1310nm | 1310 | 350 | 1200 | 1.7 | 150 | 5 | 18 |
| [SML1310005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1310005YY500MXXXX.pdf?_gl=1*18hdq57*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1310nm | 1310 | 500 | 1500 | 1.85 | 150 | 6 | 18 |
| [SML1320005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1320005YY350MXXXX.pdf?_gl=1*cpz1ix*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1320nm | 1320 | 350 | 1200 | 1.7 | 150 | 5 | 18 |
| [SML1320005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1320005YY500MXXXX.pdf?_gl=1*kakk5w*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1320nm | 1320 | 500 | 1500 | 1.95 | 150 | 6 | 18 |
| [SML1330005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1330005YY350MXXXX.pdf?_gl=1*1bwk8j*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1330nm | 1330 | 350 | 1200 | 1.7 | 150 | 5 | 18 |
| [SML1330005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1330005YY500MXXXX.pdf?_gl=1*1232u8h*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1330nm | 1330 | 500 | 1500 | 1.95 | 150 | 6 | 18 |
| [SML1340005YY350MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1340005YY350MXXXX.pdf?_gl=1*185aenx*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1340nm | 1340 | 350 | 1200 | 1.7 | 150 | 5 | 18 |
| [SML1340005YY500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1340005YY500MXXXX.pdf?_gl=1*55jj33*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | Fiber-coupled single-mode laser diode at 1340nm | 1340 | 500 | 1500 | 1.9 | 150 | 6 | 18 |
### ■ パルス
|     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | タイプ | ピーク波長(nm) | 最大出力(mW) | ピーク順電流(mA) | パルス幅(ns) | スペクトル幅 (3dB)nm | 偏光消光比 (dB) |
| [DFB10XX000YY0D3PGXXX]( | Fiber-coupled pulsed DFB laser diode at 1064nm | DFB | 1020 – 1080 | 300 | 2000 | 0.05 | – | 18 |
| [SML1030003YY001PXXXX]( | Fiber-coupled single-mode pulsed laser at 1030nm | Fabry-Perot | 1030 | 1000 | 2000 | 500 | 1.5 | 18 |
| [SML1055003YY001PXXXX]( | Fiber-coupled single-mode pulsed laser at 1055nm | Fabry-Perot | 1055 | 1000 | 2000 | 500 | 1.6 | 19 |
| [SML1060003YY001PXXXX]( | Fiber-coupled single-mode pulsed laser at 1060nm | Fabry-Perot | 1060 | 1000 | 2000 | 500 | 1.5 | 17 |
| [SML1064003YY001PXXXX]( | Fiber-coupled single-mode pulsed laser at 1064nm | Fabry-Perot | 1064 | 1000 | 2000 | 500 | 2.7 | 19 |
| [SML1064003YY0D6PXXXX]( | Fiber-coupled single-mode pulsed laser at 1064nm | Fabry-Perot | 1064 | 600 | 1200 | 500 | 1.6 | 19 |
| [SML1080003YY0D6PXXXX]( | Fiber-coupled single-mode pulsed laser at 1080nm | Fabry-Perot | 1080 | 600 | 1200 | 500 | 1.8 | 19 |
| [SML1100003YY001PXXXX]( | Fiber-coupled single-mode pulsed laser at 1100nm | Fabry-Perot | 1100 | 1000 | 2000 | 500 | 2.8 | 19 |
| [SML1100003YY0D6PXXXX]( | Fiber-coupled single-mode pulsed laser at 1100nm | Fabry-Perot | 1100 | 600 | 1200 | 500 | 1.6 | 18 |
### ■ FBGレーザー
|     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | 平均波長(nm) | 出力(mW) | 順電流(mA) | 順電圧(V) | 閾値電流(mA) | スペクトル幅 (3dB)nm | 偏光消光比(dB) |
| [FBA102YB08PM400MXXXX]( | FBG laser diode at 1018 – 1022nm in BTF-package | 1018 – 1022 | 400 | 800 | 1.7 | 70 | 0.08 | 17 |
| [FBA103YB08PM400MXXXX]( | FBG laser diode at 1024 – 1032nm in BTF-package | 1024 – 1032 | 400 | 800 | 1.7 | 70 | 0.08 | 17 |
| [FBA105YB08PM400MXXXX]( | FBG laser diode at 1040 – 1054nm in BTF-package | 1040 – 1054 | 400 | 800 | 1.8 | 70 | 0.08 | 17 |
| [FBA106YB08PM400MXXXX]( | FBG laser diode at 1055 – 1066nm in BTF-package | 1055 – 1066 | 400 | 800 | 1.7 | 80 | 0.08 | 17 |
| [FBB106YB06PM300MXXXX]( | FBG laser diode at 1058 – 1070nm in BTF-package | 1058 – 1070 | 300 | 600 | 1.8 | 40 | 0.06 | 17 |
| [FBA108YB08PM400MXXXX]( | FBG laser diode at 1075 – 1085nm in BTF-package | 1075 – 1085 | 400 | 800 | 1.7 | 60 | 0.08 | 17 |
| [FBA109YB08PM400MXXXX]( | FBG laser diode at 1086 – 1095nm in BTF-package | 1086 – 1095 | 400 | 800 | 1.8 | 60 | 0.08 | 17 |
| [FBA110YB10PM400MXXXX]( | FBG laser diode at 1095 – 1105nm in BTF-package | 1095 – 1105 | 400 | 800 | 1.7 | 60 | 0.1 | 17 |
| [FBB1122B06PM300MXXXX]( | FBG laser diode at 1120 – 1122nm in BTF-package | 1120 – 1122 | 300 | 700 | 1.6 | 40 | 0.06 | 17 |
| [FBB1122B07PM450MXXXX]( | FBG laser diode at 1120 – 1122nm in BTF-package | 1120 – 1122 | 450 | 1200 | 1.7 | 80 | 0.07 | 17 |
| [FBB1126B06PM300MXXXX]( | FBG laser diode at 1125 – 1126nm in BTF-package | 1125 – 1126 | 300 | 700 | 1.6 | 40 | 0.06 | 17 |
| [FBB1130B06PM300MXXXX]( | FBG laser diode at 1130nm in BTF-package | 1130 | 300 | 700 | 1.6 | 40 | 0.06 | 17 |
| [FBA114YB40PM350MXXXX]( | FBG laser diode at 1130 – 1150nm in BTF-package | 1130 – 1150 | 350 | 1000 | 1.6 | 60 | 0.4 | 18 |
| [FBA114YB40PM500MXXXX]( | FBG laser diode at 1130 – 1150nm in BTF-package | 1130 – 1150 | 500 | 1200 | 1.6 | 60 | 0.4 | 18 |
| [FBA118YB40PM350MXXXX]( | FBG laser diode at 1170 – 1185nm in BTF-package | 1170 – 1185 | 350 | 1000 | 1.6 | 150 | 0.4 | 18 |
| [FBA118YB40PM500MXXXX]( | FBG laser diode at 1170 – 1185nm in BTF-package | 1170 – 1185 | 500 | 1200 | 1.8 | 150 | 0.4 | 18 |
| [FBA119YB40PM350MXXXX]( | FBG laser diode at 1180 – 1195nm in BTF-package | 1180 – 1195 | 350 | 1000 | 1.6 | 150 | 0.4 | 18 |
| [FBA119YB40PM500MXXXX]( | FBG laser diode at 1180 – 1195nm in BTF-package | 1180 – 1195 | 500 | 1200 | 1.7 | 150 | 0.4 | 18 |
| [FBA120YB40PM350MXXXX]( | FBG laser diode at 1190 – 1205nm in BTF-package | 1190 – 1205 | 350 | 1000 | 1.6 | 150 | 0.4 | 18 |
| [FBA120YB40PM500MXXXX]( | FBG laser diode at 1190 – 1205nm in BTF-package | 1190 – 1205 | 500 | 1200 | 1.7 | 150 | 0.4 | 18 |
| [FBA121YB40PM350MXXXX]( | FBG laser diode at 1200 – 1215nm in BTF-package | 1200 – 1215 | 350 | 1000 | 1.6 | 150 | 0.4 | 18 |
| [FBA121YB40PM500MXXXX]( | FBG laser diode at 1200 – 1215nm in BTF-package | 1200 – 1215 | 500 | 1200 | 1.7 | 150 | 0.4 | 18 |
| [FBA122YB40PM350MXXXX]( | FBG laser diode at 1215 – 1225nm in BTF-package | 1215 – 1225 | 350 | 1000 | 1.6 | 150 | 0.4 | 18 |
| [FBA122YB40PM500MXXXX]( | FBG laser diode at 1215 – 1225nm in BTF-package | 1215 – 1225 | 500 | 1200 | 1.7 | 150 | 0.4 | 18 |
| [FBA124YB40PM350MXXXX]( | FBG laser diode at 1230 – 1250nm in BTF-package | 1230 – 1250 | 350 | 1000 | 1.7 | 80 | 0.4 | 18 |
| [FBA124YB40PM500MXXXX]( | FBG laser diode at 1230 – 1250nm in BTF-package | 1230 – 1250 | 500 | 1200 | 1.8 | 80 | 0.4 | 18 |
| [FBA126YB40PM350MXXXX]( | FBG laser diode at 1255 – 1270nm in BTF-package | 1255 – 1270 | 350 | 1200 | 1.7 | 100 | 0.4 | 18 |
| [FBA126YB40PM500MXXXX]( | FBG laser diode at 1255 – 1270nm in BTF-package | 1255 – 1270 | 500 | 1500 | 1.8 | 100 | 0.4 | 18 |
| [FBA127YB40PM350MXXXX]( | FBG laser diode at 1270 – 1280nm in BTF-package | 1270 – 1280 | 350 | 1200 | 1.7 | 100 | 0.4 | 18 |
| [FBA127YB40PM500MXXXX]( | FBG laser diode at 1270 – 1280nm in BTF-package | 1270 – 1280 | 500 | 1500 | 1.8 | 100 | 0.4 | 18 |
| [FBA128YB40PM350MXXXX]( | FBG laser diode at 1270 – 1280nm in BTF-package | 1270 – 1280 | 350 | 1200 | 1.7 | 100 | 0.4 | 18 |
| [FBA128YB40PM500MXXXX]( | FBG laser diode at 1275 – 1285nm in BTF-package | 1275 – 1285 | 500 | 1500 | 1.8 | 100 | 0.4 | 18 |
| [FBA130YB40PM350MXXXX]( | FBG laser diode at 1290 – 1305nm in BTF-package | 1290 – 1305 | 350 | 1200 | 1.8 | 130 | 0.4 | 17 |
| [FBA130YB40PM500MXXXX]( | FBG laser diode at 1290 – 1305nm in BTF-package | 1290 – 1305 | 500 | 1500 | 1.9 | 130 | 0.4 | 17 |
| [FBA131YB40PM500MXXXX]( | FBG laser diode at 1305 – 1320nm in BTF-package | 1305 – 1320 | 500 | 1800 | 1.9 | 150 | 0.4 | 17 |
| [FBA131YB40PM350MXXXX]( | FBG laser diode at 1305 – 1320nm in BTF-package | 1305 – 1320 | 350 | 1200 | 1.8 | 150 | 0.4 | 17 |
| [FBA132YB40PM350MXXXX]( | FBG laser diode at 1310 – 1330nm in BTF-package | 1310 – 1330 | 350 | 1200 | 1.8 | 150 | 0.4 | 17 |
| [FBA132YB40PM500MXXXX]( | FBG laser diode at 1310 – 1330nm in BTF-package | 1310 – 1330 | 500 | 1800 | 1.9 | 150 | 0.4 | 17 |
| [FBA134YB40PM350MXXXX]( | FBG laser diode at 1325 – 1345nm in BTF-package | 1325 – 1345 | 350 | 1200 | 1.8 | 150 | 0.4 | 17 |
| [FBA134YB40PM500MXXXX]( | FBG laser diode at 1325 – 1345nm in BTF-package | 1325 – 1345 | 500 | 1800 | 1.9 | 150 | 0.4 | 17 |
## 製品に関するお問い合わせ
この製品のお問い合わせ