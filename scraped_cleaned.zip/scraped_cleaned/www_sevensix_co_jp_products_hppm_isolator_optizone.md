# Source URL: https://www.sevensix.co.jp/products/hppm_isolator_optizone/

# 
# 高出力偏波保持アイソレータ
波長: 850 ~ 2000nm　入力パワー: 300mW ~ 30W
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- PMアイソレータ
- 光ファイバアイソレータ
中国の深センに拠点を構えるOptizone Technologiesの高出力偏波保持アイソレータです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- 高アイソレーション
- 高消光比
#### **用途**
- 光ファイバ増幅器
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 850m、980nm、1030nm、1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可 |
| 入力パワー | 300mW、500mW、1W、2W、3W、5W、10W、20W、30W、その他も対応可 |
| 光軸アライメント | Fast Axis Blocked、Both Axis Working |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
#### **パッケージタイプ**
標準サイズ
 Type A43 / B43
Type C40
 Type C5
 Type C6
## 資料ダウンロード
- [データシート：850nm High Power Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-016G-HPMI-850nm-Type-C40-300mW.pdf#view=Fit)
- [データシート：980nm High Power Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-006I-HPMI-980nm-Type-C40-1W.pdf#view=Fit)
- [データシート：1064nm High Power Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-064D-HPMI-06-A43-01-F-NN-CC-1-1-1.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm High Power Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-008E-HPMI-1310nm1550nm-1W10W.pdf#view=Fit)
- [データシート：2000nm High Power Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/SR2002006B-HPMI-2000-S-05-F-NN-BB-D5-0.75-08-1.pdf#view=Fit)
- [データシート：1064nm 500mW、1W Polarization Maintaining Isolator (Ultra-Fast Fiber Lasers)](https://www.sevensix.co.jp/wp-content/uploads/CAT-011-003B-PMI-for-Ultra-Fast-Fiber-Lasers1064nmn.pdf#view=Fit)
- [データシート：1064nm 1W、2W Polarization Maintaining Isolator (Ultra-Fast Fiber Lasers)](https://www.sevensix.co.jp/wp-content/uploads/1e5c75bbee8b2be9cf0164ea8a2f2bba.pdf#view=Fit)
- [データシート：1064nm 1W、5W、10W、20W、30W Polarization Maintaining Isolator (Ultra-Fast Fiber Lasers)](https://www.sevensix.co.jp/wp-content/uploads/32ee0748c5ffaf8e34fa60ef7ee55cea.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ