# Source URL: https://www.sevensix.co.jp/products/pd_coherent/

# 
# 超広帯域フォトディテクタ
DC ~ 100GHzの広帯域 (cut-off周波数3dB)
_メーカ：_ Coherent (旧 II-VI)
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- フォトダイオード(PD)
- PD
Ⅱ-Ⅵの超広帯域フォトディテクタは、DC～100GHzの広い帯域(cut-off周波数3dB)でリニアな周波数応答特性と高い同窓信号除去比(common mode rejection ratio)を保証する業界屈指のソリューションです。コヒーレント通信、光ファイバ無線(RF over Fiber)、レーダ、測定器、マイクロウェイブ・フォトニクス等の様々な分野で活用されています。
製品のお問い合わせ･お見積
## 特長
- DC～100GHzの広い帯域(cut-off周波数3dB)
- リニアな周波数応答特性と高い同窓信号除去比(common mode rejection ratio)
## 用途
- 光アクセス
- 光ファイバセンシング
- 基幹系インフラ
- 通信
### ■ プロダクト・ポートフォリオ
### ■　Single Photo Detectorシリーズ
|     |     |     |     |
| --- | --- | --- | --- |
| 帯域(typ) | 1310nm<br>オプション | 型番 | 備考 |
| 50 GHz |  | [XPDV2120R]( |  |
| 35 GHz |  | [XPDV2120RA]( | ・ACカップル |
| 50 GHz |  | [XPDV2150R]( | ・Low PDLモデル |
| 50 GHz | 〇 | [XPDV2320R]( |  |
| 70 GHz |  | [XPDV3120R]( |  |
| 70 GHz | 〇 | [XPDV3320R]( |  |
| 90 GHz |  | [XPDV4120R]( |  |
| 100 GHz |  | [XPDV4121R]( |  |
### ■　Balanced Photo Detectorシリーズ
|     |     |     |     |
| --- | --- | --- | --- |
| 帯域(typ) | 1310nm<br>オプション | 型番 | 備考 |
| 43 GHz |  | [BPDV2120R]( | ・Singleのみ |
| 43 GHz |  | [BPDV2150R(M/Q)]( | ・Single/Dual/Quad<br>・Low PDLモデル |
| 70 GHz |  | [BPDV3120R(M/Q)]( | ・Single/Dual/Quad |
| 70 GHz | 〇 | [BPDV3320R]( | ・Singleのみ |
| 100 GHz |  | [BPDV4121R(Q)]( | ・Single/Dual/Quad |
### ■　High-Power Photo Detectorシリーズ
高RF出力で光ファイバ無線(RF over Fiber)やマイクロウェイブ・フォトニクスに最適の製品です。
|     |     |     |     |
| --- | --- | --- | --- |
| 帯域(typ) | 1310nm<br>オプション | 型番 | 備考 |
| 50 GHz |  | [HPDV2120R]( |  |
| 20 GHz |  | [VPDV2120]( |  |
| 18 GHz | 〇 | [XPRV2324A]( | limitingアンプ内蔵 |
| 30 GHz | 〇 | XPRV2325A | Linearアンプ内蔵、I2C I/F内蔵 |
### 解説・関連動画
▼II-VI（FINISAR）社製 100G/5G向け 超高速フォトディテクタ詳細情報│Vol.015
## 資料ダウンロード
- [カタログ：超広帯域フォトディテクタ](https://www.sevensix.co.jp/wp-content/uploads/II-VI-Coherent-and-Advanced-Photodetectors-and-Receivers.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ