# Source URL: https://www.sevensix.co.jp/products/ld878nm_bwt/

# 
# ファイバ付 高出力 半導体マルチモードレーザー
波長: 878.6 ~ 888nm　出力 30 ~ 170W
_メーカ：_ BWT Beijing LTD.
- 半導体レーザーダイオード（LD）
- ポンプLD
- MMファイバ
- ファブリペローレーザー
✓ 高出力波長安定化ファイバ結合ダイオードレーザー
✓ 出力最大170W対応
✓ 全製品RoHS・REACH 規制物質に対応
製品のお問い合わせ･お見積
## 特長
- 878.6nmVBG品or888nmで選択可能
- 高効率、安定性、優れたビーム品質で固体レーザーの励起に最適
## 用途
- 固体レーザー励起
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| 製品名 | 型式 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| 878.6nm 30W Wavelength-Stabilized<br>Fiber Coupled Diode Laser | [K878BAHRN-30.00W]( | 878.6 | 30 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 65W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BNLRN-65.00W]( | 878.6 | 65 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 120W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BL9RN-120.0W]( | 878.6 | 120 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 170W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BL9RN-170.0W]( | 878.6 | 170 | 200 | 0.22 | 固体レーザー増幅 |
| 888nm 120W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K888BL9RN-120.0W]( | 888 | 120 | 200 | 0.22 | 固体レーザー増幅 |
| 888nm 170W High Power Wavelength-<br>Stabilized Fiber Coupled Diode Laser | [K888BL9RN-170.0W]( | 888 | 170 | 200 | 0.22 | 固体レーザー増幅 |
## 製品に関するお問い合わせ
この製品のお問い合わせ