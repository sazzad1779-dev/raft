# Source URL: https://www.sevensix.co.jp/products/octsc_nktp/

# 
# OCT用 広帯域 白色レーザー光源 最上位モデル『SuerK FIANIUM OCT』
可視光出力: 600 ~ 900 mW
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 広帯域白色レーザー光源
超高分解能 OCT 用にデザインした 白色スーパーコンティニュームレーザー『SuperK FIANIUM OCT』。
製品のお問い合わせ･お見積
## ◆　『SuerK FIANIUM OCT』 製品概要
OCT用にデザインされた広帯域・低雑音なSupercontinuum レーザーである SuerK FIANIUM OCTをご紹介します。
SuperK FIANIUM OCT は SuperK FIANIUM と同等の特性、操作性を有しながら、OCTに必要な感度を
達成するために雑音を低減した Supercontinuum レーザーです。
SuperK FIANIUM OCT を広帯域のスペクトロメータを組み合わせることで、Ti:Sapphire レーザーベースの OCT と同等のOCT断層像を得ることができます。一方で、SuerK FIANIUM OCT はオールファイバベースの光源であるため、Ti:SapphireレーザーベースのOCTと比べて、ローコスト、小型、可搬性があり堅牢なOCTシステムを構築できます。
## 特長
- 低ノイズ
- 平均光出力 600 – 900 mW @ 350 – 850 nm
- M2 < 1.1
- 堅牢メンテナンスフリー
- >10,000時間に及ぶ長寿命
SuperK FIANIUM OCT FIU-6 OCT / FIR-9 OCT のスペクトル
## 仕様詳細
SuperK FIANIUM OCT には、スペクトル形状が異なる FIU-6 OCT、FIR-9 OCTの 2種類をご用意いたしております。
中心波長 840 nm のOCTを構築される場合は FIR-9 OCTをお選び下さい。できるだけ短波長の可視光が必要な場合は FIU-6 OCT が最適です。
### 光学仕様
|     |     |     |
| --- | --- | --- |
|  | FIU-6 OCT | FIR-9 OCT |
| カットイン波長<br>(>0.1 mW/nm) | < 425 nm | < 640 nm |
| 全出力パワー | < 6.5 W | < 6.5 W |
| 可視光パワー(350-850 nm) | 600 mW | 900 mW |
| スペクトルパワー密度 | 0.5 mW/nm @ 450 nm<br>0.9 mW/nm @ 532 nm<br>1.2 mW/nm @ 650 nm<br>2.0 mW/nm @ 780 nm<br>1.6 mW/nm @ 800 nm | NA<br>NA<br>0.6 mW/nm @ 650 nm<br>3.2 mW/nm @ 780 nm<br>3.5 mW/nm @ 800 nm |
| 繰返し周波数 | 312 ± 3 MHz | 312 ± 3 MHz |
| 出力安定性 | < ± 0.5 % | < ± 0.5 % |
| 偏光 | ランダム偏光 | ランダム偏光 |
| ビーム品質 | 回折限界 | 回折限界 |
| 出力端 | コリメータ | コリメータ |
| ビーム径 <br>(コリメータビーム) | 1 mm @ 530 nm<br>2 mm @ 1100 nm<br>3 mm @ 2000 nm | 1 mm @ 530 nm<br>2 mm @ 1100 nm<br>3 mm @ 2000 nm |
### 機械 / 電気 / 環境 仕様
|     |     |
| --- | --- |
| 冷却方法 | 空冷 |
| 稼働電圧 | 100-240 VAC, 50-60 Hz |
| 消費電力 | < 100 W |
| コンピュータインターフェース | USB |
| ドアインターロックコネクタ | 2-pin LEMO |
| 外部busコネクタ | 16-pin D-sub |
| ファイバ長 | 1.5m |
| 寸法（WxHxL） | 440 x 251 x 400  mm |
| 重量 | 18 kg |
| 使用温度 | 18 ~ 30 °C |
| 保管温度 | ー10 ~ 55°C |
SuperK FIANIUM OCTは、最も低雑音な Supercontinuum レーザーです。この低雑音な Supercontinuum レーザーをOCTの光源としてお使いいただくことにより、深さ方向分解能が 1 – 2 um の高分解能でありながらも、高コントラストで低雑音なOCTイメージを取得することができます。
SuerK FIANIUM OCT は、 Wasatch Photonics社の OCT用広帯域分光器 Cobra シリーズ 等と一緒に
お使いいただけます。
分光OCT、Autofluorescence OCT、ドップラーOCT、SLOと組み合わせたOCT などマルチモダリティなOCT の開発に最適です。
SuperK FIANIUM OCT FIU-6 OCT / FIR-9 の相対強度雑音 (RIN)
標準品は コリメータ出力となり、 NKT Photonics が提供している様々なフィルタアクセサリと組み合わせるこで
必要な光波長成分だけを使うことできます（フィルタアクセサリの詳細については こちら をご覧ください)。
これらのアクセサリは、NKT Photonicsが無償提供している GUI CONTROL software を用いて制御するか、NKT Photonics が無償配布している各種言語のソフトウェア開発キット (Software Development Kit) を用いた
自作プログラムにより制御することができます。
## 用途
- 光コヒーレンストモグラフィ
- 白色干渉系
- マルチモダリティOCT 用途
下図は、Medical University Vienna 、Prof. Dr. Wolfgang Drexlers の研究グループの Angelika Unterhuber 氏 が取得した 人の眼 のOCTイメージです。左側が Ti:Sapphireレーザーを用いて取得したOCTイメージ、右側が SuperK FIANIUM OCT を用いて取得した OCTイメージです。
### 参考文献：Supercontinuum レーザーのOCT応用
Supercontinuum レーザーのOCT用途に関する研究論文を下記にご紹介します。
| 無料公開（論文） | Minshan Jiang, Tan Liu, Xiaojing Liu, and Shuliang Jiao, “ Simultaneous optical coherence tomography and lipofuscin autofluorescence imaging of the retina with a single broadband light source at 480nm,” Biomed. Opt. Express **5**, 4242-4248 (2014) |
| 無料公開（論文） | Ji Yi, Siyu Chen, Vadim Backman, and Hao F. Zhang, “ In vivo functional microangiography by visible-light optical coherence tomography,” Biomed. Opt. Express **5**, 3603-3612 (2014) |
| 無料公開（論文） | Yi, Ji et al. “ Spatially Resolved Optical and Ultrastructural Properties of Colorectal and Pancreatic Field Carcinogenesis Observed by Inverse Spectroscopic Optical Coherence Tomography,” _Journal of Biomedical Optics_ 19.3 (2014) |
| 無料公開（論文） | Francesco LaRocca, Derek Nankivil, Sina Farsiu, and Joseph A. Izatt, “ True color scanning laser ophthalmoscopy and optical coherence tomography handheld probe,” Biomed. Opt. Express **5**, 3204-3216 (2014) |
| 無料公開（オリジナル記事） | Visible light optical coherence tomography measures retinal oxygen metabolic response to systemic oxygenation (2015) |
## 資料ダウンロード
- [データシート：SuperK FIANIUM OCT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-FIANIUM-OCT-Datasheet.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ