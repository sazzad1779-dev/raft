# Source URL: https://www.sevensix.co.jp/products/110ghz-phase_modulator-hyperlight/

# 
# 薄膜LN 110GHz 光位相変調器
C / L-band
_メーカ：_ HyperLight
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光変調器
- 位相変調器
従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現する
薄膜LN方式の光変調器メーカ：Hyperlight社の110GHz 光位相変調器です。
Low VπモデルとRegular Vπモデルの2タイプがございます。
製品のお問い合わせ･お見積
## 特長
- \> 110 GHz bandwidth
- Low Vπ
- 1.0mm RF connector(W)
- Low Vπ model and Regular Vπ model support
- C/L-band support
## 用途
- Optical Computing
- Quantum communication
- Microwave photonics
- EO comb generation
### 解説・関連動画▼
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 5:30
•Live
•
## 資料ダウンロード
- [カタログ：薄膜LN 110GHz 光位相変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-110GHz-phase-modulator.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ