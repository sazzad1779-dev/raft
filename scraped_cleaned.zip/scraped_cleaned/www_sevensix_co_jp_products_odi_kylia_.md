# Source URL: https://www.sevensix.co.jp/products/odi_kylia/

# 
# 光遅延干渉計
波長: 1520 ~ 1570nm　光入力パワー: 300mW
_メーカ：_ Kylia Inc.
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光フィルタ
- 光遅延干渉計
MINTはマッハツェンダーの遅延線干渉計(DLI)です。WT-MINTは、100psから9nsまでの遅延範囲に対応したFSRチューニング可能なDLIです。
製品のお問い合わせ･お見積
## 特長
- PMファイバー対応可能
## 用途
- センシング / デバイス評価
## 仕様詳細
|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| パラメータ | 最小値 | 中央値 | 最大値 | 単位 | 備考 |
| 最大光入力パワー (OpIn) |  |  | 300 | mW |  |
| 保存温度範囲(STR) <br>MINT<br>WT-MINT | -40<br>-10 |  | 80<br>40 | ℃ |  |
| 湿度 (RH) | 5 |  | 85 | ％ | 非凝縮性 |
| ファイバー曲げ半径 | 20 |  |  | mm |  |
| 最大入力電圧(Vmax)<br>U option<br>L option |  |  | 100<br>4 | V |  |
| 動作波長 (OWR) | 1520 |  | 1570 | nm |  |
| 動作温度範囲(OTR)<br>MINT<br>WT-MINT | 0<br>10 |  | 70<br>35 | ℃ |  |
## 資料ダウンロード
- [光遅延干渉計　データシート](https://www.sevensix.co.jp/wp-content/uploads/datasheet-MINT-V12.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ