# Source URL: https://www.sevensix.co.jp/products/fplaserpm_3sp/

# 
# シード用ファブリペローレーザー (CW / Pulse) PMファイバ
波長: 1050 ~ 1070nm　出力: 400 ~ 500W
_メーカ：_ 3SP Technologies
- 半導体レーザーダイオード（LD）
- シードLD
- ファブリペローレーザー
✓ 1060 nm付近の高出力シングルモードレーザモジュール
✓ 最大500mWの動作電力
✓ 30 ns～500 ns のパルス動作
✓ 動作温度：75 °Cまで
✓ RoHS指令対応品
製品のお問い合わせ･お見積%20PM%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90)
## 特長
- 14ピンバタフライ型モジュール
- ピグテールファイバ – PMF
- TEC、NTCサーミスタ、モニタリングPDを内蔵
- Telcordia GR-468-CORE準拠
- MTTF > 100.000h
## 用途
- ラマン分光の励起光源
- パルス、CWのファイバレーザの種光源用
## 仕様詳細
### ■ 電気光学特性
### \*Tsubmount = 25 °C, Tcase = -5 °C to 75 °C, VBFM= -5 V and -50 dB max 背面反射で規定
## 資料ダウンロード
- [データシート：シード用ファブリペローレーザー (CW / Pulse) PMファイバ](https://www.sevensix.co.jp/wp-content/uploads/3SP-1064CHP%E2%91%A0.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%20PM%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90)
%20PM%E3%83%95%E3%82%A1%E3%82%A4%E3%83%90)