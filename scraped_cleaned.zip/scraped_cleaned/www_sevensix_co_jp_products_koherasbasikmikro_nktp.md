# Source URL: https://www.sevensix.co.jp/products/koherasbasikmikro_nktp/

# 
# OEM型 超低ノイズ 狭線幅 ファイバーレーザー『Koheras BASIK MIKRO』
波長: 1535 ~ 1580nm　出力: 40mW
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 狭線幅CWレーザー光源
『Koheras BASIK MIKRO』 は産業センシングシステムのOEM統合用に設計された業界で最も小型な産業向け単一周波数ファイバレーザです。
製品のお問い合わせ･お見積
### 特長
- OEM用途に適した小さな設置面積
- 低位相雑音と狭線幅
- 堅牢な単一周波数動作
- 高い波長安定性
- PM 出力、高速波長チューニングオプション
- センサへのOEM統合に最適
Koheras BASIK MIKRO は産業センシングシステムのOEM統合用に設計された業界で最も小型な産業向け単一周波数ファイバレーザです。Koheras BASIK MIKRO モジュールはレーザ制御回路が完全に統合されており、レーザの性能を継続的にモニタリングできます。
Koheras BASIK MIKRO は E15 のモデルのみあります。データシートで保証する光学的な性能は Koheras BASIK と Koheras MIKRO で全く同じとなっております。発振波長は 1535 – 1580 nm の範囲でお選びいただけますが、標準品の発振波長は 1550.12 nm です。
オプションでご用意しているUSBインタフェースキットと Koheras MIKRO をお使いいただくことで、NKT Photonicsが無料配布しているGUIである NKTP CONTROL ソフトウェア を用いて制御することができます。
Koheras BASIK シリーズとKoheras BASIK MIKROの違い
## 資料ダウンロード
- [データシート：Koheras BASIK MIKRO](https://www.sevensix.co.jp/wp-content/uploads/koheras-mikro-datasheet.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ