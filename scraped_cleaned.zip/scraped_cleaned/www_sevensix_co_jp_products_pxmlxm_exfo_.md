# Source URL: https://www.sevensix.co.jp/products/pxmlxm_exfo/

# 
# 多芯光ファイバ長/損失/極性測定器『PXM/LXM』
挿入損失、長さ、極性を2波長で1秒で測定
_メーカ：_ EXFO
- 光計測器
- パワーメータ
業界最速の試験速度を誇る、フル機能のデュプレックスおよび
多芯光ファイバ対応パワーメータ 兼 光源。
損失・極性・長さの測定と、内蔵された認証規格による
Tier-1デュプレックスおよび多芯ファイバの認証に対応。
製品のお問い合わせ･お見積
## 特長
- 12芯光ファイバーの挿入損失、長さ、極性を2波長で1秒で測定
- マルチモード850/1300nmおよびシングルモード1310/1550nm
- TIA/ISO/IECケーブル規格およびIEEEネットワークアプリケーションに準拠したオンボード規格認証
- TIA/IEC準拠の1コードリファレンス用大型ハイブリッド非接触MPOパワーメーターテストポート
- 光ファイバートレース用インライン可視障害探知器（VFL）
- トーン発生周波数：270Hz、330Hz、1kHz、2kHz
- 4インチカラータッチスクリーンとフィールド交換可能なリチウムイオンバッテリー
- LXM-PXM マルチファイバーOLTS
- CommScope 3 Oに供給
## 用途
- **AI supercomputer clusters**
AIスーパーコンピュータ・クラスター
- **Hyperscaler data centers**
ハイパースケーラー・データセンター
- **Enterprise**
エンタープライズ（企業向けシステム）
- **Private networks**
プライベートネットワーク（専用ネットワーク）
## 仕様
|     |     |
| --- | --- |
| **Technical specifications** |  |
| Automation<br>(自動機能) | あり |
| Calibrated wavelengths<br>(校正波長) | 850 / 1300 / 1310 / 1550 nm |
| Fiber connector type<br>(ファイバコネクタタイプ) | MPO / Duplex / LC / MDC / SN |
| Fiber type<br>(ファイバタイプ) | シングルモード / マルチモード |
| Measurement<br>(測定内容) | リンク損失 |
| Multiple wavelength measuring<br>(多波長測定) | あり |
| Visual Fault Locator, VFL<br>(可視光故障検出器) | あり |
## 関連動画
生成AIクラウド構築に潜む罠 【MPOコネクター編】│Vol.139
生成AIクラウドやデータセンターの高帯域ネットワークでは、MPOコネクタの需要が急増しています。 しかし品質管理が不十分なMPOコネクタを使用すると、反射減衰量不足やリンクダウンといった深刻なトラブルを招く可能性があります。
解決策① EXFO社の測定ソリューション（光損失テストセット）
MPOコネクタの多芯光ファイバの挿入損失、極性、ケーブル長を自動計測できるテストセットです。
MPO-12芯対応していますが、治具ケーブルを使用することでMPO-16芯、-24芯測定も可能です。2波長でMPO-12芯ケーブルを１秒で試験ができます。また、SMF、MMF対応しており、挿入損失測定、極性検査、ケーブル長測定が可能です。
生成AIクラウド構築に潜む罠 【MPOコネクター編】│Vol.139 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
生成AIクラウド構築に潜む罠 【MPOコネクター編】│Vol.139
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 9:30
•Live
•
## 資料ダウンロード
- [スペックシート：pxm-lxm\_spec-sheet\_v10（英語）](https://www.sevensix.co.jp/wp-content/uploads/pxm-lxm_spec-sheet_v10_en.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ