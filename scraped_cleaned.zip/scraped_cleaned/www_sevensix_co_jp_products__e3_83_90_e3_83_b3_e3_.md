# Source URL: https://www.sevensix.co.jp/products/%e3%83%90%e3%83%b3%e3%83%89%e3%83%91%e3%82%b9%e3%83%95%e3%82%a3%e3%83%ab%e3%82%bf-%e6%b3%a2%e9%95%b7-1064-1565nm-optizone/

# 
# バンドパスフィルタ
波長: 1064 ~ 1565nm　バンド幅: 5 / 37nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- その他光ファイバ部品
中国の深センに拠点を構えるOptizone Technologiesのバンドパスフィルタです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間20,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 高分離
- 低挿入損失
- ハイリターンロス
## 用途
- レーザ
- 増幅機能
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 1064nm、1528nm～1565nm、その他も対応可 |
| バンド幅 | 5nm、37nm、その他も対応可 |
| ストップバンド幅 | 22nm、53nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |
## 資料ダウンロード
- [データシート：1064nm Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/BPF-1064nm-CAT-04-002C.pdf#view=Fit)
- [データシート：1528nm～1565nm SMF Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/BPF-CAT-04-003D.pdf#view=Fit)
- [データシート：1528nm～1565nm PM Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/PMBPF-2865nm-CAT-09-043C.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ