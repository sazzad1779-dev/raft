# Source URL: https://www.sevensix.co.jp/products/dfb_3sp/

# 
# DFB レーザーチップオンサブマウント型
波長: 1529 ~ 1570nm　出力: 20mW
_メーカ：_ 3SP Technologies
- 半導体レーザーダイオード（LD）
- シードLD
- DFBレーザー
✓ 1550 nm DFB レーザー用チップ
✓ C-Band (1529nm - 1570nm) 対応
✓ BRS構造は、有機金属気相成長法（MOVPE）採用
製品のお問い合わせ･お見積
## 特長
- 出力電力：20mW、40mW、60mW
- C -Band(1529nm – 1570nm)、波長間隔：50GHz
- 低いビーム発散
- Telcordia GR-468-CORE認定 済
## 用途
- CWオペレーション&HF帯（2.5GHzまで）
- テレコムTDMおよびDWDM
- 計測機器
## 仕様詳細
### ■ 電気光学特性
## 資料ダウンロード
- [データシート：DFB レーザチップ サブマウント型](https://www.sevensix.co.jp/wp-content/uploads/3SP%E3%80%80%E3%83%AC%E3%83%BC%E3%82%B6%E3%83%BC%E3%83%81%E3%83%83%E3%83%97-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ