# Source URL: https://www.sevensix.co.jp/products/opal-md_exfo/

# 
# OPAL-MD：フォトニック集積回路 (PIC) 向け自動プローブステーション​
_メーカ：_ EXFO
- 光計測器
- 光コンポーネント・テスタ
- その他
EXFO社のOPAL-MDは、複数のダイ (マルチダイ) を対象としたフォトニック集積回路 (PIC) 向け自動プローブステーションです。
ウェーハおよびダイレベルのテストを自動化し、高精度なファイバアライメントと迅速な測定を可能にします。
研究開発から生産ラインまで幅広く対応できるソリューションです。
製品のお問い合わせ･お見積%20%E5%90%91%E3%81%91%E8%87%AA%E5%8B%95%E3%83%97%E3%83%AD%E3%83%BC%E3%83%96%E3%82%B9%E3%83%86%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E2%80%8B)
## 特長
- マルチダイ測定に対応し、生産効率を向上
- 高精度な自動アライメント機能で測定の再現性を確保
- 透過率、反射率、偏波依存損失（PDL）、波長分散などの多様な測定に対応
- 直感的なソフトウェア制御で、操作性とデータ管理を最適化
- EXFOの光測定機器とシームレスに統合可能
EXFO社の 光スペクトラムアナライザー、 パワーメーター との組み合わせで最適な測定環境を実現
## 用途
- 光通信向けフォトニック集積回路（PIC）の量産評価
- シリコンフォトニクスデバイスの研究開発および生産ラインテスト
- 光モジュール・光トランシーバの高精度測定
## 使用詳細
## 関連動画
▼ Introducing the OPAL-MD, probe station for multi-die testing
Introducing the OPAL-MD, probe station for multi-die testing - YouTube
Photo image of EXFO Tube
EXFO Tube
15.3K subscribers
Introducing the OPAL-MD, probe station for multi-die testing
EXFO Tube
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 1:53
•Live
•
## 資料ダウンロード
- [データシート：フォトニック集積回路 (PIC) 向け自動プローブステーション​【OPAL-MD】](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_opal-md_v1_ja.pdf#view=Fit)
- [技術紹介資料：大学・研究機関向け光学測定ソリューション (EN)](https://www.sevensix.co.jp/wp-content/uploads/a7c2460031db9c16882c51b5388725a8.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%20%E5%90%91%E3%81%91%E8%87%AA%E5%8B%95%E3%83%97%E3%83%AD%E3%83%BC%E3%83%96%E3%82%B9%E3%83%86%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E2%80%8B)
%20%E5%90%91%E3%81%91%E8%87%AA%E5%8B%95%E3%83%97%E3%83%AD%E3%83%BC%E3%83%96%E3%82%B9%E3%83%86%E3%83%BC%E3%82%B7%E3%83%A7%E3%83%B3%E2%80%8B)
## 関連製品
(1/2)
- 光パワーメータ『PX-1』 - 多機能な汎用光パワーメータEXFO光計測器
- CWDM/DWDMネットワーク用光スペクトラムアナライザ『FTBx-5235』 - 波長: 1270 ~ 1610nm　周波数: 50GHz / 100GHzEXFO光計測器
- 光コンポーネントテスタ『CTP10』 - IL / RL / PDL 測定評価用EXFO光計測器
- PIC(光集積回路)テストソリューション - 測定したい光集積回路をカスタマイズEXFO光計測器
- OPAL-EC：フォトニック集積回路 (PIC) 向けエッジカップリング自動プローブステーション - EXFO光計測器