# Source URL: https://www.sevensix.co.jp/products/800g_transceiver_coherent/

# 
# 800G ZR/ZR+ QSFP-DD DCO 光トランシーバ
OIF800ZR/OpenZR+対応、C/L-band対応、High Tx power対応
_メーカ：_ Coherent (旧 II-VI)
- 光通信/ 同軸・RF関連
- 光トランシーバ
OIF800ZR、OpenZR+ MSAに対応したデジタルコヒーレント光トランシーバです。
独自のInP+SOAを基盤とした構成を採用、SiP+EDFA基盤の構成に比べて集積化が容易でシンプル構成です。
C-band及びL-bandの波長に対応、High Tx Powerモデルもサポートしております。
製品のお問い合わせ･お見積
## 特長
- 独自のInP+SOA技術採用 集積化/シンプル構成
- C-band/L-band 対応
- High Tx Power 0 dBm 対応
- QSFP-DD/OSFP対応
- 低消費電力 <28W@OIF800ZR, <31W@OpenZR+
- 様々な変調フォーマットをサポート
## 用途
Data Center Interconnect, Telecom network, Mobile Network
## 資料ダウンロード
- [カタログ：800G ZR/ZR+ QSFP-DD DCO 光トランシーバ](https://www.sevensix.co.jp/wp-content/uploads/non-NDAFTCE33x6R1PCL-800G-QSFP-DD-DCO-ZR-vA01.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ