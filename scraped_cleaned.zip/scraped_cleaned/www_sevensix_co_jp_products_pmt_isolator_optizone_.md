# Source URL: https://www.sevensix.co.jp/products/pmt_isolator_optizone/

# 
# 偏波保持タップアイソレータ
波長: 1064 ~ 1590nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- PMアイソレータ
- 光ファイバアイソレータ
中国の深センに拠点を構えるOptizone Technologiesの偏波保持タップアイソレータです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- 低偏波依存性損失
#### **用途**
- ファイバレーザ
- アンプ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 1064nm、1310nm、1480nm、1550nm、1590nm |
| ステージ | シングル、デュアル |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| 光軸アライメント | Fast Axis Blocked、Both Axis Working |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバタイプ on Tap | SMF 28e Fiber、PM Panda Fiber |
| ファイバ長 | 標準1m、その他も対応可 |
#### パッケージタイプ
　　　　　　　　　　小型タイプ
　　　　　　　　　　標準タイプ
## 資料ダウンロード
- [データシート：1310nm、1480nm、1550nm、1590nm Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-030C-PMTAPI-13101590nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm、1590nm High Power Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-054C-HPMTAPI-1310nm1590nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm、1590nm Mini Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-040B-MPMTAPI-1530-to-1570nm.pdf#view=Fit)
- [データシート：1064nm Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-11-008B-PMTAPI-1064nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ