# Source URL: https://www.sevensix.co.jp/products/waveanalyzer-400a/

# 
# C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』
帯域幅：1527.8 ~ 1610.05nm
_メーカ：_ Coherent (旧 II-VI)
- 光計測器
- 光スペクトラムアナライザ
C+L-bandモデルをサポートした、コヒーレント検波方式の、高分解能、高速測定可能な光スペクトラム・アナライザです。
さらに、弊社ではWaveAnalyzerのポテンシャルを最大限に引き出す
当社オリジナル・ソフトウェアのサポートをご提供しております。
製品のお問い合わせ･お見積
## 特長
- C+L-band帯対応 1527.8～1610.05nm
- 高い分解能帯域幅 500MHz
- 高速測定 フルレンジ 0.5秒／スキャン
- X偏波とY偏波を別々に表示可能なDual Polarization Detection
- 小型軽量 221mm x 221mm x 44mm, 1.5 kg
## 用途
- 光システム試験
- DWDMテスト
- チャネルパワーとOSNRのテスト
- 製造現場：High throughput コンポーネントテスト
## 仕様詳細
## ■ セブンシックスの技術サポート
導入前・導入後のご相談、承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyze のポテンシャルを最大限に引き出す当社 [オリジナル・ソフトウェア]( のサポート
- WaveShaper・WaveAnalyze の修理対応 (電源系、ファン、ファイバ端面等の交換・修理)
### 解説・関連動画📢
### Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
エクセルと一緒にご使用いただく Python ベースのソフトウェアを新たに開発しました！Matlabベースのソフトとの違いなど、詳細ついては下記動画をご視聴ください。
Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 10:37
•Live
•
▼ Coherent社 Super C-band WaveShaper/Analyzer
新登場│Vol.77
▼ 『WaveShaper』セブンシックス製ソフト②
任意スペクトル・パルス生成 │ Vol.011 (Matlabベース)
## 資料ダウンロード
- [データシート：WaveAnalyzer-400A](https://www.sevensix.co.jp/wp-content/uploads/edb314a5768d3ccdeeff81624769fc71.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバーCoherent (旧 II-VI)光計測器
- ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』 - Super C-band帯 (1523.9 ~ 1572.7nm)対応Coherent (旧 II-VI)光計測器