# Source URL: https://www.sevensix.co.jp/products/opticalamplifier_ramp/

# 
# シングルパルス用光増幅器
波長: 1020 ~ 1600nm
_メーカ：_ RAM Photonics LLC
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光増幅器
- 光ファイバアンプ
SPAシリーズのファイバーアンプは、単一光パルスのような連続波領域で動作しない信号を低ノイズで増幅するために設計されています。従来の連続波増幅器や平均出力増幅器が飽和状態に返信するのに対し、SPAシリーズは低ノイズ増幅に特化した設計になっています。
製品のお問い合わせ･お見積
#### **特長**
- 10-40dB オペレーショナルゲイン
- 1μm帯またはテレコムバンド
- ASEノイズフロア ≤ 1 μW
- シードロスに対する安定性
- 帯域外ASEの抑制
- SMまたはPMアンプリファイア
#### **用途**
- 有限パルス列増幅
- リモートセンシング
- 高エネルギーレーザーシーダーパルス
- 赤外線システム
- 動的透過電子
- 顕微鏡
#### **仕様詳細**
|     |     |     |     |
| --- | --- | --- | --- |
|  | 標準 | オプション / Comment | 単位 |
| ゲイン | 10-30 | up to 40 | dB |
| 動作波長 | typically < 2 nm in 1020-1090 nm | or 1520-1600 nm bands |  |
| インバンドASEノイズフロア | ≤ 1<br>≤ 10<br>≤ 200 | 20dB gain<br>30dB gain<br>40 dB gain | µW(1) |
| 帯域外ASEノイズフロア | ≤ 10 | up to 30 dB gain | pW(1) |
| 時間ゲインコンプレッション | ≤ 0.1 | – | dB |
| 偏光消光比 | 18 | PM versions only | dB |
| Input/Output | FC/APC | collimator op3onal | – |
| 入力との同期 | – | none required | – |
| 消費電力 | ≤ 20 | – | W |
(1): 0.1nmの帯域幅で測定
## 資料ダウンロード
- [シングルパルスファイバ増幅器　データシート](https://www.sevensix.co.jp/wp-content/uploads/SPA-Single-Pulse-Fiber-Amplifier.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ