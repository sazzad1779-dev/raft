# Source URL: https://www.sevensix.co.jp/products/pompld_mm_innolume/

# 
# 半導体マルチモードレーザー / 量子ドットレーザー
波長: 678 ~ 1310nm　出力: 3 ~ 15W
_メーカ：_ Innolume GmbH
- 半導体レーザーダイオード（LD）
- ポンプLD
- シードLD
- MMファイバ
- ファブリペローレーザー
✓ 波長、出力、マウントタイプ別に用途に合った高出力半導体レーザラインナップ
✓ パッケージタイプ : C マウント、サブマウント、ファイバ結合モジュール
✓ RoHS規制対応
製品のお問い合わせ･お見積
## 特長
- single emitterから最大15Wの高光出力を生成できます
 C-MOUNT
 SUBMOUNT
## 用途
- 波長可変光源
- 医療機器、産業機器
## 仕様詳細
### ■ C-MOUNTパッケージ
|     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | 平均波長(nm) | Mesa 幅(um) | 出力(W) | 順電流(A) | 順電圧(V) | 閾値電流(A) | スペクトル幅 (3dB)nm | Slow軸ビーム発散角(deg) | Fast軸ビーム発散角(deg) |
| [BAD1064004CM006WXXXX]( | Broad-area laser diode at 1064nm on C-mount | 1064 | 90.00 | 6.00 | 7.00 | 1.5 | 0.4 | 4 | 6 | 35 |
| [BAE1064004CM008WXXXX]( | Broad-area laser diode at 1064nm on C-mount | 1064 | 130 | 8.00 | 10.00 | 1.5 | 0.5 | 4 | 7 | 35 |
| [BAH1064004CM012WXXXX]( | Broad-area laser diode at 1064nm on C-mount | 1064 | 250 | 12.00 | 14.00 | 1.5 | 0.7 | 4 | 8 | 35 |
| [BAH1064004CM015WXXXX]( | Broad-area laser diode at 1064nm on C-mount | 1064 | 250 | 15.00 | 18.00 | 1.5 | 0.7 | 4 | 10 | 34 |
| [BAD1150010CM004WXXXX]( | Broad-area laser diode at 1150nm on C-mount | 1150 | 90 | 4.00 | 8.00 | 1.4 | 0.4 | 10 | 8 | 40 |
| [BAH1160010CM007WXXXX]( | Broad-area laser diode at 1160nm on C-mount | 1160 | 250 | 7.00 | 14.00 | 1.4 | 1 | 10 | 10 | 40 |
| [BAD1180010CM003WXXXX]( | Broad-area laser diode at 1180nm on C-mount | 1180 | 90 | 3.00 | 6.00 | 1.5 | 0.5 | 10 | 7 | 38 |
| [BAH1190010CM006WXXXX]( | Broad-area laser diode at 1190nm on C-mount | 1190 | 250 | 6.00 | 14.00 | 1.5 | 1.1 | 10 | 8 | 40 |
| [BAD1210010CM004WXXXX]( | Broad-area laser diode at 1210nm on C-mount | 1210 | 90 | 4.00 | 7.50 | 1.4 | 0.5 | 10 | 8 | 34 |
| [BAE1210010CM005WXXXX]( | Broad-area laser diode at 1210nm on C-mount | 1210 | 130 | 5.00 | 9.50 | 1.4 | 0.6 | 10 | 8 | 33 |
| [BAH1210010CM009WXXXX]( | Broad-area laser diode at 1210nm on C-mount | 1210 | 250 | 9.00 | 17.00 | 1.4 | 1 | 10 | 9 | 27 |
| [BAH1240010CM009WXXXX]( | Broad-area laser diode at 1240nm on C-mount | 1240 | 250 | 9.00 | 17.00 | 1.4 | 1.5 | 10 | 9 | 29 |
| [BAD1280010CM004WXXXX]( | Broad-area laser diode at 1280nm on C-mount | 1280 | 90 | 4.00 | 7.50 | 1.4 | 0.5 | 10 | 7 | 30 |
| [BAE1280010CM005WXXXX]( | Broad-area laser diode at 1280nm on C-mount | 1280 | 130 | 5.00 | 10.00 | 1.4 | 0.7 | 10 | 7 | 30 |
| [BAH1290010CM009WXXXX]( | Broad-area laser diode at 1290nm on C-mount | 1290 | 250 | 9.00 | 20.00 | 1.5 | 1.8 | 10 | 11 | 31 |
| [BAE1310010CM005WXXXX]( | Broad-area laser diode at 1310nm on C-mount | 1310 | 130 | 5.00 | 11.00 | 1.4 | 1 | 10 | 8 | 30 |
| [BAA1320006CM002WXXXX]( | Broad-area laser diode at 1320nm on C-mount | 1320 | 30 | 2.00 | 4.00 | 1.5 | 0.6 | 6 | 4 | 28 |
| [BAD1320010CM003WXXXX]( | Broad-area laser diode at 1320nm on C-mount | 1320 | 90 | 3.00 | 7.00 | 1.5 | 0.3 | 10 | 8 | 40 |
### ■ SUBMOUNTパッケージ
|     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 製品概要 | 平均波長(nm) | Mesa 幅(um) | 出力(W) | 順電流(A) | 順電圧(V) | 閾値電流(A) | スペクトル幅 (3dB)nm | Slow軸ビーム発散角(deg) | Fast 軸ビーム発散角(deg) |
| [BAD1020004CC006WXXXX]( | Broad-area laser diode at 1020nm on submount | 1020 | 90.00 | 6.00 | 7.00 | 1.5 | 0.6 | 4 | 6 | 16 |
| [BAD1064004CC006WXXXX]( | Broad-area laser diode at 1064nm on submount | 1064 | 90 | 6.00 | 7.00 | 1.5 | 0.4 | 4 | 6 | 35 |
| [BAE1064004CC008WXXXX]( | Broad-area laser diode at 1064nm on submount | 1064 | 130 | 8.00 | 10.00 | 1.5 | 0.5 | 4 | 7 | 35 |
| [BAH1064004CC012WXXXX]( | Broad-area laser diode at 1064nm on submount | 1064 | 250 | 12.00 | 14.00 | 1.5 | 0.7 | 4 | 8 | 35 |
| [BAH1064004CC015WXXXX]( | Broad-area laser diode at 1064nm on submount | 1064 | 250 | 15.00 | 18.00 | 1.5 | 0.7 | 4 | 10 | 34 |
| [BAD1120004CC006WXXXX]( | Broad-area laser diode at 1120nm on submount | 1120 | 90 | 6.00 | 8.00 | 1.4 | 0.7 | 4 | 6 | 34 |
| [BAE1120004CC008WXXXX]( | Broad-area laser diode at 1120nm on submount | 1120 | 130 | 8.00 | 11.00 | 1.4 | 1 | 4 | 7 | 36 |
| [BAD1150010CC004WXXXX]( | Broad-area laser diode at 1150nm on submount | 1150 | 90 | 4.00 | 8.00 | 1.4 | 0.4 | 10 | 8 | 40 |
| [BAH1160010CC007WXXXX]( | Broad-area laser diode at 1160nm on submount | 1160 | 250 | 7.00 | 14.00 | 1.4 | 1 | 10 | 10 | 40 |
| [BAD1180010CC003WXXXX]( | Broad-area laser diode at 1180nm on submount | 1180 | 90 | 3.00 | 6.00 | 1.5 | 0.5 | 10 | 7 | 38 |
| [BAH1190010CC006WXXXX]( | Broad-area laser diode at 1190nm on submount | 1190 | 250 | 6.00 | 14.00 | 1.5 | 1.1 | 10 | 8 | 40 |
| [BAD1210010CC004WXXXX]( | Broad-area laser diode at 1210nm on submount | 1210 | 90 | 4.00 | 7.50 | 1.4 | 0.5 | 10 | 8 | 34 |
| [BAE1210010CC005WXXXX]( | Broad-area laser diode at 1210nm on submount | 1210 | 130 | 5.00 | 9.50 | 1.4 | 0.6 | 10 | 8 | 33 |
| [BAH1210010CC009WXXXX]( | Broad-area laser diode at 1210nm on submount | 1210 | 250 | 9.00 | 17.00 | 1.4 | 1 | 10 | 9 | 27 |
| [BAH1240010CC009WXXXX]( | Broad-area laser diode at 1240nm on submount | 1240 | 250 | 9.00 | 17.00 | 1.4 | 1.5 | 10 | 9 | 29 |
| [BAD1280010CC004WXXXX]( | Broad-area laser diode at 1280nm on submount | 1280 | 90 | 4.00 | 7.50 | 1.4 | 0.5 | 10 | 7 | 30 |
| [BAE1280010CC005WXXXX]( | Broad-area laser diode at 1280nm on submount | 1280 | 130 | 5.00 | 10.00 | 1.4 | 0.7 | 10 | 7 | 30 |
| [BAH1290010CC009WXXXX]( | Broad-area laser diode at 1290nm on submount | 1290 | 250 | 9.00 | 20.00 | 1.5 | 1.8 | 10 | 11 | 31 |
| [BAE1310010CC005WXXXX]( | Broad-area laser diode at 1310nm on submount | 1310 | 130 | 5.00 | 11.00 | 1.4 | 1 | 10 | 8 | 30 |
| [BAA1320006CC002WXXXX]( | Broad-area laser diode at 1320nm on submount | 1320 | 30 | 2.00 | 4.00 | 1.5 | 0.6 | 6 | 4 | 28 |
| [BAD1320010CC003WXXXX]( | Broad-area laser diode at 1320nm on submount | 1320 | 90 | 3.00 | 7.00 | 1.5 | 0.3 | 10 | 8 | 40 |
## 製品に関するお問い合わせ
この製品のお問い合わせ