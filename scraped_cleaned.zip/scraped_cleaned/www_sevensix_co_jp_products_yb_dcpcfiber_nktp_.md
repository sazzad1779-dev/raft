# Source URL: https://www.sevensix.co.jp/products/yb_dcpcfiber_nktp/

# 
# Yb添加 ダブルクラッドフォトニック結晶ファイバ
高ピークパワーの超短パルスファイバレーザ増幅器用
_メーカ：_ NKT Photonics A/S
- 光ファイバ素線 / 光ファイバパッチコード
- PMファイバ
- PMファイバ
- 希土類添加ファイバ (Yb/ Er)
- フォトニック結晶ファイバ
高ピークパワーの超短パルスファイバレーザ増幅器用のYb添加ダブルクラッドファイバ
製品のお問い合わせ･お見積
## 特長
- 最大31 umのモードフィールド径
- 高ピークパワー＆高パルスエネルギー対応
- 高信頼性
### ◆ DC-135/14-PM-Yb
モードフィールド径が14 um、励起クラッド径が135 umのYb添加ダブルクラッド PM フォトニック結晶ファイバです。
本製品は市販されている産業向けコンバイナーとの互換性があるため、数多くのレーザメーカに採用されている Yb添加ファイバとなります。
### ◆ DC-200/40-PZ-Yb
モードフィールド径が31 um、励起クラッド径が200 umのYb添加ダブルクラッド PM フォトニック結晶ファイバです。
本製品は市販されている産業向け超短パルスレーザ用のラージモードエリアファイバ（LMAファイバ）の中で最もモードフィールド径が大きく、数多くのレーザメーカに採用されてきた Yb添加ファイバとなります。
※DC-200/40-PZ-Yb のファイバ単体ではなく、DC-200/40-PZ-Yb を用いた増幅器モジュールをご検討の方
aeroGAIN-BASE シリーズ をご参照くださいませ▼
 超短パルスレーザー用光増幅モジュール『aeroGAIN-BASE』
## 資料ダウンロード
- [データシート：DC-135/14-PM-Yb](https://www.sevensix.co.jp/wp-content/uploads/DC-135_14-PM-Yb.pdf#view=Fit)
- [データシート：DC-200/40-PZ-Yb](https://www.sevensix.co.jp/wp-content/uploads/DC-200_40-PZ-Yb.pdf#view=Fit)
- [アプリケーションノート：DC-200/40-PZ-Yb のモード特性](https://www.sevensix.co.jp/wp-content/uploads/WhitePaper_DC-200-40-PZ-Yb-ModalProperties.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ