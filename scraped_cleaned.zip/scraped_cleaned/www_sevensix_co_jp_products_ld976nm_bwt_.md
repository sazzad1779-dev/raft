# Source URL: https://www.sevensix.co.jp/products/ld976nm_bwt/

# 
# ファイバ付 高出力 半導体マルチモードレーザー
波長: 976 ~ 980nm　出力: 10 ~ 1000W
_メーカ：_ BWT Beijing LTD.
- 半導体レーザーダイオード（LD）
- ポンプLD
- MMファイバ
- ファブリペローレーザー
✓ 高効率、高い安定性、優れたビーム品質
✓ コネクタ、パッケージについても変更の相談が可能
✓ 電源付きのシステムでもご提案が可能
製品のお問い合わせ･お見積
## 特長
- 中心波長976~980nmの励起用半導体レーザー
- CWファイバレーザーの励起に最適
## 用途
- ファイバレーザ構築
- レーザ加工
- 光ファイバ増幅器構築
- 溶接/切断
- 研究&開発/教育用キット
- 医療
## 仕様詳細
|     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- |
| 製品名 | 型式 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| 976nm 3W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AB2RN-3.000WN0N-10522F10ENA]( | 976 | 3 | 105 | 0.22 | ファイバーレーザー増幅 |
| 976nm 9W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AB2RN-9.000WN0N-10522F10ENA]( | 976 | 9 | 105 | 0.22 | ファイバーレーザー増幅 |
| 976nm 18W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AA2RN-18.00WN0N-10522F10ENA]( | 976 | 18 | 105 | 0.22 | ファイバーレーザー増幅 |
| 976nm 27W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AAHRN-27.00WN1N]( | 976 | 27 | 105 | 0.22 | ファイバーレーザー増幅 |
| 976nm 60W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AA5RN-60.00WN0N-10522F20ENA]( | 976 | 60 | 106.5 | 0.22 | ファイバーレーザー増幅 |
| 976nm 130W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976AT4RN-130.0WN0N-10522F20EFF]( | 976 | 130 | 105 | 0.22 | ファイバーレーザー増幅 |
| 976nm 140W Wavelength Stabilized Fiber Coupled <br>Diode Laser | [K976BN1RN-140.0WN0N-10522F20ENA]( | 976 | 140 | 106.5 | 0.22 | ファイバーレーザー増幅 |
| 976nm Pluggable Fiber Coupled Diode Laser | [K976FPACA Series]( | 976 | 200/300 | 400 | 0.22 | レーザープラスチック溶着、レーザーはんだ付け、科学研究 |
| 976nm 430W Wavelength-Stabilized High Power Fiber Coupled Diode Laser | [K976BNZRN-430.0WN0N-20022F20FNA0]( | 976 | 430 | 200 | 0.22 | ファイバーレーザー増幅 |
| 976nm 460W High Power Fiber Coupled Diode Laser | [K976-A0-460.0W-22022-D]( | 976 | 460 | 220 | 0.22 | ファイバーレーザー増幅 |
| 976nm 510W High Power Fiber Coupled Diode Laser | [K976-A0-510.0W-22022-D]( | 976 | 510 | 220 | 0.22 | ファイバーレーザー増幅 |
| 976nm 530W Wavelength Stabilized High Power Fiber Coupled Diode Laser | [K976BNERN-530.0WN0N-20022F20FFF]( | 976 | 530 | 200 | 0.22 | ファイバーレーザー増幅 |
| 976nm 700W High Power Fiber Coupled Diode Laser | [K976DNERN-700.0WN0N-20022F20ENA]( | 976 | 700 | 200 | 0.22 | ファイバーレーザー増幅 |
| 976nm 1000W Lightweight high power fiber coupled diode laser | [K976DGLRN-1000.0W]( | 976 | 1000 | 220 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 980nm 10W Multi-Function Detachable <br>Diode Laser | [K980F11CA-10.00W]( | 980 | 10 | 200 | 0.22 | 医療 |
| 980nm 10W Multi-Function Detachable <br>Diode Laser | [K980F14CC-10.00W]( | 980 | 10 | 200 | 0.22 | 医療 |
| 980nm 30W Multi-Function Detachable Diode Laser | [K980FAMCA-30.00W]( | 980 | 30 | 200 | 0.22 | 医療、科学研究 |
## 製品に関するお問い合わせ
この製品のお問い合わせ