# Source URL: https://www.sevensix.co.jp/products/multicore-fibercoupler_ks-photonics/

# 
# マルチコアファイバカプラ
C-Band / L-Band
_メーカ：_ KS Photonics Inc.
- 光ファイバ部品
- WDMカプラ
KSPhotonics社のマルチコアファイバカプラの特徴としては、同社独自の技術であるサイドポリッシュファイバの技術を採用しています。
マルチコア光増幅器用のポンプコンバイナやTAPカプラとして、高い結合効率と低ロス特性を有してご使用いただけます。
指定のマルチコアファイバをご支給いただき、各種特注での対応も可能です。
製品のお問い合わせ･お見積
## 特長
- 各コアへ対する直接結合
- FIFO-less結合
- 低損失
- オールファイバ構造
- コンパクトサイズ
## 用途
- マルチコアファイバ増幅器
- MCF分岐比可変/固定カプラ
- MCF TAPカプラ
- MCF WDMカプラ(ビームコンバイナ)
- MCF Fan-In/Fan-Out
## 仕様詳細
### マルチコア WDMカプラ 仕様例\*
|     |     |     |
| --- | --- | --- |
| Specifications | Port 1 | Port2 |
| Wavelength | 980 nm | 1550 nm |
| Insertion loss | 0.04 dB | 0.4 dB |
|  | 99.1 % | 91.2 % |
| Isolation | 15 dB | 12 dB |
## 関連動画
6G/第6世代通信向けキーデバイス│Vol.89
## 資料ダウンロード
- [カタログ：マルチコアファイバカプラ](https://www.sevensix.co.jp/wp-content/uploads/88235bf584969c8eb74f328cea8f6dbc.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ