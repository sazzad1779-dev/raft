# Source URL: https://www.sevensix.co.jp/products/freespace_smlaser_innolume/

# 
# フリースペース型 シングルモード半導体レーザー
波長: 1000 ~ 1310nm　出力: 0.3 ~ 0.5W
_メーカ：_ Innolume GmbH
- 半導体レーザーダイオード（LD）
- シードLD
Innolume社は、1000nmから1310nmの範囲の任意の波長の高出力、空間シングルモードレーザーダイオードの幅広いポートフォリオを提供しています。
自由空間ビームを持つデバイスは、9mm TO-canまたはサブマウントにパッケージングされています。
製品のお問い合わせ･お見積
## 特長
- 独自のミラーコーティング技術により高信頼性を実現
- 信頼性の高いAu/Snボンディング
- オプション：キャップなし、オープンヒートシンクへの取り付け（CマウントまたはAlNキャリア）
## 仕様詳細
|     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 平均波長 (nm) | 製品概要 | 出力(mW) | 順電流 (mA) | 順電圧(V) | 閾値電流 (mA) | スペクトル幅 (3dB)nm | Slow軸ビーム発散角 (deg) | Fast軸ビーム発散角 (deg) |
| [SML1000B60TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1000B60TC300MXXXX.pdf?_gl=1*l42xxp*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1000 | Single-mode laser diode at 1000nm in TO-9 package | 300 | 400 | 1.6 | 30 | 0.6 | 6 | 17 |
| [SML1064B60TC500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1064B60TC500MXXXX.pdf?_gl=1*po2mm5*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1064 | Single-mode laser diode at 1064nm in TO-9 package | 500 | 600 | 1.7 | 30 | 0.6 | 6 | 31 |
| [SML1085B60TC400MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1085B60TC400MXXXX.pdf?_gl=1*17j25iw*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1085 | Single-mode laser diode at 1085nm in TO-9 package | 400 | 500 | 1.6 | 40 | 0.6 | 6 | 35 |
| [SML1155005TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1155005TC300MXXXX.pdf?_gl=1*h5uuv6*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1155 | Single-mode laser diode at 1155nm in TO-9 package | 300 | 600 | 1.55 | 40 | 4.5 | 6 | 27 |
| [SML1155005TC500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1155005TC500MXXXX.pdf?_gl=1*1cxaihs*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1155 | Single-mode laser diode at 1155nm in TO-9 package | 500 | 800 | 1.6 | 40 | 5 | 6 | 27 |
| [SML1170007TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1170007TC300MXXXX.pdf?_gl=1*1iftdrx*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1170 | Single-mode laser diode at 1170nm in TO-9 package | 300 | 600 | 1.5 | 30 | 7 | 6 | 31 |
| [SML1180007TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1180007TC300MXXXX.pdf?_gl=1*kgh3j3*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1180 | Single-mode laser diode at 1180nm in TO-9 package | 300 | 600 | 1.5 | 30 | 7 | 6 | 31 |
| [SML1200005TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1200005TC300MXXXX.pdf?_gl=1*17714o*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1200 | Single-mode laser diode at 1200nm in TO-9 package | 300 | 600 | 1.4 | 40 | 4.5 | 6 | 29 |
| [SML1200005TC500MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1200005TC500MXXXX.pdf?_gl=1*1291biy*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1200 | Single-mode laser diode at 1200nm in TO-9 package | 500 | 900 | 1.5 | 40 | 5 | 6 | 29 |
| [SML1210005TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1210005TC300MXXXX.pdf?_gl=1*qltlwz*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5f#view=Fit) | 1210 | Single-mode laser diode at 1210nm in TO-9 package | 300 | 600 | 1.4 | 40 | 4.5 | 6 | 29 |
| [SML1210005TC500MXXXX](https://api.innolume.com/storage/https://api.innolume.com/storage/products/pdf/fp/SML1210005TC500MXXXX.pdf?_gl=1*qltlwz*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1210 | Single-mode laser diode at 1210nm in TO-9 package | 500 | 900 | 1.5 | 40 | 5 | 6 | 29 |
| [SML1230007TC300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1230007TC300MXXXX.pdf?_gl=1*1mdt3o1*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) | 1230 | Single-mode laser diode at 1230nm in TO-9 package | 300 | 600 | 1.5 | 40 | 7 | 6 | 38 |
| [SML1310007T](https://api.innolume.com/storage/products/pdf/fp/SML1310007TC300MXXXX.pdf?_gl=1*1ypofpl*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5) [C](https://api.innolume.com/storage/products/pdf/fp/SML1310007TC300MXXXX.pdf?_gl=1*1ypofpl*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5#view=Fit) [300MXXXX](https://api.innolume.com/storage/products/pdf/fp/SML1310007TC300MXXXX.pdf?_gl=1*1ypofpl*_gcl_au*MTk1ODM1NDQwMS4xNzY4NDQyNTk5) | 1310 | Single-mode laser diode at 1310nm in TO-9 package | 300 | 800 | 1.6 | 80 | 7 | 6 | 29 |
## 製品に関するお問い合わせ
この製品のお問い合わせ