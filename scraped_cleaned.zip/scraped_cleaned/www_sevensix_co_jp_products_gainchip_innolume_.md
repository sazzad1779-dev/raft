# Source URL: https://www.sevensix.co.jp/products/gainchip_innolume/

# 
# ゲインチップ
波長 780 ~ 1340nm　出力: 33 ~ 350ｍW
_メーカ：_ Innolume GmbH
- 半導体レーザーダイオード（LD）
- ファブリペローレーザー
- ゲインチップ/ゲインモジュール
✓ 波長可変光源向けのゲインチップ
✓ 外部共振器システムでの波長ロック動作に最適
製品のお問い合わせ･お見積
## 特長
- 片側光アクセス(タイプA、B)
- 二面性光アクセス（タイプC、D）
- 片側光アクセスゲインチップは、出力パワーを外部共振器から切り離す方式の動作に最適
- 一般的にはTO-canパッケージで提供されます
 Straight gain-chip in TO package (type-A)
 Curved gain-chip in TO package (type-B)
 Gain-chip in TO package with cap
## 用途
- 外部共振器型チューナブルレーザー
## 仕様詳細
|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 製品型番 | 用途 | 製品概要 | 最大出力波長(nm) | チューニング幅(nm) | 最大出力(mW) | チューニング中心波長(nm) | 順電流(mA) | Slow軸ビーム発散角(deg) | Fast軸ビーム発散角(deg) | チップ長(mm) | Mesaタイプ |
| [GCB0780030TC030MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 33mW at 780nm in TO package | 780 | 30 | 33 | 775 | 150 | 7.5 | 22 | 2 | curved |
| [GCB0920090TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 920nm in TO package | 920 | 90 | 200 | 905 | 400 | 8.5 | 36 | 1.5 | curved |
| [GCB0950110TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 980nm in TO package | 980 | 110 | 200 | 950 | 400 | 5.5 | 31 | 1.5 | curved |
| [GCB1030150TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1060nm in TO package | 1060 | 150 | 200 | 1025 | 400 | 9.5 | 38 | 1.4 | curved |
| [GCB1030160TC100MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 110mW at 1060nm in TO package | 1060 | 160 | 110 | 1030 | 200 | 8 | 18 | 1.5 | curved |
| [GCB1060150TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 210mW at 1090nm in TO package | 1090 | 150 | 210 | 1060 | 400 | 8 | 17 | 1.5 | curved |
| [GCB1105130TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1130nm in TO package | 1130 | 130 | 200 | 1105 | 400 | 9 | 38 | 1.4 | curved |
| [GCA1110070TC300MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 350mW at 1120nm in TO package | 1120 | 70 | 350 | 1105 | 600 | 4 | 35 | 3 | straight |
| [GCA1160090TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 230mW at 1160nm in TO package | 1160 | 90 | 230 | 1150 | 600 | 5 | 42 | 3 | straight |
| [GCB1180100TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 210mW at 1190nm in TO package | 1190 | 100 | 210 | 1170 | 600 | 6 | 37 | 3 | curved |
| [GCA1180080TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 220mW at 1190nm in TO package | 1190 | 80 | 220 | 1180 | 600 | 4 | 37 | 3 | straight |
| [GCB1220110TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 230mW at 1240nm in TO package | 1240 | 110 | 230 | 1215 | 800 | 6 | 32 | 3 | curved |
| [GCA1260060TC120MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 120mW at 1260nm in TO package | 1260 | 60 | 120 | 1260 | 400 | 5 | 38 | 3 | straight |
| [GCB1260060TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 210mW at 1270nm in TO package | 1270 | 60 | 210 | 1260 | 800 | 7 | 38 | 3 | curved |
| [GCA1270060TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1270nm in TO package | 1270 | 60 | 200 | 1270 | 800 | 6 | 33 | 3 | straight |
| [GCB1270130TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1320nm in TO package | 1320 | 130 | 200 | 1270 | 800 | 6 | 38 | 3 | curved |
| [GCA1270140TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 220mW at 1310nm in TO package | 1310 | 140 | 220 | 1270 | 800 | 5 | 38 | 3 | straight |
| [GCB1300060TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1320nm in TO package | 1320 | 60 | 200 | 1300 | 800 | 6 | 38 | 3 | curved |
| [GCA1310060TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 220mW at 1310nm in TO package | 1310 | 60 | 220 | 1310 | 800 | 5 | 38 | 3 | straight |
| [GCB1330070TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 200mW at 1340nm in TO package | 1340 | 70 | 200 | 1325 | 800 | 7 | 37 | 3 | curved |
| [GCA1330060TC200MXXXX]( | External cavity laser, Tunable laser source | Gain-chip 210mW at 1340nm in TO package | 1340 | 60 | 210 | 1330 | 800 | 5 | 38 | 3 | straight |
## 製品に関するお問い合わせ
この製品のお問い合わせ