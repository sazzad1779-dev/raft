# Source URL: https://www.sevensix.co.jp/products/pilasdx_nktp/

# 
# ゲインスイッチ方式 ピコ秒レーザー『PILAS DX』
波長：375 ~ 1550nm
_メーカ：_ NKT Photonics A/S
- ファイバーレーザー・その他光源
- 超短パルスレーザー(ナノ秒/ピコ秒/フェムト秒)光源
『PILAS DX』シリーズは、単一波長発振のゲインスイッチ方式のピコ秒レーザーです。
製品のお問い合わせ･お見積
## 製品概要
PILAS DX シリーズはNKT Photonics社が2017年7月に買収いたしましたOnefive社の子会社でドイツのベルリンに拠点を持つAdvanced Laser Diode Systems の単一波長発振のゲインスイッチ方式のピコ秒レーザーです。
本製品はレーザーコントローラユニットとレーザー発振ヘッドから構成されます。発振波長は375 – 1550 nm間の10種類以上の波長から選択可能です。マスタ/スレーブモードの両使用にて繰り返し周波数はsingle shotから40 MHz （80MHz のカスタム対応可）でPulse on demandとなり、外部から簡単にトリガが可能です。射出端はFree space と Single mode fiber output(1m, FC/APC connector)どちらも対応可能です。
## 特長
- 低タイミングジッタ：< 3ps rma
- Single shotから最大80 MHzまで繰り返し周波数を可変
- 内部トリガー / 外部トリガー
- マスターモード / スレーブモード両方での発振可能
- メンテナンスフリー / アライメントフリー
- 24/7 オペレーション
- CW発振のオプションもあり
## 用途
- ファイバの測定
- 検出器の測定
- 蛍光イメージング
- 半導体検査
- 時間分解分光法
## 仕様詳細
### 光学仕様
|     |     |
| --- | --- |
| パルス繰り返し周波数 \*1 | Pulse-on-Demand ~ 40 MHz |
| 周波数分解能 | 1 Hz @ 50 Hz |
| ビーム品質 | M2 <1.2 |
| 偏波消光比 | >20 dB (ファイバは非偏光) |
| タイミングジッタ | <3 ps rms |
### 機械 / 電気 / 環境 仕様
|     |     |
| --- | --- |
| レーザー出力 | Free space / SMF (1m, FC/APC connector) |
| ウォームアップ時間 | < 10分 |
| 使用温度 | 寸法（WxHxL） |
| 保管温度 | ー15 ~ 60 °C |
| オン/オフサイクル | \> 10,000 |
| 寿命 | \> 10,000時間 |
| 電源 | 12 VDC/3A or 100-264 VAC, 47-63 Hz |
| 消費電力 | < 30 W |
| レーザーヘッドのサイズ (W x H x L) | 95 x 31 x 181 mm |
| レーザーヘッドの重量 | 0.45 kg |
| コントロールユニットのサイズ (W x H x L) | 326 x 88 x 235 mm |
| コントロールユニットの重量 | 2.5 kg |
| 冷却方法 | 空冷 |
### 製品ラインナップ
|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
| モデル | 出力 | 波長 | スペクトル幅 | パルス幅 | ピーク出力 | 平均出力 \*1 | 最大繰り返し周波数 |
| PIL037-FS | Free space | 375 ± 10 nm | < 5 nm | < 70 ps | \> 150 mW | \> 0.5 mW | 40 MHz |
| PIL037-FC | SMF（FC/APC） | 375 ± 10 nm | < 5 nm | < 70 ps | \> 60 mW | \> 0.2 mW | 40 MHz |
| PIL040-FS | Free space | 405 ± 15 nm | < 5 nm | < 45 ps | \> 350 mW | \> 0.8 mW | 40 MHz |
| PIL040-FC | SMF（FC/APC） | 405 ± 15 nm | < 5 nm | < 45 ps | \> 160 mW | \> 0.25 mW | 40 MHz |
| PIL044-FS | Free space | 440 ± 20 nm | < 5 nm | < 70 ps | \> 250 mW | \> 0.7 mW | 40 MHz |
| PIL044-FC | SMF（FC/APC） | 440 ± 20 nm | < 5 nm | < 70 ps | \> 100 mW | \> 0.3 mW | 40 MHz |
| PIL048-FS | Free space | 480 ± 20 nm | < 10 nm | < 80 ps | \> 150 mW | \> 0.8 mW | 40 MHz |
| PIL048-FC | SMF（FC/APC） | 480 ± 20 nm | < 10 nm | < 80 ps | \> 60 mW | \> 0.3 mW | 40 MHz |
| PIL051-FS | Free space | 510 ±15 nm | < 10 nm | < 110 ps | \> 100 mW | \> 0.6 mW | 40 MHz |
| PIL051-FC | SMF（FC/APC） | 510 ±15 nm | < 10 nm | < 110 ps | \> 40 mW | \> 0.2 mW | 40 MHz |
| PIL063-FS | Free space | 635 ±15 nm | < 7 nm | < 50 ps | \> 200 mW | \> 0.5 mW | 40 MHz |
| PIL063-FC | SMF（FC/APC） | 635 ±15 nm | < 7 nm | < 50 ps | \> 80 mW | \> 0.2 mW | 40 MHz |
| PIL067-FS | Free space | 655 ±15 nm | < 7 nm | < 45 ps | \> 200 mW | \> 0.5 mW | 40 MHz |
| PIL067-FC | SMF（FC/APC） | 655 ±15 nm | < 7 nm | < 45 ps | \> 80 mW | \> 0.3 mW | 40 MHz |
| PIL069-FS | Free space | 690 ±15 nm | < 7 nm | < 50 ps | \> 200 mW | \> 0.6 mW | 40 MHz |
| PIL069-FC | SMF（FC/APC） | 690 ±15 nm | < 7 nm | < 50 ps | \> 80 mW | \> 0.2 mW | 40 MHz |
| PIL085-FS | Free space | 850 ±15 nm | < 10 nm | < 50 ps | \> 200 mW | \> 0.5 mW | 40 MHz |
| PIL085-FC | SMF（FC/APC） | 850 ±15 nm | < 10 nm | < 50 ps | \> 80 mW | \> 0.2 mW | 40 MHz |
| PIL094-FS | Free space | 940 ± 20 nm | < 15 nm | < 50 ps | \> 150 mW | \> 0.35 mW | 40 MHz |
| PIL094-FC | SMF（FC/APC） | 940 ± 20 nm | < 15 nm | < 50 ps | \> 80 mW | \> 0.15 mW | 40 MHz |
| PIL106-FS | Free space | 1060 ± 20 nm | < 15 nm | < 50 ps | \> 150 mW | \> 0.35 mW | 40 MHz |
| PIL106-FC | SMF（FC/APC） | 1060 ± 20 nm | < 15 nm | < 50 ps | \> 60 mW | \> 0.15 mW | 40 MHz |
| PIL155-FS | Free space | 1550 ± 20 nm | < 15 nm | < 50 ps | \> 40 mW | \> 0.04 mW | 40 MHz |
| PIL155-FC | SMF（FC/APC） | 1550 ± 20 nm | < 15 nm | < 50 ps | \> 20 mW | \> 0.02 mW | 40 MHz |
## 資料ダウンロード
- [データシート：PILAS DX](https://www.sevensix.co.jp/wp-content/uploads/ALS-Pilas-Datasheet.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ