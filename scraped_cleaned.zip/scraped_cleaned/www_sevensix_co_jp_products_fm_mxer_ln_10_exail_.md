# Source URL: https://www.sevensix.co.jp/products/fm-mxer-ln-10_exail/

# 
# 【宇宙グレード】高消光比強度変調器
動作帯域: 1535 ~ 1560 nm
_メーカ：_ exail
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 強度変調器
- 光変調器
Exail社の「EM/NS-FM/FM-MXER-LN-10」は、Cバンド（1535～1560 nm）で
動作する宇宙グレードの高消光比強度変調器です。
このデバイスは、10 GHzを超える広帯域幅と非常に高い消光比を特徴とし、
Exailの特許技術「Magic Junction」を採用することで、低挿入損失と高消光比を実現しています。
製品のお問い合わせ･お見積
## 特長
- 最大+20 dBmの高光出力対応
- 高消光比
- 低挿入損失
- 低Vπ
製造メーカであるExail社は宇宙環境での使用に適した高品質な光変調器を提供しており、特に高消光比と広帯域幅を必要とするアプリケーションに適しています。
こちらの変調器は、Exail社の MPZ Cバンド位相変調器などの関連機器と組み合わせて使用することができます。
**▼exail社の変調器はNASAで採用されています▼**
NASA JPL と契約し GRACE-Cミッション に宇宙グレードの光学部品を提供
「当社の変調器は、NASAの要件を満たす能力があることから選ばれました。LiNbO 3変調器における長年の専門知識とリーダーシップにより、当社はNASAの厳格な基準に準拠しながらも宇宙の過酷な環境条件に耐えるコンポーネントを提案しました」 – exail社 Yves Deiss氏 –
2018年からNASAのミッションで運用されているExailの 宇宙グレードの変調ソリューションは、GRACE-Cミッションで重要な役割を果たします。レーザー測距機器に統合されたこれらのコンポーネントは、地球を周回する2機の宇宙船間の、レーザーによる正確な距離測定に貢献しています。
## 用途
- 高パルスコントラスト
- パルス位置変調（PPM）
- 量子鍵配送（QKD）
- Lidar
## 使用詳細
※ o: apply. x: do not apply
## 関連動画
### ▼ EXAIL – Photonics solutions for Laser, Sensing, Communication, Quantum and Space applications
### ▼ Space Quality 変調器・特殊ファイバ│Vol.75
## 資料ダウンロード
- [データシート：高消光比強度変調器【EM-MXER-LN-10】](https://www.sevensix.co.jp/wp-content/uploads/exail-datasheet-em-ns-fm-fm-mxer-ln-10-space-grade-components-1.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ