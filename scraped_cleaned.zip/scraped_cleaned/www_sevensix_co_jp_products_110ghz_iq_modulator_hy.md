# Source URL: https://www.sevensix.co.jp/products/110ghz_iq_modulator_hyperlight/

# 
# 薄膜LN 110GHz IQ 光変調器
C-band
_メーカ：_ HyperLight
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 強度変調器
- 光変調器
従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現する
薄膜LN方式の光変調器メーカ：Hyperlight社の110GHz IQ 光変調器です。
Low VπモデルとRegular Vπモデルの2タイプがございます。
製品のお問い合わせ･お見積
## 特長
- Single-polarization IQ modulator
- \> 125 GHz bandwidth
- Support 240 Gbaud singnaling
- 1.0mm RF Connector(W), PM fibers
- C-band support　※O-band 2025年4Qリリース予定
## 用途
- 240 Gbaud testing
- 110 GHz single sideband modulation
### 解説・関連動画▼
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102 - YouTube
Photo image of sevensix TV (セブンシックス株式会社)
sevensix TV (セブンシックス株式会社)
919 subscribers
100GHz Bandwidth/薄膜LN集積回路の性能限界を押し上げる│Vol.102
sevensix TV (セブンシックス株式会社)
Search
Watch later
Share
Copy link
Info
Shopping
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
More videos
## More videos
You're signed out
Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.
CancelConfirm
Share
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch on
0:00
0:00 / 5:30
•Live
•
## 資料ダウンロード
- [カタログ：薄膜LN 110GHz IQ 光変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-110GHz-IQ-Modulator.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ