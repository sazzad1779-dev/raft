# Source URL: https://www.sevensix.co.jp/products/m_wdmfiltertc_optizone/

# 
# マルチモードWDMフィルタ型カプラ
波長：1310nm Pass / 850 ~ 1550nm Reflect
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- WDMカプラ
中国の深センに拠点を構えるOptizone TechnologiesのマルチモードWDMフィルタ型カプラです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 低挿入損失
- 高リターンロス
## 用途
- 研究用途
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 1310nm Pass / 1550nm Reflect、1550nm Pass / 1310nm Reflect、850nm Pass / 1310nm Reflec、 1310nm Pass / 850nm Reflect |
| コア直径 | 62.5um、50um |
| コネクタタイプ | FC/UPC 、FC/APC、SC/UPC、SC/APC、無し、その他対応可能 |
| ファイバジャケット | 250umベアファイバ、900umルーズチューブ、3mmケーブル、その他対応可能 |
| ファイバ長 | 1.0m、その他対応可能 |
## 資料ダウンロード
- [データシート：Multimode Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-08-002D-MMFWDM-8501550nm.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ