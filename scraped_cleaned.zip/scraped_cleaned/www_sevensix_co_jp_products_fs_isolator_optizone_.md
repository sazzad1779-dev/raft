# Source URL: https://www.sevensix.co.jp/products/fs_isolator_optizone/

# 
# フリースペースアイソレータ
波長: 915 ~ 2000nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- SMアイソレータ
- 光ファイバアイソレータ
中国の深センに拠点を構えるOptizone Technologiesのフリースペースアイソレータです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 低挿入損失
- ハイパワーハンドリング
#### **用途**
- 半導体レーザ
- 個体レーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 915nm、980nm、1064nm、1310nm、1550nm、2000nm、その他も対応可 |
| ステージ | Single Stage、Dual Stage |
| 光路 | Forward、Backward |
| パッケージサイズ | dia2.8×3.7mm、その他対応可能 |
| ハンドリングパワー | 20W、50W、80W、100w、その他対応可能 |
| 有効開口 | 4.7mm、5.0mm、その他対応可能 |
| 波長範囲 | λ±10nm、λ±40nm |
## 資料ダウンロード
- データシート：1064nm Free Space Isolator
- データシート：1310/1550nm Free Space Isolator
- [データシート：2000nm Free Space Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-017C-FSI-2000nm.pdf#view=Fit)
- [データシート：980nm High Power Free Space Isolator Sensitive C149](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-074B-HPFSI-98-C149-20-50-S.pdf#view=Fit)
- [データシート：1064nm High Power Free Space Isolator Sensitive C147](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-073B-HPFSI-06-C147-80-47-S-10.pdf#view=Fit)
- [データシート：1064nm High Power Free Space Isolator Sensitive](https://www.sevensix.co.jp/wp-content/uploads/79972fcb35d22a320bfa393741a0ea5d.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ