# Source URL: https://www.sevensix.co.jp/products/ramanld_3sp-2/

# 
# ラマン励起用 シングルモード半導体レーザー
波長: 1420 ~ 1510nm　出力: 300 ~ 500ｍW
_メーカ：_ 3SP Technologies
- 半導体レーザーダイオード（LD）
- ファブリペローレーザー
✓ ラマン増幅用に設計された超低消費電力
✓ FBGはPMFピグテール上に記載
✓ 動作温度範囲 : -5℃～70°C
✓ RoHS指令対応品
製品のお問い合わせ･お見積
## 特長
- 14ピンバタフライ型モジュール
- TEC、NTCサーミスタ、モニタリングPDを内蔵
- TelcordiaGR-468-CORE認定 済
## 用途
- FTTH用途向けのラマンアンプ
- ラマン分光の励起光源
## 仕様詳細
### ■ **電気光学特性**
**\\* Tsubmount = 35°C, Tcase = -5 to 70°C, TFBG=25°CのBOLで規定**
## 資料ダウンロード
- [データシート：ラマン励起用 シングルモード半導体レーザー](https://www.sevensix.co.jp/wp-content/uploads/3SP-%E3%83%A9%E3%83%9E%E3%83%B3%E3%82%A2%E3%83%B3%E3%83%97.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ