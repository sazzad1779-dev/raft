# Source URL: https://www.sevensix.co.jp/products/cobritedx_idphotonics/

# 
# ベンチトップ型 狭線幅波長可変レーザー
発振波長: 186 ～ 196THz
_メーカ：_ ID Photonics GmbH
- ファイバーレーザー・その他光源
- 狭線幅CWレーザー光源
ベンチトップタイプの狭線幅チューナブルレーザー、CoBrite DXシリーズです。
4CHモデルはタッチパネルを搭載、ウェブブラウザからアクセスしてPC制御やソフトウェアのインストールも可能です。
ラインナップとしては、4CHモデルの他、1CHモデル / 2CHモデル / 48CHモデル もございます。
製品のお問い合わせ･お見積
## 特長
- 仕様範囲全体にわたる完全なチューナビリティ
- CおよびLバンドへの拡張、1525nm～1625nm
- 最大出力 17.8dBm
- レーザー線幅 < 25kHz
- 偏波保持出力
- ブラウザーベースのコントロール用統合ウェブサーバー
- 19インチラックマウント可能
## 用途
- 光ファイバー通信
- コヒーレント光トランシーバー開発
- 局部発振器
- シリコンフォトニクス
- 光学・物理研究への多用途光源
■ CoBrite DX – 4CHモデル　タッチパネル搭載
イーサネット対応(リモート制御可)
■ CoBrite DX2 – 2CHモデル
イーサネット対応(リモート制御可)
■ CoBrite DX1 – 1CHモデル
■ CoBrite MX – 48CHモデル
## 仕様詳細
### 製品比較表
## 解説・関連動画
▼ ID Photonics社 100Gソリューション│Vol.60
## 資料ダウンロード
- [データシート：CoBrite DXシリーズ](https://www.sevensix.co.jp/wp-content/uploads/DataSheet_IDPhotonics_CoBrite_Series.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ