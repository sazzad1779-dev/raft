# Source URL: https://www.sevensix.co.jp/products/aerogain-rod/

# 
# 超短パルスレーザー用光増幅モジュール『aeroGAIN-ROD』
波長: 1030 ~1040nm　出力: 250W
_メーカ：_ NKT Photonics A/S
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光増幅器
- 光ファイバアンプ
aeroGAIN-BASE は微細加工用超短パルスレーザーにおけるパワーアンプ部分（後方励起の光ファイバ増幅システム）でお使いいただくアンプモジュールです。
取扱いが簡単なので、研究室での高出力超短パルスファイバレーザーの研究開発にも適しています。
製品のお問い合わせ･お見積
## 製品概要
aeroGAIN-ROD は産業用 1um 帯超短パルスレーザーの製造のために設計・製造された水冷ホルダ付きのYbファイバベースの増幅モジュールです。
aeroGAIN-RODを用いれば、産業用の繰返し周波数 MHz、パルスエネルギー > 数百 uJ、パルス幅 ピコ秒/フェムト秒の製造が可能です。
## 特長
- non-PM、PM双方に対応
- 高出力対応かつ低線形性
- 優れた位置安定性
- 堅牢な産業向けの構造
- 熱管理が容易
- 市場で証明された信頼性
## 用途
- ピコ秒、ナノ秒パルスの増幅
OEM として採用していただいた時の寿命は 励起LD出力、励起波長、冷却効率に依存しますが、NKT Photonics がシステム設計をサポートします。
OEMをご検討いただく企業の方にはNKT Photonics 本社への訪問・トレーニングも承っております。お気軽にご相談ください。
## 仕様概要
|     |     |     |
| --- | --- | --- |
| モデル | aeroGAIN ROD 2.1 | aeroGAIN ROD 3.1 |
| 動作波長 \[nm\] | 1030 ~ 1040 | 1030 ~ 1040 |
| ファイバコア径 \[µm\] | 85 | 85 |
| モードフィールド径, <br>1/e2 \[µm\] | 65 ± 10% | 65 ± 10% |
| インナークラッド径 \[µm\] | 260 ± 15 | 260 ± 15 |
| インナークラッドNA<br>(FWHM @ 950 nm) | \> 0.5 | \> 0.5 |
| Yb添加ファイバ長 \[µm\] | 804 ± 3 | 804 ± 3 |
| クラッド吸収率 \[dB\]<br>@ 915 nm | 5 ± 0.7 | 5.7 ± 0.7 |
| クラッド吸収率 \[dB\]<br>@ 976 nm | 15 | 17 |
| 変換効率 \[%\] | \> 60 | \> 60 |
| シグナル光の平均出力 \[W\] | 100 | 250 |
| ビーム品質 | M2 < 1.3 | M2 < 1.3 |
| PER, typical \[dB\] | \> 15 | \> 15 |
aeroGAIN-ROD 2.1,3.1 ともに内部に使用されているRODファイバー長は80.4cm で、増幅後の超短パルスレーザーの出力は 2.1は 100W、3.1が 250W 程度 です。
aeroGAIN-ROD のファイバ出力端は ARコートされた大口径エンドキャップが取り付けられており、モード径の拡大と後方反射を抑制に貢献しています。
高いビーム位置安定性(Pointing stability)と低い非線形性を有する aeroGAIN-ROD を採用していただくことにより、柔軟で多様な高出力超短パルスレーザーを構成することができます。
1台の aeroGAIN-ROD モジュールで、ピコ秒(パルス圧縮後にフェムト秒)、ナノ秒パルスの増幅に使えます。モード径が大きいため、例えばスペクトル幅が狭いピコ秒レーザーを効率よく周波数変換できます（高波波の生成効率が高い）。
全ての aeroGAIN-ROD モジュールはクリーンルームで組み立て・検査されています。aeroGAIN-ROD モジュールは連続 25,000時間動作確認を含む複数かつ長期間に渡る動作テストを得てリリースされた製品で、数多くの超短パルスレーザーメーカに採用され、24/7 オペレーションが立証されてます。
## 資料ダウンロード
- [データシート：『aeroGAIN-ROD』](https://www.sevensix.co.jp/wp-content/uploads/aeroGAIN-ROD-Datasheet.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD 2.1』の増幅事例](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes-1.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD 3.1』の増幅事例](https://www.sevensix.co.jp/wp-content/uploads/175-W-average-power-from-a-single-core-rod-fiber-based-chirped-pulse-amplification-system.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD』へのシグナル光と励起光の入力方法](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes-2.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- ピコ秒 / フェムト秒 超短パルスレーザー \- 製品ラインナップとその特徴NKT Photonics A/Sファイバーレーザー・その他光源