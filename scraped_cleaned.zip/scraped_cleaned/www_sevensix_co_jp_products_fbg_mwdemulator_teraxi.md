# Source URL: https://www.sevensix.co.jp/products/fbg_mwdemulator_teraxion/

# 
# FBG方式 波長分散エミュレータ
波長: 1530 ~ 1565nm (Cバンド)
_メーカ：_ TeraXion
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光フィルタ
- 偏波分割多重エミュレータ
何10kmものDCFを準備せずとも低損失・低遅延の波長分散補償、あるいは負荷のエミュレーション実験を行うことのできる可変波長分散エミュレータです。
製品のお問い合わせ･お見積
## 特長
- 1台で波長分散のエミュレーション及び分散補償の実験が可能
- 高精度の波長分散エミュレーションが可能
- Continuous Grid/50GHz Grid/100GHz Gridをサポート
- ベンチトップと共にラックマウントタイプもサポート
## 用途
- データセンター
- 光アクセス
- 基幹系インフラ
- 通信
## 仕様詳細
仕様: Continuous Grid
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| Parameters | TDCMB-C000-J | TDCMB-C000-O | TDCMB-C000-N | Units |
| Dispersion range | ± 900 | ± 1,600 | ± 2,000 | ps/nm |
| Operation bandwidth | ≥ 40 | ≥ 45 | ≥ 35 | GHz |
| Insertion loss | < 5 | < 9 | < 9 | dB |
| Phase ripple standard deviation | < 0.08 | < 0.15 | < 0.15 | rad |
| Dispersion resolution | 5 | 5 | 5 | ps/nm |
仕様：50 GHz Grid
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| Parameters | TDCMB-C050-F | TDCMB-C050-N | TDCMB-C050-R | Units |
| Dispersion range | ± 1200 | ± 2000 | ± 2400 | ps/nm |
| Operation bandwidth | ≥ 45 | ≥ 45 | ≥ 35 | GHz |
| Insertion loss | < 5 | < 9 | < 9 | dB |
| Phase ripple standard deviation | < 0.1 | < 0.15 | < 0.15 | rad |
| Dispersion resolution | 5 | 10 | 10 | ps/nm |
仕様：100 GHz Grid
|     |     |     |
| --- | --- | --- |
| Parameters | TDCMB-C100-O | Units |
| Dispersion range | ± 1 600 | ps/nm |
| Operation bandwidth | ≥ 35 | GHz |
| Insertion loss | < 9 | dB |
| Phase ripple standard deviation | < 0.15 | rad |
| Dispersion resolution | 5 | ps/n |
## 資料ダウンロード
- [データシート：FBG方式 波長分散エミュレータ](https://www.sevensix.co.jp/wp-content/uploads/teraxion-clearspectrum-tdcmb-specsheet.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ