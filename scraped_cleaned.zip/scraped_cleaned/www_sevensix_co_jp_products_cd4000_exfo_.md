# Source URL: https://www.sevensix.co.jp/products/cd4000_exfo/

# 
# クロックデータリカバリ(CDR)『CD-4000』
56GBd / 28GBd
_メーカ：_ EXFO
- 光計測器
- CDR
- BERT
EXFOのビットエラーレートテスターBA-4000とサンプリング・オシロスコープEA-4000と組み合わせて同期の最適化を得るためのCDR（クロック・データ・リカバリ）です。
製品のお問い合わせ･お見積%E3%80%8ECD-4000%E3%80%8F)
## 特長
- NRZ/PAM4サポート
- Integrated O/E with optical splitter
- 超低ランダムジッタ
- オート・ロッキング
## 用途
- 光トランシーバの試験、評価
### ＜測定器構成例＞
## 仕様詳細
### ■ 光学特性
|     |     |
| --- | --- |
| シンボルレート (GBd) | 25 – 56 (depends on model) |
| 波長 (nm) | 1250 – 1650 |
| 反射減衰量 (dB) | –30 (at 1310/1550 nm) |
| 入力感度 | –5 (at 1310/1550 nm) |
| ダメージパワー (mW) | 5 |
| コネクタタイプ | FC/PC (9/125 µm) |
| ループ帯域幅 (MHz) | 20 |
| クロック出力比率 | /8 for 53G, 56G<br>/4 for 26G, 28G |
| リカバリー・クロック・ランダム・ジッター (fs) | < 290 (0 dBm, PRBS16Q at 53 GBd) |
| クロック出力振幅 (mV) | 400 (typical) |
## 資料ダウンロード
- [スペックシート：クロックデータリカバリ(CDR) 『CD-4000』](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_cd-4000_v6_en.pdf#view=Fit)
- [パンフレット：光トランシーバテスト製品ラインナップ \- 最大800G伝送速度](https://www.sevensix.co.jp/wp-content/uploads/c0e90febf49b7bdbef1693a146c5fa68-2.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ%E3%80%8ECD-4000%E3%80%8F)
%E3%80%8ECD-4000%E3%80%8F)