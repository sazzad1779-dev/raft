# Source URL: https://www.sevensix.co.jp/products/waveshaper1000a_coherent/

# 
# 1 μｍ 超短パルスファイバレーザー用 時間・スペクトルプロセッサ WaveShaper『1000A/SP』
1 μｍ, C-Band, C+L-Band
_メーカ：_ Coherent (旧 II-VI)
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光任意波形成形器(Wave Shaper)
- 光フィルタ
LCoSをベースにした、光の振幅と位相を独立に制御できるフィルタです。
LN変調器を用いた時間領域でのパルス制御と比べて高安定・高再現性という特長があります。
WaveShaperはPCとつなげて制御します。専用のソフトウェアを用いることで、WaveShaperのスイッチを入れてからすぐにお使いいただくことができます。
さらに、弊社ではWaveShaperのポテンシャルを最大限に引き出す
当社オリジナル・ソフトウェアのサポートをご提供しております。
製品のお問い合わせ･お見積
## 特長
- 振幅と位相を任意制御
- 振幅の減衰設定 0~25 dB@1 μm, 0~35 dB@ C-band, C+L-band
- 設定可能な群遅延 ± 13~25 ps
- PM ファイバ入出力
- LCoSベースで可動部なし
- 小型・堅牢な OEMモジュール
## 用途
- ファイバレーザー構築
- 微細加工
- パルス圧縮と拡張
- パルスシェープ
- マルチパルス化
- スーパーコンティニューム光の生成
WaveShaper 1000A/SP は LCoSベースの光プロセッサです。主な用途は1 μm帯ファイバレーザーのパルス圧縮です。1 μm帯の光の振幅と位相を操作しますが、稼働域がなく静的に動作するため信頼性と再現性が非常に高く、堅牢なシステムとなっております。
WaveShaperには 通信帯の 1.5 μm帯製品もあります。1.5 μm帯はポートが複数あり、偏波無依存となっておりますが、1 μm帯の WaveShaper 1000A/SP は基本的にレーザー微細加工に用いられるレーザーシステムのパルス圧縮のために設計されているため、ポートは一つです。また、安定な超短パルスレーザーは直線偏光となっているため、WaveShaper 1000A/SPの入出力ファイバもPMFとなっております。
## アプリケーション事例
モードロックレーザー、光ファイバ増幅器と一緒に用いることで性能をフルに発揮できます。WaveShaperの性能をフルに発揮できる光源としては、① 光周波数コム光源『Frush』, ② 超短パルスファイバレーザー『iQoM』 がお勧めです。
### アプリケーション事例①：波長広帯域化とフェムト秒パルスの生成​
### アプリケーション事例②：超短パルス光の出力​
## 仕様詳細
### WaveShaperシリーズ概要
※ WaveShaper A / B シリーズの詳細ページはこちら
※下記リンクをクリックいただくと、各データシートをご確認いただけます。
|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| シリーズ名 | モデル番号 | ポート | 動作波長範囲 | フィルタ波形 |
| [WaveShaper Short-Pulse Shaping]( | WS-01000A/SP | 1×1 | 1μ,<br>C-band,<br>C+L-band | 減衰と位相が任意 |
| [WaveShaper A-Series]( | WS-01000A/S,<br>WS-04000A/S Series | 1×1, 1×4 | S-band | 減衰と位相が任意 |
|  | WS-01000A/U, <br>WS-04000A/U Series | 1×1, 1×4 | U-band | 減衰と位相が任意 |
| [WaveShaper B-Series]( | WS 500B-Series | 1×1 | Super C-band,<br>Super L-band | 減衰が任意 |
|  | WS 1000B-Series | 1×1 | Super C-band,<br>Super L-band,<br>C+L-band<br>O-band | 減衰と位相が任意 |
|  | WS 4000B-Series | 1×4 | Super C-band,<br>Super L-band,<br>C+L-band | 減衰と位相が任意減衰と位相が任意 |
|  | WS 3200xB-Series | 1×31, 4×28, 8×24,<br>12×20, 16×16 | Super C-band,<br>Super C+ Super L-band | 減衰と位相が任意 |
### WaveShaper 1000A/SP の使用詳細
### WaveShaper 1000A/SP 原理
WaveShaper 1000A/SP の入力コネクタから入ってきたレーザーは、回折格子によって波長分解され、LCoS上に照射されます。LCoSでステアリング（方向を制御されて反射）された光は再び回折格子を通して出力ファイバに結合されます。
スペクトルの振幅制御は、ビームが出力ファイバへ入射するときの結合率を制御することで最大25~35 dBの減衰を与えます。位相（群遅延）は、LCoSでステアリングされたビームパスを制御することで実現します。
WaveShaper 1000A/SP は USB 2.0 もしくはギガビットイーサネットで PC に接続して使用します。パルス制御専用のソフトウェアの用意もございます。LabView、Matlab、Python,、Octave、Visual Basic、C# のサンプルコードもご用意しています。お客様のシステムに合わせて制御ソフトウェアをお造りいただけます。
## セブンシックスの技術サポート
導入前・導入後のご相談、承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyze のポテンシャルを最大限に引き出す当社 [オリジナル・ソフトウェア]( のサポート
- WaveShaper・WaveAnalyze の修理対応 (電源系、ファン、ファイバ端面等の交換・修理)
### 解説・関連動画📢
### Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
エクセルと一緒にご使用いただく Python ベースのソフトウェアを新たに開発しました！Matlabベースのソフトとの違いなど、詳細ついては下記動画をご視聴ください。
▼ 『WaveShaper』セブンシックス製ソフト①～③ 任意スペクトル・パルス生成 │ Vol.010～012  (Matlabベース)
複雑なフィルタ形状を簡単に設定
目的のスペクトル形状を生成する
光パルスを最短パルス化させる
▼ WaveShaper/光任意波形整形器：これ1台で自由自在？！ │Vol.008
▼ Coherent社 Super C-band WaveShaper/Analyzer新登場│Vol.77
## 資料ダウンロード
- [カタログ：WaveShaper『1000A/SP』](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-1000a-sp-ds.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/2)
- 超短パルスファイバレーザー『iQoM』 - 波長: 1040 / 1064 nm　パルス幅: 3 - 15 / 2 - 8 psセブンシックス株式会社ファイバーレーザー・その他光源
- 光周波数コム発生器 Frush - 波長帯 1550 nm / FSR 12－18 GHzセブンシックス株式会社ファイバーレーザー・その他光源
- C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』 - 帯域幅：1527.8 ~ 1610.05nmCoherent (旧 II-VI)光計測器
- ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』 - Super C-band帯 (1523.9 ~ 1572.7nm)対応Coherent (旧 II-VI)光計測器
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバーCoherent (旧 II-VI)光計測器
- 通信帯域 スペクトル・分散制御プロセッサ WaveShaper A/Bシリーズ - O / S / C / L / U-band対応Coherent (旧 II-VI)光増幅器/ 光変調器/ PD/ 光フィルタ他