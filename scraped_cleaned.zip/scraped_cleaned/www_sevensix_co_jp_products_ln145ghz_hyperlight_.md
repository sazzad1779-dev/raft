# Source URL: https://www.sevensix.co.jp/products/ln145ghz_hyperlight/

# 
# 薄膜LN 145GHz光強度変調器
C/O-band
_メーカ：_ HyperLight
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 強度変調器
- 光変調器
従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現する
薄膜LN方式の光変調器メーカ：Hyperlight社の145GHz強度変調器です。
C-bandとO-bandの2波長に対応し、Low VπモデルとRegular Vπモデルの2タイプがございます。
製品のお問い合わせ･お見積
## 特長
- \> 145 GHz bandwidth
- 0.8mm connector
- High extinction ratio
- Stable DC biasing
- High optical and RF power handling
- C-band, O-band support
## 用途
- 260 Gbaud testing
- 140 Gbaud testing
- 70 GHz single sideband modulation
## 資料ダウンロード
- [カタログ：薄膜LN 145GHz光強度変調器](https://www.sevensix.co.jp/wp-content/uploads/145GHz-IM.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ