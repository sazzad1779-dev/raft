# Source URL: https://www.sevensix.co.jp/products/ea4000_exfo/

# 
# 超高速サンプリング・オシロスコープ『EA-4000』
波長: 830 ~ 1600nm　帯域幅: 33GHz
_メーカ：_ EXFO
- 光計測器
- BERT
- サンプリング・オシロスコープ
高速測定に対応(2秒以内に1000以上の波形計測可能)した28G NRZシグナル対応、830～1600nmフルレンジ、広帯域(33GHz)の光サンプリング・オシロスコープです。
製品のお問い合わせ･お見積
## 特長
- 超高速スコープ 1M サンプル/秒、2秒以内に1000以上の波形を測定(2000 サンプル/波形)
- 28G NRZシグナル対応
- 低ジッタモードをサポート
- フルレンジモデル(830～1600nm)とシングルモードモデル(1250～1600nm)をサポート
### ■ 超高速スコープ
業界最速の高速測定（1000波形を2秒以内）で、光コンポーネントの生産ラインにおける検査工数の削減、スループットの向上が可能です。
### ■ 低ジッタモードをサポート
## 仕様詳細
### ■ 電気特性
|     |     |
| --- | --- |
| サンプリング速度 | 1,000,000 サンプル/秒 |
| 帯域幅(Bandwidth) | 33 GHz (typical at 3 dB bandwidth) |
| 入力レンジ | max 1.0 Vppd |
| Damage amplitude | max 1.7 Vppd |
| コネクタタイプ | K(female) (50 Ω) |
| リターンロス | K(female) (50 Ω) |
| RMS ノイズ | 2.0 mV(typical) / 2.5 mV(max) |
### ■ 光学特性
|     |     |
| --- | --- |
| 帯域幅(Unfiltered) | 33 GHz |
| 動作波長 | フルレンジモデル：830～1600 nm<br>シングルモードモデル：1250～1600 nm |
| リターンロス | –24 dB (フルレンジモデル)<br>–30 dB (シングルモードモデル) |
| Mask sensitivity<br>(CWDM4 mask, mask margin 0%, hit count 0) | –8 dBm (typical at 850 nm)<br>–10 dBm (typical at 1310 nm) |
| Damage power | 8 mW |
| コネクタタイプ | FC/PC (50/125 µm) (フルレンジモデル)<br>FC/PC (9/125 µm) (シングルモードモデル) |
### ■ クロック特性
|     |     |
| --- | --- |
| Clock input ratio | /8, /16, /32, /64 |
| Trigger jitter | <290 fs (typical) |
| Sensitivity | 100 mV (typical) |
### ■ 紹介動画
## 資料ダウンロード
- [スペックシート：超高速サンプリング・オシロスコープ『EA-4000』](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_ea-4000_v6_en.pdf#view=Fit)
- [パンフレット：光トランシーバテスト製品ラインナップ \- 最大800G伝送速度](https://www.sevensix.co.jp/wp-content/uploads/c0e90febf49b7bdbef1693a146c5fa68-3.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ