# Source URL: https://www.sevensix.co.jp/products/pmfc_optizone/

# 
# 偏波保持フィルタカプラ
波長: 1064 ~ 2000nm　ポート数: 1×2 / 2×2
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- フィルタカプラ \*Tapカプラ含む
- 光ファイバカプラ
中国の深センに拠点を構えるOptizone Technologiesの偏波保持フィルタカプラです。
全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。
年間20,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。
高出力用受動部品を特に得意としており、中国の深センにかまえる9,000㎡の大規模な工場で、
カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
## 特長
- 高い消光比
- 低挿入損失
- 高リターンロス
## 用途
- ファイバーレーザ
- EDFA、ラマン分光
- センサー
## 仕様詳細
|     |     |
| --- | --- |
| 波長 | 1064nm、1310nm、1550nm、2000nm、その他も対応可 |
| ポート数 | 1×2、2×2 |
| ハンドリングパワー | 0.5W、1W |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他組も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準0.8m、1m、その他も対応可 |
＊ハイパワー対応の製品も取り扱い御座います
## 資料ダウンロード
- [データシート：1064nm 1×2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-018D-PMFC-1030-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-017C-PMFC-1030-1064nm-2x2-1.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-019C-PMFC-1310nm1550nm-1x2-2x2-1.pdf#view=Fit)
- [データシート：2000nm 1×2、2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-015C-PMFC-2000nm-1x2-2x2-1.pdf#view=Fit)
- [データシート：1064nm 1×2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-045D-HPMFC-1030-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/SR2101011B-HPMFC-06-2-50-F-0.5-NNNN-BBBB-0.8-04A-01.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-046C-HPMFC-1310nm1550nm-1x2-2x2-1.pdf#view=Fit)
- [データシート：2000nm 1×2、2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-059B-HPMFC-2000nm-1x2-2x2-1.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2x2 Mini Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/MPMFC-1310nm-1550nmCAT-09-037B.pdf#view=Fit)
- [データシート：1310nm、1550nm 1×2、2x2 Polarization Maintaining Filter Coupler (High Extinction Ratio)](
## 製品に関するお問い合わせ
この製品のお問い合わせ