# Source URL: https://www.sevensix.co.jp/products/mems_nonlactchswitch_agiltron/

# 
# MEMS型 ノンラッチ光スイッチ
波長: 1260 ~ 1610nm　ポート数: 1x2 / 2x2
_メーカ：_ Agiltron Inc.
- 光増幅器/ 光変調器/ PD/ 光フィルタ他
- 光スイッチ
独自の熱活性化マイクロミラーを使用して光チャンネルを接続し、光路を移動させ、
長期ドリフトのない高い安定性、フェイルセーフラッチング、速い設定時間、および5V直接駆動の利便性を独自に特徴としています。
製品のお問い合わせ･お見積
## 特長
- 高い安定性
- 速い設定時間
- 5V直接駆動の利便性
- 低挿入損失
- 高速スイッチング
## 用途
- 光アクセス
- 基幹系インフラ
- 通信
## 仕様詳細
|     |     |     |     |
| --- | --- | --- | --- |
| パラメータ | 最小値 | 中央値 | 最大値 |
| 動作波長 (nm)<br>シングルモード<br>マルチモード | 1260<br>810<br>1260 |  | 1610<br>890<br>1360 |
| 挿入損失 \[1\], \[2\]<br>シングルバンド<br>デュアルバンド |  | 0.6<br> – | 1.0<br>1.2 \[3\] |
| PDL シングルモード |  |  | 0.1 |
| リターンロス \[1\]<br>シングルモード<br>マルチモード | 50<br>35 |  |  |
| クロストーク \[1\]<br>シングルモード<br>マルチモード | 50<br>35 |  |  |
| 切替時間 |  | 10 |  |
| 繰り返し精度 |  |  | ±0.05 |
| 繰返し周波数 |  | 10 |  |
| 耐久性 | 109 |  |  |
| スイッチング方式 |  | Non-Latching |  |
| 動作温度 | -5 |  | 70 |
| 保存温度 | -40 |  | 85 |
| 光パワーハンドリング |  | 300 |  |
| パッケージ寸法 |  | 13L x 9W x 6H |  |
| ファイバタイプ<br>シングルモード <br>マルチモード |  | SMF-28 <br>MM 50/125, MM 62.5/125<br>equivalent |  |
## 資料ダウンロード
- [データシート：MEMS型 ノンラッチ光スイッチ](https://www.sevensix.co.jp/wp-content/uploads/MEMS-Dual-1x2-Dual-2x2-Non-Latching-Series-Switch.pdf#view=Fit)
- [ESD Analysis of Thermal Actuated MEMS Chips](https://www.sevensix.co.jp/wp-content/uploads/ESD-Qualification-Report-11-11-2021-F.pdf#view=Fit)
- [テストレポート：Vibration Test Report](https://www.sevensix.co.jp/wp-content/uploads/Vib-Test-Report-3-11-2017.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ