# Source URL: https://www.sevensix.co.jp/products/hnpcfiber_nktp/

# 
# 高非線形フォトニック結晶ファイバ
波長：0.8um帯 / 1um帯
_メーカ：_ NKT Photonics A/S
- 光ファイバ素線 / 光ファイバパッチコード
- シングルクラッドファイバ
- PMファイバ
- PMファイバ
- フォトニック結晶ファイバ
0.8 um & 1 um用のレーザーを種光源とした白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバ＆ファイバデバイス
製品のお問い合わせ･お見積
## ◆ 白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバ
NL-PM-750はTi:Sapphireレーザや780nmモードロックErファイバレーザなどを種光源とする白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶PMファイバ 、
SC-5.0-1040はマイクロチップレーザや1umモードロックYbファイバレーザなどを種光源とする白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶SMファイバ 、
SC-5.0-1040-PMは マイクロチップレーザや1umモードロックYbファイバレーザなどを種光源とする白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶PMファイバです。
### 特長
•小さいモードフィールド径
•高い非線形係数
## ◆ 白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバデバイス：FemtoWHITE シリーズ
FemtoWHITE 800は800nm帯のTi:Sapphireレーザを種光源とする白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバデバイス、
FemtoWHITE CARSは800nm帯のTi:SapphireレーザやモードロックErファイバレーザなどを種光源とするCARS (Coherent Anti-stokes Raman Scattering)用途の る白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバデバイス です。
### 特長
- メンテナンスフリー
- お持ちのTi:Sapphireレーザの利用が可能
- 標準のホルダーとの互換性
- コンパクトデザイン
- 堅牢な構造
## 資料ダウンロード
- [データシート：NL-PM-750 / SC-5.0-1040 / SC-5.0-1040-PM](https://www.sevensix.co.jp/wp-content/uploads/Non-linear-fibers.pdf#view=Fit)
- [アプリケーションノート：白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/Supercontinuum-application-note.pdf#view=Fit)
- [アプリケーションノート：SC-5.0-1040を用いた白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/Supercontinuum-application-note-SC-5.0-1040.pdf#view=Fit)
- [データシート：FemtoWHITE 800 / FemtoWHITE CARS](https://www.sevensix.co.jp/wp-content/uploads/FemtoWhite.pdf#view=Fit)
- [アプリケーションノート：FemtoWHITE CARSを用いた白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/FemtoWHITE-CARS-application-note.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ