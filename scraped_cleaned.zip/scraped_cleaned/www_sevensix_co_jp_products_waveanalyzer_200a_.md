# Source URL: https://www.sevensix.co.jp/products/waveanalyzer_200a/

# 
# ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』
Super C-band帯 (1523.9 ~ 1572.7nm)対応
_メーカ：_ Coherent (旧 II-VI)
- 光計測器
- 光スペクトラムアナライザ
✓業界初のポータブル式
✓タッチパネル式モニタ(7インチ)を搭載
✓Super C-band帯(1523.9 ~ 1572.7nm)対応、高い分解能(650MHz(4pm)
✓高速スイープ 0.5秒／スキャン
さらに、弊社ではWaveAnalyzer のポテンシャルを最大限に引き出す
当社オリジナル・ソフトウェアのサポートをご提供しております。
製品のお問い合わせ･お見積
## 特長
- Super C-band帯 高い分解能帯域幅 : 650MHz(4pm)
- タッチパネル式モニタ(7インチ)を搭載
- リアルタイム測定 0.5秒＠フルSuper C-bandスキャン
- 超小型軽量 1.25kg　255 mm x 140 mm x 30 mm
## 用途
①波長多重通信(WDM)伝送路の品質チェック
コヒーレント通信等の波長多重通信伝送路の現地調査・定期メンテナンス等において、高分解能な光スペクトル分析や
光パワーレベル・中心波長・OSNR等の各種測定・解析を行うことができます。
②LiDAR用レーザ光の分析
自動運転などにおいて、LiDARの有効性検証を屋外で実験する場合、通常のスペアナと異なり容易に持ち運びが可能です。
③光ファイバセンサー敷設現場でのメンテナンス作業
光ファイバセンサー敷設現場の現地調査やメンテナンス作業において、入射パルス光やブリルアン散乱光を
高分解能でスペクトル解析可能です。
## 仕様詳細
| Model | WA 200A (C-Band) | WA 200B<br> (Super C-Band) |
| --- | --- | --- |
| Spectral |  |  |
| Frequency Range | 191.1 to 196.2 THz<br> (1527.8 to 1568.8 nm) | 190.623 to 196.727 THz<br> (1523.9 to 1572.7 nm) |
| Spectral Sampling Resolution | 312.5 MHz | 312.5 MHz |
| Resolution Bandwidth (FWHM) | 1.75 GHz (15 pm) | 650 MHz (4 pm) |
| Absolute Frequency Accuracy (1) | \+/\- 1 GHz | \+/\- 1 GHz |
| Frequency Repeatability (sweep to sweep) | 200 MHz | 200 MHz |
| Measurement Update Rate <br>Full C-band scan | 2 updates / s (typical) | 2 updates / s (typical) |
| **Power** |  |  |
| Max Total Power | 27 dBm | 27 dBm |
| Max Power Density | +11.5 dBm / 1.75 GHz | +11.5 dBm / 1.75 GHz |
| Noise floor | -58.5 dBm / 1.75 GHz | -58.5 dBm / 1.75 GHz |
| Relative Power Accuracy | +/-0.5 dB (2) | +/-0.5 dB (2) |
| **Mechanical, Electrical and Environment** |  |  |
| Operating Temperature | 5°C to 35°C | 5°C to 35°C |
| Operating Humidity | 10% to 85% | 10% to 85% |
| Communications Interface | Ethernet, USB 2.0 (master) | Ethernet, USB 2.0 (master) |
| Power Consumption (3) | 100 V – 240 V; 40 VA | 100 V – 240 V; 40 VA |
| Connector Type | FC/APC, LC/UPC | FC/APC, LC/UPC |
| Size | Instrument only | 255 mm x 140 mm x 30 mm |
|  | instrument including protective bumper | 273 mm x 168 mm x 50 mm |
| Weight | Instrument only | 1.25 kg |
|  | instrument including protective bumper | 1.5 kg |
Notes:
(1) Valid within recommended recalibration period
(2) Guaranteed when using an ASE source
(3) Condition: Battery is charging and instrument is operated
## セブンシックスの技術サポート
導入前・導入後のご相談、承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyze のポテンシャルを最大限に引き出す当社 [オリジナル・ソフトウェア]( のサポート
- WaveShaper・WaveAnalyze の修理対応 (電源系、ファン、ファイバ端面等の交換・修理)
### 解説・関連動画📢
### Coherent社WaveShaperオリジナルソフト『SAF』解説│Vol.126
エクセルと一緒にご使用いただく Python ベースのソフトウェアを新たに開発しました！Matlabベースのソフトとの違いなど、詳細ついては下記動画をご視聴ください。
▼ 『WaveShaper』セブンシックス製ソフト②
任意スペクトル・パルス生成 │ Vol.011 (Matlabベース)
▼ Coherent社
Super C-band WaveShaper/Analyzer新登場│Vol.77
▼ スイープ速度
▼ 『WaveAnalyzer』超高分解能スペアナ登場！│Vol.009
## 資料ダウンロード
- [カタログ：WaveAnalyzerシリーズ](https://www.sevensix.co.jp/wp-content/uploads/20250917_WaveAnalyzer_Family.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ
## 関連製品
(1/1)
- 400GbE/100GbE QSFP 光トランシーバ - 400G/100GbpsCoherent (旧 II-VI)光通信/ 同軸・RF関連
- C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』 - 帯域幅：1527.8 ~ 1610.05nmCoherent (旧 II-VI)光計測器
- 超高波長精度 光スペクトラムアナライザ『WaveAnalyzer 1500B』 - C+L-band対応(1526.8～1612.6 nm)Coherent (旧 II-VI)光計測器
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバーCoherent (旧 II-VI)光計測器