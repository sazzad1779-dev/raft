# Source URL: https://www.sevensix.co.jp/products/fr_optizone/

# 
# インラインファラデーローテータ
波長: 1310 ~ 1550nm
_メーカ：_ Optizone Technology Limited
- 光ファイバ部品
- その他光ファイバ部品
中国の深センに拠点を構えるOptizone Technologiesのインラインファラデーローテータです。全製品Telcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えております。年間18,000ケ以上を生産をしており、主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷しております。高出力用受動部品を特に得意としており、中国の深センにかまえる9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。
製品のお問い合わせ･お見積
#### **特長**
- 高リターンロス
- 高消光比
- 低挿入損失
#### **用途**
- ファイバセンサ
- 光増幅器
- ファイバレーザ
#### **仕様詳細**
|     |     |
| --- | --- |
| 波長 | 1310nm、1480nm、1550nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、400umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバタイプ | PM Panda Fiber、SMF-28e Fiber |
| ファイバ長 | 標準1m、その他も対応可 |
#### **パッケージタイプ**
標準タイプ
小型サイズ
## 資料ダウンロード
- [データシート：In-line Faraday Rotator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-001C-ILF-1310nm1550nm.pdf#view=Fit)
- [データシート：Mini In-line Faraday Rotator](https://www.sevensix.co.jp/wp-content/uploads/MILF-1310nm1550nmCAT-09-041C.pdf#view=Fit)
## 製品に関するお問い合わせ
この製品のお問い合わせ