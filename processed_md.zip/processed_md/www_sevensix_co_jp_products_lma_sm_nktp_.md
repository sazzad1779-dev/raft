# ラージモードエリアフォトニック結晶ファイバ / SMF

**カテゴリ:** 光ファイバ素線 / 光ファイバパッチコード  
**中カテゴリ:** フォトニック結晶ファイバ  
**小カテゴリ:** SMファイバ  
**メーカー:** NKT Photonics A/S  
**波長:** 400 ~ 1700 nm  

ラージモードエリアフォトニック結晶ファイバ / SMFは、最大400~1700 nmの広帯域の光をシングルモードで、かつ低ロスで伝搬が可能な唯一のファイバです。

## 特長
- シングルモード伝送
- 高出力＆高パルスエネルギー対応
- 低非線形性
- 5~25μmコア径と幅広い製品ラインナップ

## 仕様詳細
この製品の仕様は以下の通りです。

| 特徴               | 詳細                       |
|--------------------|----------------------------|
| モード             | シングルモード             |
| 波長範囲           | 400 ~ 1700 nm              |
| コア径             | 5 ~ 25 μm                  |
| 非線形性           | 低非線形性                 |
| 出力               | 高出力＆高パルスエネルギー対応 |

## 資料ダウンロード
- [データシート：LMAファイバ (SMF)](https://www.sevensix.co.jp/wp-content/uploads/LMA-fibers.pdf#view=Fit)
- [データシート：LMAファイバ (PMF)](https://www.sevensix.co.jp/wp-content/uploads/LMA-PM-fibers.pdf#view=Fit)
- [データシート：LMAファイバ (PM-1550)](https://www.sevensix.co.jp/wp-content/uploads/PM-1550.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の資料を参照してください。

# Source URL: https://www.sevensix.co.jp/products/lma_sm_nktp/