# スクリュー型 VOA

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** その他光ファイバ部品  
**小カテゴリ:** VOA（光可変減衰器）  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 1060 ~ 2000nm  
**入力パワー:** 300mW ~ 5W  

Optizone Technology Limitedは、中国の深センに拠点を構える光可変アッテネータのメーカーです。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、高品質・高安定性を兼ね備えています。年間1,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9,000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高リターンロス

## 用途
- ファイバーレーザ
- 研究用途

## 仕様詳細
以下の表は、スクリュー型VOAの主要な仕様を示しています。

| 項目         | 詳細内容                                                                 |
|--------------|--------------------------------------------------------------------------|
| 波長         | 1060nm、1310nm、1550nm、1590nm、2000nm、その他も対応可                 |
| 入力パワー   | 300mW                                                                   |
| コネクタタイプ| FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可                  |
| ファイバ被膜 | 250umファイバ、900umルーズチューブ、2mmケーブル、3mmケーブル、その他も対応可 |
| ファイバ長   | 標準0.8m、1m、その他も対応可                                           |

## パッケージタイプ
- 標準タイプ
- 2×2タイプ

## 資料ダウンロード
- [データシート：1064nm、1310nm、1550nm Mini Type Manual Variable Optical Attenuator](https://www.sevensix.co.jp/wp-content/uploads/MVOA-1064-1550nm-1.pdf#view=Fit)
- [データシート：1064nm、1310nm、1550nm Polarization Maintaining Mini Type Manual Variable Optical Attenuator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-045D-PMVOA-1064-1550nm.pdf#view=Fit)
- [データシート：1310nm、1550nm、1590nm、2000nm Micro Electronic Mechanical System Variable Optical Attenuator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-046A-MEMSVOA-31552000nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[製品URL](https://www.sevensix.co.jp/products/st_voa_optizone/)