# 狭線幅レーザー『Koheras』用 光増幅モジュール『Koheras Boostik』

## 概要
- **カテゴリ**: 光増幅器
- **小カテゴリ**: 光ファイバアンプ
- **メーカー**: NKT Photonics A/S
- **モデル**: 型番なし
- **波長範囲**: 1545 ~ 1565 nm
- **出力**: 2 W

NKT Photonics社の狭線幅レーザー『Koheras BASIK』用のコンパクトな光増幅器で、1.5um帯の波長範囲1545 - 1565 nmで動作し、最大出力は2 Wです。マルチチャンネルシステムである『Koheras ACOUSTIK』への搭載も可能です。

## 特長
- 強度・位相雑音と線幅を維持したままの増幅が可能
- 産業向けOEMパッケージ
- マルチチャンネルシステム向け設計 (ACOUSTIK)
- メンテナンスフリー
- PM出力（non-PM出力は要相談）
- Koheras BASIKの強度雑音を20 dBほど下げるオプションあり

## Koheras Boostik 仕様
### Koheras ACOUSTIK マルチチャンネルプラットフォーム
『Koheras ACOUSTIK』は、Koheras BASIK単一周波数低ノイズファイバレーザとKoheras BOOSTIK光増幅器を搭載可能な電源込みのラックシステムです。ACOUSTIKは、搭載中のKoheras BASIKやKoheras BOOSTIKに電源を供給し、それぞれを制御します。BASIKとBOOSTIKは簡単にACOUSTIKに出し入れできます。

Koheras ACOUSTIKは、堅牢性が求められる産業用途に対応するため、パッシブ冷却システムデザインとなっています。マルチチャンネルのセンサシステム用に設計されており、標準的な3U 19インチラック筐体には制御エレクトロニクスと電源が含まれています。各BASIKやBOOSTIKレーザモジュールには、ACOUSTIKのフロントパネルから直接アクセスできます。Koheras ACOUSTIKと搭載したBASIKとBOOSTIKモジュールは、NKT Photonicsが無償配布しているCONTROLソフトウェアを用いて制御することができます。

## 資料ダウンロード
- [『Koheras BOOSTIK』データシート](https://www.sevensix.co.jp/wp-content/uploads/Koheras_BOOSTIK.pdf#view=Fit)
- [『Koheras ACOUSTIK』データシート](https://www.sevensix.co.jp/wp-content/uploads/Koheras_ACOUSTIK-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。

# Source URL: https://www.sevensix.co.jp/products/koherasboostik_e15_nktp/