# 超短パルス1ns LDドライバ

**カテゴリ:** 半導体レーザーダイオード（LD）  
**中カテゴリ:** LDコントローラ/ドライバ  
**メーカー:** 株式会社トリマティス  
**モデル:** 型番なし  
**Source URL:** [https://www.sevensix.co.jp/products/1nsldd_trimatiz/](https://www.sevensix.co.jp/products/1nsldd_trimatiz/)

超短パルス「1ナノ秒」を実現するLDドライバです。

## 特長
- LD直接駆動方式で1nsの電流パルス幅を達成
- 高変換効率、小型、低コストのピコ秒レーザ光源を実現

## 用途
- ファイバーレーザ用シード光源
- 各種分析/計測機器
- 3Dセンシング
- LIDAR
- センシング / デバイス評価

## 仕様詳細
以下の表は、超短パルス1ns LDドライバの主要な仕様を示しています。

| パラメータ         | 値          |
|------------------|-------------|
| パルス幅         | 1ns         |
| 繰返し周波数     | 2000kHz     |
| 電流値           | 1A          |

## 資料ダウンロード
- [カタログ：超短パルス1ns LDドライバ『LDD-PU-200』](https://www.sevensix.co.jp/wp-content/uploads/1uLD%E3%83%89%E3%83%A9%E3%82%A4%E3%83%90.pdf#view=Fit)