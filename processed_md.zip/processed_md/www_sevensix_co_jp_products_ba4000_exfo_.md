# ビットエラーレートテスター(BERT)『BA-4000』

- **カテゴリ**: 光計測器
- **中カテゴリ**: BERT
- **小カテゴリ**: BERT
- **メーカー**: EXFO
- **モデル**: 型番なし
- **対応伝送規格**: 400G / 800G

ビットエラーレートテスター(BERT)『BA-4000』は、800GbE/400GbE等のPAM4変調方式を用いた高速伝送規格の対応デバイス（光トランシーバ・OSA・FPGA等）の試験・評価に最適な製品です。

## 特長
- 800G/400G/200G/100Gの伝送規格向けテストをフルサポート (～56GBd, NRZ/PAM4, ～8チャネル)
- バーストエラー分析に必須のFECシミュレーション機能
- 生成信号の高品質なアイパターン
- RFインターフェースに着脱容易なO-SMPMコネクタ採用
- PRBS 7/9/11/13/15/23/31/13Q/31Q, SSPRQをサポート

## 用途
- 光トランシーバ、OSA(Optical Sub Assembly)の試験、評価
- FPGA、MCB(Module Compliance Board)、HCB(Host Compliance Board)の試験、評価

## 仕様詳細

### FECシミュレーション機能
BA-4000のFECシミュレーション機能は、バーストエラーに対する様々な分析機能を提供します。以下の機能をサポートしています。
- PRBSエラーチェック及び訂正
- Pre-FEC及びpost-FEC BER
- KP4/KR4及び低遅延FECプロトコル
- FEC lane striping
- FECシンボルエラー分布表示: codewords vs. シンボルエラー
- FECマージン自動計算

### O-SMPMコネクタ
測定系構築時の着脱操作が容易に可能で、各種高周波コネクタ(K, 2.4mm, SMPM, 1.85mm)に対応したケーブルもサポートしています。

### 高品質なアイパターン
53GBd PAM4の生成信号においてアイ幅 > 6psと、高品質なアイパターンの生成が可能です。

### 使いやすいGUI
ユーザーフレンドリーなGUI設計です。詳しくは参考動画①の1分22秒以降もご参照ください。

## 資料ダウンロード
- [スペックシート：ビットエラーレートテスター(BERT) – 『BA-4000』](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_ba-4000_v7_ja.pdf#view=Fit)
- [パンフレット：光トランシーバテスト製品ラインナップ - 最大800G伝送速度](https://www.sevensix.co.jp/wp-content/uploads/c0e90febf49b7bdbef1693a146c5fa68-1.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/ba4000_exfo/