# 偏波保持パッチコード

## 概要
- **カテゴリ**: 光ファイバ素線 / 光ファイバパッチコード
- **中カテゴリ**: 光ファイバパッチコード
- **小カテゴリ**: PMファイバパッチコード
- **メーカー**: Optizone Technology Limited
- **品名**: 偏波保持パッチコード
- **波長**: 980 ~ 1550nm

Optizone Technology Limitedは、中国の深センに拠点を構える企業で、偏波保持パッチコードを提供しています。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、高品質・高安定性を兼ね備えています。年間15,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を得意としており、9,000㎡の工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低損失
- 高リターンロス

## 用途
- 研究開発
- ファイバレーザ

## 仕様詳細
以下の表は、偏波保持パッチコードの主要な仕様を示しています。

| 項目         | 詳細内容                                                                 |
|--------------|--------------------------------------------------------------------------|
| 波長         | 980nm、1064nm、1310nm、1480nm、1550nm、その他も対応可                  |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、FERRULE UPC、LC/PC、FERRULE APC、MU/PC、E2000/APC、MPO/APC（SM8core）None |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可                |
| ファイバ長   | 標準1m、その他も対応可                                                  |

## 資料ダウンロード
- [データシート：980nm、1060nm、1310nm、1480nm、1550nm Polarization Maintaining Fiber Patchcord](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-029D-PMP-405nm2000nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。

# Source URL: https://www.sevensix.co.jp/products/optizone_pmpatchcode/