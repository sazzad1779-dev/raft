大カテゴリ: 半導体レーザーダイオード（LD）  
中カテゴリ: シードLD  
メーカ: eagleyard Photonics GmbH  
品名: シングルモード半導体レーザー  

モデル:  
- モデル: (型番なし)  

# Source URL: https://www.sevensix.co.jp/products/smld_eagleyard/

## シングルモード半導体レーザー
- 波長: 808 ~ 1064nm  
- 出力: 100 ~ 800mW  
- メーカ： Toptica Eagleyard  
- 半導体レーザーダイオード（LD）  
- シードLD  
- ファブリペローレーザー  

TOPTICA eagleyard のファブリペローレーザーは、全ての製品がISO 9001:2015で要求される厳格な品質基準に準拠しています。

## 特長
- 808, 850, 1060nm 単一周波数レーザ
- 波長線幅が狭く、応答性の高いレーザー光源。宇宙衛星向けとしても実績あり
- パッケージは、hermetic TO Housing / hermetic Butterfly Package / FlatPack Package with Window

## 用途
- イルミネーション
- 干渉計
- マテリアルプロセッシング
- Ndドープファイバーポンプ
- 光ピンセット
- センシング

## 仕様詳細
この仕様表は、各モデルの波長、出力パワー、モード、パッケージタイプを比較しています。以下のモデルが含まれています。

| 製品名 | 波長 (nm) | 出力パワー (W)　<br>\*推奨 | モード | パッケージ |
| --- | --- | --- | --- | --- |
| [EYP-RWL-0808-00400-4000-BFY02-0000]( | 808 ± 4 | 0.8 | CW | hermetic Butterfly Package |
| [EYP-RWL-0808-00800-4000-BFW09-0000]( | 796(Min)<br>808(Typ)<br>816(Max) | 0.8 | CW | hermetic Butterfly Package |
| [EYP-RWL-0850-00100-1500-SOT12-0000]( | 850 ± 10 | 0.1 | CW | hermetic TO Housing |
| [EYP-RWL-1060-00100-1300-SOT01-0000]( | 1060 ± 10 | 0.1 | CW | hermetic TO Housing |
| [EYP-RWL-1060-00750-4000-FLW01-0006]( | 1064 ± 10 | 0.65(min) | パルス | FlatPack Package with Window |

## 製品に関するお問い合わせ
この製品のお問い合わせ