# ファイバ付 高出力 半導体マルチモードレーザー 878.6nm

**カテゴリ:** 半導体レーザーダイオード（LD）  
**中カテゴリ:** ファブリペローレーザー  
**小カテゴリ:** MMファイバ  
**メーカー:** BWT Beijing LTD.  
**モデル:** (型番なし)  

**波長:** 878.6 ~ 888nm  
**出力:** 30 ~ 170W  

この製品は、高出力波長安定化ファイバ結合ダイオードレーザーで、最大出力170Wに対応しています。全製品はRoHS・REACH規制物質に準拠しています。

## 特長
- 878.6nm VBG品または888nmで選択可能
- 高効率、安定性、優れたビーム品質で固体レーザーの励起に最適

## 用途
- 固体レーザー励起

## 仕様詳細
以下の表は、ファイバ付高出力半導体マルチモードレーザーの主要な仕様を示しています。各モデルは異なる出力と波長を持ち、固体レーザー増幅に使用されます。

| 製品名 | 型式 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| --- | --- | --- | --- | --- | --- | --- |
| 878.6nm 30W Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BAHRN-30.00W]( | 878.6 | 30 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 65W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BNLRN-65.00W]( | 878.6 | 65 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 120W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BL9RN-120.0W]( | 878.6 | 120 | 200 | 0.22 | 固体レーザー増幅 |
| 878.6nm 170W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K878BL9RN-170.0W]( | 878.6 | 170 | 200 | 0.22 | 固体レーザー増幅 |
| 888nm 120W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K888BL9RN-120.0W]( | 888 | 120 | 200 | 0.22 | 固体レーザー増幅 |
| 888nm 170W High Power Wavelength-Stabilized Fiber Coupled Diode Laser | [K888BL9RN-170.0W]( | 888 | 170 | 200 | 0.22 | 固体レーザー増幅 |

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[Source URL](https://www.sevensix.co.jp/products/ld878nm_bwt/)