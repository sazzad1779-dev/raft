# シングルモードアイソレータ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** 光ファイバアイソレータ  
**小カテゴリ:** SMアイソレータ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 1064 ~ 2000nm  

Optizone Technology Limitedのシングルモードアイソレータは、中国の深センに拠点を構え、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高アイソレーション
- 低偏波依存性損失

## 用途
- 光ファイバ増幅器
- ファイバレーザ

## 仕様詳細
以下の表は、シングルモードアイソレータの主要な仕様を示しています。

| 項目             | 内容                                                         |
|------------------|------------------------------------------------------------|
| 波長             | 1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可   |
| ステージ         | シングルステージ、デュアルステージ                        |
| コネクタタイプ   | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可     |
| ファイバ被膜     | 250umベアファイバ、900umルーズチューブ、その他も対応可   |
| ファイバ長       | 標準1m、その他も対応可                                     |

## パッケージタイプ
- 小型サイズ
- 標準サイズ

## 資料ダウンロード
- [データシート：1064nm Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-07-003C-PII-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-07-004D-PII-1310nm1550nm-1.pdf#view=Fit)
- [データシート：2000nm Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-011C-PII-2000.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Twin Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-07-006D-TPII-1310nm1550nm.pdf#view=Fit)
- [データシート：1550nm Mini Twin Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-07-007B-MTPII-1550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/sm_isolator_optizone/)から。