# 製品概要

製品名: [Space] Low-noise optical amplifier  
モデル: (モデルなし)  
カテゴリ: 光増幅器  
中カテゴリ: 光増幅器  
サブカテゴリ: テーパードアンプ  
メーカー: exail  

[製品の詳細はこちら](https://www.sevensix.co.jp/products/ixs-lnoa-cx-rad_exail/)