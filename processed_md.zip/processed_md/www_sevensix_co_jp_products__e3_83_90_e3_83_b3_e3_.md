# バンドパスフィルタ

## 製品概要
- **品名**: バンドパスフィルタ
- **モデル**: (型番なし)
- **メーカー**: Optizone Technology Limited
- **カテゴリ**: 光ファイバ部品 > その他光ファイバ部品
- **波長範囲**: 1064 ~ 1565nm
- **バンド幅**: 5 / 37nm

Optizone Technology Limitedは、中国の深センに拠点を構える企業で、全製品はTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間20,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9,000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 高分離
- 低挿入損失
- ハイリターンロス

## 用途
- レーザ
- 増幅機能

## 仕様詳細
以下の表は、バンドパスフィルタの主要な仕様を示しています。

| 項目           | 内容                                   |
|----------------|----------------------------------------|
| 波長           | 1064nm、1528nm～1565nm、その他も対応可 |
| バンド幅       | 5nm、37nm、その他も対応可             |
| ストップバンド幅 | 22nm、53nm、その他も対応可            |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜   | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長     | 標準1m、その他も対応可                 |

## 資料ダウンロード
- [データシート：1064nm Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/BPF-1064nm-CAT-04-002C.pdf#view=Fit)
- [データシート：1528nm～1565nm SMF Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/BPF-CAT-04-003D.pdf#view=Fit)
- [データシート：1528nm～1565nm PM Bandpass Filter](https://www.sevensix.co.jp/wp-content/uploads/PMBPF-2865nm-CAT-09-043C.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の資料ダウンロードリンクを参照してください。

# Source URL: https://www.sevensix.co.jp/products/%e3%83%90%e3%83%b3%e3%83%89%e3%83%91%e3%82%b9%e3%83%95%e3%82%a3%e3%83%ab%e3%82%bf-%e6%b3%a2%e9%95%b7-1064-1565nm-optizone/