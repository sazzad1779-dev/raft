# 製品概要
製品名: SuerK FIANIUM OCT  
モデル: SuperK FIANIUM OCT  
モデル番号: FIR-9 OCT, FIU-6 OCT  
カテゴリ: 光ファイバーレーザーおよびその他の光源  
メーカー: NKT Photonics A/S  
ソースURL: [https://www.sevensix.co.jp/products/octsc_nktp/](https://www.sevensix.co.jp/products/octsc_nktp/)

## 製品概要
SuerK FIANIUM OCTは、OCT用にデザインされた広帯域・低雑音なSupercontinuumレーザーです。このレーザーは、SuperK FIANIUMと同等の特性を持ちながら、OCTに必要な感度を達成するために雑音を低減しています。広帯域のスペクトロメータと組み合わせることで、Ti:SapphireレーザーベースのOCTと同等の断層像を得ることができます。また、オールファイバベースの光源であるため、ローコストで小型、可搬性があり堅牢なOCTシステムを構築できます。

## 特長
- 低ノイズ
- 平均光出力: 600 – 900 mW @ 350 – 850 nm
- M2 < 1.1
- 堅牢でメンテナンスフリー
- >10,000時間の長寿命

## 仕様詳細
SuperK FIANIUM OCTには、スペクトル形状が異なるFIU-6 OCTとFIR-9 OCTの2種類があります。中心波長840 nmのOCTを構築する場合はFIR-9 OCTを選択し、短波長の可視光が必要な場合はFIU-6 OCTが最適です。

### 光学仕様
| 仕様項目 | FIU-6 OCT | FIR-9 OCT |
| --- | --- | --- |
| カットイン波長 (>0.1 mW/nm) | < 425 nm | < 640 nm |
| 全出力パワー | < 6.5 W | < 6.5 W |
| 可視光パワー (350-850 nm) | 600 mW | 900 mW |
| スペクトルパワー密度 | 0.5 mW/nm @ 450 nm<br>0.9 mW/nm @ 532 nm<br>1.2 mW/nm @ 650 nm<br>2.0 mW/nm @ 780 nm<br>1.6 mW/nm @ 800 nm | NA<br>NA<br>0.6 mW/nm @ 650 nm<br>3.2 mW/nm @ 780 nm<br>3.5 mW/nm @ 800 nm |
| 繰返し周波数 | 312 ± 3 MHz | 312 ± 3 MHz |
| 出力安定性 | < ± 0.5 % | < ± 0.5 % |
| 偏光 | ランダム偏光 | ランダム偏光 |
| ビーム品質 | 回折限界 | 回折限界 |
| 出力端 | コリメータ | コリメータ |
| ビーム径 (コリメータビーム) | 1 mm @ 530 nm<br>2 mm @ 1100 nm<br>3 mm @ 2000 nm | 1 mm @ 530 nm<br>2 mm @ 1100 nm<br>3 mm @ 2000 nm |

### 機械 / 電気 / 環境仕様
| 仕様項目 | 値 |
| --- | --- |
| 冷却方法 | 空冷 |
| 稼働電圧 | 100-240 VAC, 50-60 Hz |
| 消費電力 | < 100 W |
| コンピュータインターフェース | USB |
| ドアインターロックコネクタ | 2-pin LEMO |
| 外部busコネクタ | 16-pin D-sub |
| ファイバ長 | 1.5m |
| 寸法（WxHxL） | 440 x 251 x 400 mm |
| 重量 | 18 kg |
| 使用温度 | 18 ~ 30 °C |
| 保管温度 | -10 ~ 55 °C |

SuperK FIANIUM OCTは、最も低雑音なSupercontinuumレーザーであり、OCTの光源として使用することで、深さ方向分解能が1 – 2 μmの高分解能でありながら、高コントラストで低雑音なOCTイメージを取得できます。SuerK FIANIUM OCTは、Wasatch Photonics社のOCT用広帯域分光器Cobraシリーズなどと一緒に使用できます。

## 用途
- 光コヒーレンストモグラフィ
- 白色干渉系
- マルチモダリティOCT用途

## 参考文献：SupercontinuumレーザーのOCT応用
以下はSupercontinuumレーザーのOCT用途に関する研究論文です。
- Minshan Jiang, Tan Liu, Xiaojing Liu, and Shuliang Jiao, “Simultaneous optical coherence tomography and lipofuscin autofluorescence imaging of the retina with a single broadband light source at 480nm,” Biomed. Opt. Express **5**, 4242-4248 (2014)
- Ji Yi, Siyu Chen, Vadim Backman, and Hao F. Zhang, “In vivo functional microangiography by visible-light optical coherence tomography,” Biomed. Opt. Express **5**, 3603-3612 (2014)
- Yi, Ji et al. “Spatially Resolved Optical and Ultrastructural Properties of Colorectal and Pancreatic Field Carcinogenesis Observed by Inverse Spectroscopic Optical Coherence Tomography,” _Journal of Biomedical Optics_ 19.3 (2014)
- Francesco LaRocca, Derek Nankivil, Sina Farsiu, and Joseph A. Izatt, “True color scanning laser ophthalmoscopy and optical coherence tomography handheld probe,” Biomed. Opt. Express **5**, 3204-3216 (2014)
- Visible light optical coherence tomography measures retinal oxygen metabolic response to systemic oxygenation (2015)

## 資料ダウンロード
- [データシート：SuperK FIANIUM OCT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-FIANIUM-OCT-Datasheet.pdf#view=Fit)