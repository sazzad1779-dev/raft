# マルチモードレーザーダイオード

**カテゴリ:** 半導体レーザーダイオード（LD）  
**中カテゴリ:** ファブリペローレーザー  
**メーカー:** Toptica Eagleyard  
**モデル:** (型番なし)  
**波長:** 653～1064 nm  
**出力:** 1～90 W  

マルチモードレーザーダイオードは、空間的にも縦方向にもマルチモードで動作するレーザーダイオードです。波長は653～1,120nm、出力はcwモードで1～18W、パルスモードで最大100Wまで提供しています。ストライプ幅は60μmから400μmまであり、用途に応じてビーム構造と出力を最適化することが可能です。このレーザーは、宇宙や防衛用途のセンシング、材料加工、医療用途、LIDARまたは固体レーザー励起に使用されます。

## 特長
- 出力はCWモードで1~18W、パルスモードで最大90Wまで対応
- C-Mount / TO 9 / CDL パッケージ
- ストライプ幅は60μmから400μm

## 用途
- 宇宙衛星・防衛用途のセンシング
- 材料加工
- 医療用途
- LIDARや固体レーザーの励起

## 仕様詳細
以下の表は、マルチモードレーザーダイオードの主要な仕様を示しています。各製品の波長、出力パワー、モード、パッケージタイプが記載されています。

| 製品名 | 波長 (nm) | 出力パワー (W)　<br>\*推奨 | モード | パッケージ |
| --- | --- | --- | --- | --- |
| [EYP-BAL-0653-01000-1510-CMT02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 653 ± 5 | 1.2 | CW | C-Mount 2mm package |
| [EYP-BAL-0670-00001-1510-SOT23-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 670 ± 10 | 1.8 | パルス | 9mm TO-can |
| [EYP-BAL-0670-00004-1510-SOT23-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 670 ± 20 | 4 | パルス | 9mm TO-can |
| [EYP-BAL-0670-00010-1510-SOT23-0016](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 670 ± 20 | 10 | パルス | 9mm TO-can |
| [EYP-BAL-0760-00008-2020-SOT23-0016](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 760 ± 5 | 8 | パルス | 9mm TO-can |
| [EYP-BAL-0808-00005-2013-SOT12-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 808 ± 5 | 6 | パルス | 9mm TO-can |
| [EYP-BAL-0808-07000-4020-CDL02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 808 ± 15 | 7 | CW | integrated FAC/SAC |
| [EYP-BAL-0808-08000-4020-CMT04-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 808 ± 15 | 8 | CW | C-Mount 4mm package |
| [EYP-BAL-0808-00020-4020-FLW01-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 808 ± 15 | 20 | パルス | flatpack with window |
| [EYP-BAL-0808-00025-2013-SOT23-0016](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 808 ± 15 | 20 | パルス | 9mm TO-can |
| [EYP-BAL-0905-00010-1040-TOE02-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 850 (Min)<br>905 (Typ)<br>920 (Max) | 10 | パルス | TO-with thread |
| [EYP-BAL-0905-00050-1040-TOE22-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 850 (Min)<br>905 (Typ)<br>920 (Max) | 56 | パルス | TO-with thread |
| [EYP-BAL-0905-00090-1040-TOE22-0010](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 850 (Min)<br>905 (Typ)<br>920 (Max) | 90 | パルス | TO-with thread |
| [EYP-BAL-0980-08000-4020-CMT04-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 980 ± 15 | 8 | CW | C-Mount 4mm package |
| [EYP-BAL-0980-15000-4020-CDL02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 980 ± 15 | 14 | CW | integrated FAC/SAC |
| [EYP-BAL-0980-18000-4020-CDL02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 980 ± 15 | 18 | CW | integrated FAC/SAC |
| [EYP-BAL-1064-08000-4020-CMT04-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 1064 ± 15 | 8 | CW | C-Mount 4mm package |
| [EYP-BAL-1064-10000-4020-CDL02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 1064 ± 15 | 10 | CW | integrated FAC/SAC |
| [EYP-BAL-1064-16000-4020-CDL02-0000](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/) | 1064 ± 15 | 16 | CW | integrated FAC/SAC |

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/mmld653nm_eagleyard/)から。