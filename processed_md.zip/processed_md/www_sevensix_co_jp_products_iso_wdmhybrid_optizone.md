# アイソレータ / フィルタ WDMハイブリッド

**カテゴリ:** 光増幅器/光変調器/PD/光フィルタ他  
**中カテゴリ:** 光フィルタ  
**小カテゴリ:** 光ハイブリッド  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 1530 ~ 1580nm / 1530 ~ 1565nm / 1950 ~ 2050nm  

Optizone Technology Limitedのアイソレータ/フィルタWDMハイブリッドは、中国の深センに拠点を置き、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間20,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9,000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失

## 用途
- ファイバレーザ
- ファイバセンサ
- 光増幅器

## 仕様詳細
以下の表は、アイソレータ/フィルタWDMハイブリッドの主要な仕様を示しています。

| 項目           | 内容                                      |
|----------------|-------------------------------------------|
| 波長           | 1530-1580nm、1530-1565nm、1950-2050nm    |
| ステージ       | シングル、デュアル                        |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜   | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長     | 標準1m、その他も対応可                   |

### パッケージ
- 標準タイプ
- 小型タイプ

## 資料ダウンロード
- [データシート：1530-1580nm Isolator/Filter Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-06-001E-IWDM-5531nm-5548nm-new.pdf#view=Fit)
- [データシート：1950~2050nm Isolator/Filter Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-010E-IWDM-2057.pdf#view=Fit)
- [データシート：1530~1565nm High Power Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-062C-HPIWDM-5598-F-D-1-01-NNN-BBB-1-01-01.pdf#view=Fit)
- [データシート：1950~2050nm High Power Isolator/Filter Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-058D-HPIWDM-2057-1.pdf#view=Fit)
- [データシート：1530~1565nm Mini Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/f8555bc138514c234c83fbee130dd707-1.pdf#view=Fit)
- [データシート：1530-1580nm Tap/Isolator/Filter Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-06-004D-TIWDM-980nm-1480nm-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[Source URL](https://www.sevensix.co.jp/products/iso_wdmhybrid_optizone/)