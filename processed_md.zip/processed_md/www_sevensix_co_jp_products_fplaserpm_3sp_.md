# 製品概要
- **カテゴリ**: 半導体レーザーダイオード（LD）
- **中カテゴリ**: シードLD
- **メーカー**: 3SP Technologies
- **品名**: シード用ファブリペローレーザー (CW / Pulse) PMファイバ
- **モデル**: (型番なし)
- **波長**: 1050 ~ 1070nm
- **出力**: 400 ~ 500W

[製品URL](https://www.sevensix.co.jp/products/fplaserpm_3sp/)

## 特長
- 14ピンバタフライ型モジュール
- ピグテールファイバ – PMF
- TEC、NTCサーミスタ、モニタリングPDを内蔵
- Telcordia GR-468-CORE準拠
- MTTF > 100,000h

## 用途
- ラマン分光の励起光源
- パルス、CWのファイバレーザの種光源用

## 仕様詳細
### 電気光学特性
- Tsubmount = 25 °C
- Tcase = -5 °C to 75 °C
- VBFM= -5 V
- 背面反射で規定: -50 dB max

## 資料ダウンロード
- [データシート：シード用ファブリペローレーザー (CW / Pulse) PMファイバ](https://www.sevensix.co.jp/wp-content/uploads/3SP-1064CHP%E2%91%A0.pdf#view=Fit)