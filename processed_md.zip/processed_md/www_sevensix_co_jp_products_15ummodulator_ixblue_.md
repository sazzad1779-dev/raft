# 1.5 um帯 10GHz/20GHz/30GHz 強度変調器

**カテゴリ:** 光変調器  
**小カテゴリ:** 強度変調器  
**メーカー:** iXBlue SAS  
**波長:** 1530 ~ 1625 nm  
**帯域幅:** 最大 40 GHz  

MX-LNシリーズはニオブ酸リチウム（LiNbO3）を用いた強度変調器で、10 Gb/sから44 Gb/sの光伝送に最適です。このマッハツェンダー変調器は、Xカット設計により、幅広い動作条件での安定性と、ゼロチャープ性能を実現しています。NRZ、RZ、DPSK、Duo Binaryの各変調方式に対応しています。

## 特長
- 高い帯域幅
- Xカットによる高い安定性
- 低い駆動電圧
- 低挿入損失

### オプション
- 2000 nm、1300 nm、1060 nm、850 nm
- 高消光比バージョン

## 用途
- 汎用強度変調
- 試験・計測
- デジタル通信

## 資料ダウンロード
- [データシート：1.5 um帯 10GHz/20GHz/40GHz 強度変調器](https://www.sevensix.co.jp/wp-content/uploads/1.5-um%E5%B8%AF-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8-MX-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

# Source URL: https://www.sevensix.co.jp/products/15ummodulator_ixblue/