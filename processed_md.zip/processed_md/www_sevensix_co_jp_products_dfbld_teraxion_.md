# 超狭線幅DFBレーザーモジュール

**メーカー**: TeraXion  
**カテゴリ**: 半導体レーザーダイオード（LD）  
**中カテゴリ**: DFBレーザー  
**モデル**: (型番なし)  
**Source URL**: [https://www.sevensix.co.jp/products/dfbld_teraxion/](https://www.sevensix.co.jp/products/dfbld_teraxion/)

## 製品概要
超狭線幅DFBレーザーモジュールは、線幅80Hzと超低ノイズで高出力(> 60 mW)を実現した小型・低消費電力なDFBレーザーです。低RIN・高周波数時間安定性を持ち、DFBベースでフォトニック・リファレンス内蔵のループ制御によるノイズキャンセル機構を採用しています。

## 特長
- DFBベースでフォトニック・リファレンス内蔵のループ制御によるノイズキャンセル機構
- 超狭線幅: typ 80 Hz (max 200 Hz) @1 MHz
- 高出力: > 60 mW
- 対応波長: 1545/1550/1560 nm
- 極めて低いRIN (Relative Intensity Noise): < -155 dBc/Hz
- 振動に対する高い安定性
- 小型軽量、電源/制御用USBインターフェースボードサポート(オプション)

## 用途
- 光ファイバセンシング、DAS
- 量子鍵配送(QKD)、量子コンピューティング
- LiDAR

## 仕様詳細
### デフォルト / オプション概要
- 小型軽量 (クレジットカードサイズ)
- 電源/制御用USBインターフェースボード対応 (オプション)

## 資料ダウンロード
- [データシート：DFBレーザーモジュール（LXM-U1550.12-040-M1-I1-N0）](https://www.sevensix.co.jp/wp-content/uploads/TeraXion-SPECS-OPP2022518-11.0-LXM-U1550_12-040-M1-I1-N00.pdf#view=Fit)
- [データシート：DFBレーザーモジュール（LXM-U1550.12-060-M1-I1-N0）](https://www.sevensix.co.jp/wp-content/uploads/TeraXion-SPECS-OPP2022518-12.0-LXM-U1550_12-060-M1-I1-N00.pdf#view=Fit)