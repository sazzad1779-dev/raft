# ポンプシグナルコンバイナ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** 光コンバイナ/スプリッタ  
**小カテゴリ:** ポンプコンバイナ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 790 ~ 2000nm  
**ポンプ数:** (2+1)X1、(6+1)X1  

Optizone Technology Limitedのポンプシグナルコンバイナは、中国の深センに拠点を置き、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- **ポンプ波長範囲:** 700～1000nm
- **信号波長範囲:** 900～2000nm

## 用途
- ファイバーレーザ
- 光ファイバアンプ
- その他光学部品

## 仕様詳細
以下の表は、ポンプシグナルコンバイナの主要な仕様を示しています。

| 項目                     | 詳細内容                                   |
|------------------------|----------------------------------------|
| **ポンプ伝播方向**       | 前方、後方、その他も対応可                     |
| **ポンプ波長**           | 793nm、915nm、976nm、その他も対応可            |
| **信号波長**             | 1030nm、1550nm、1064nm、2000nm、その他も対応可 |
| **ポンプファイバタイプ** | MM-S105/125-22A、MM-S105/125-15A、<br>MM-S135/155-22FA、MM-S200/220-22A、その他も対応可 |
| **信号ファイバタイプ**   | CORNING HI1060、NUFERN FUD-3583(10/125DC)、<br>LMA-GDF-30/250-M、その他も対応可 |
| **出力ファイバタイプ**   | NUFERN FUD-3394(6/125 DC)、NUFERN FUD-3583(10/125DC)、<br>LMA-GDF-20/400-M、その他も対応可 |
| **ファイバ長**           | 1m、1.5m、2m、その他も対応可                  |
| **パッケージ**           | 70X12X8、100X15X10、その他も対応可            |

＊ハイパワー対応の製品も取り扱いがあります。

## 資料ダウンロード
- [データシート： (6+1)×1 MultiMode Pump Signal Combiner](https://www.sevensix.co.jp/wp-content/uploads/61X1-MultiMode-Pump-Signal-Combiner.pdf#view=Fit)
- [データシート： (2+1)×1 MultiMode Pump Signal Combiner](https://www.sevensix.co.jp/wp-content/uploads/21X1-MultiMode-Pump-Signal-Combiner.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/pompcombiner_optizone/)から。