# 製品概要

- **製品名**: Femtosecond ultrashort pulse laser
- **モデル**: ORIGAMI 03XP-S, ORIGAMI 05XP, ORIGAMI 05XP-S
- **カテゴリ**: ファイバーレーザーおよびその他の光源
- **中カテゴリ**: 超短パルスレーザー（ナノ秒/ピコ秒/フェムト秒）光源
- **メーカー**: NKT Photonics A/S

# モデル一覧

以下は、Femtosecond ultrashort pulse laserの各モデルの概要です。

| モデル名         | 特徴                       |
|------------------|----------------------------|
| ORIGAMI 03XP-S   | 高出力、コンパクト設計     |
| ORIGAMI 05XP     | 幅広い波長範囲、優れた安定性 |
| ORIGAMI 05XP-S   | 高精度、低ノイズ           |

# ソースURL
[製品ページ](https://www.sevensix.co.jp/products/origamixp_nktp/)