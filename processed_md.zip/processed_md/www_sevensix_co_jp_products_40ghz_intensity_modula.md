# 薄膜LN 40GHz Ultra-low Vπ光強度変調器

**カテゴリ:** 光変調器  
**メーカー:** HyperLight  
**モデル:** 型番なし  
**波長帯:** C / L-band  

HyperLight社の薄膜LN 40GHz Ultra-low Vπ光強度変調器は、従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現しています。

## 特長
- 40 GHzの広帯域
- 低Vπ: 0.7V
- 高い消光比
- C/L-band対応
- コンパクトなフットプリント、安定したDCバイアス
- バランス検出用のデュアル出力

## 用途
- Radio-over-fiberおよび衛星リンク
- ワイヤレス、5G/6G

## 資料ダウンロード
- [カタログ：薄膜LN 40GHz Ultra-low Vπ光強度変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-40GHz-Ultra-low-Vpai-Intensity-Modulator.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/40ghz_intensity_modulator_hyperlight/