大カテゴリ: 光増幅器/ 光変調器/ PD/ 光フィルタ他  
中カテゴリ: 光増幅器  
小カテゴリ: SOA  
メーカ: Innolume GmbH  
品名: 半導体光アンプ  

モデル:  
- モデル: (型番なし)  

# Source URL: https://www.sevensix.co.jp/products/soa_innolume/

## 半導体光アンプ
- 波長: SOA 780~1290nm　BOA 1060~1310nm
- メーカ： Innolume GmbH
- 特徴:
  - 27dB の高ゲイン
  - 970-1080nm 増幅幅
  - 直線偏波
  - RoHS対応

## 特長
半導体光増幅器 (SOA：Semiconductor optical amplifiers) は、増幅媒体として半導体を用いた光増幅器です。SOAはファブリ・ペロー半導体レーザと似通った構造をしていますが、半導体チップの片面にARコーティング (Anti-Reflection coating) が施されています。最近のSOAの設計ではARコーティングに加えて導波路が斜めになっているため、射出側における端面反射が0.001%以下に抑えられています。これにより、共振器内での光損失が増幅率よりも大きくなり、この半導体がレーザとして動作するのを妨げます。

## 用途
- ファイバレーザのプリアンプ
- SS-OCT用 波長掃引光源

SOAは出力と帯域の間に大きな依存関係があります。利得バンド幅が広くなるほど、利得は小さくなります。用途に合った最適な製品をお選びください。

## 仕様詳細

### SOA
以下の表は、異なるSOAモデルの仕様を示しています。各モデルは、用途、ゲイン波長、ゲイン幅、スモール信号利得、飽和出力、雑音指数、順電動、順電圧、偏光消光比などの重要なパラメータを比較しています。

| 製品型番 | 用途 | 製品概要 | ゲイン波長(nm) | ゲイン幅 (3dB)nm | スモール信号利得(dB) | 飽和出力(dBm) | 雑音指数(dB) | 順電動(mA) | 順電圧(V) | 偏光消光比(dB) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SOA0780016YY30DBXXXX | spectroscopy, tunable laser source | Semiconductor optical amplifier at 780nm in BTF package | 780 | 16 | 31 | 12 | 6.5 | 300 | 1.9 | 15 |
| SOA1000100YY30DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1000nm in BTF package | 1000 | 100 | 32 | 17 | 6.5 | 600 | 1.7 | 18 |
| SOA1020110YY30DBXXXX | OCT, tunable laser source | Semiconductor optical amplifier at 1020nm in BTF package | 1020 | 110 | 30 | 15 | 8 | 550 | 1.6 | 18 |
| SOA1035020YY40DBXXXX | spectroscopy, gas sensing, tunable laser source | Semiconductor optical amplifier at 1035nm in BTF package | 1035 | 20 | 37 | 16 | 8 | 450 | 1.6 | 18 |
| SOA1060022YY40DBXXXX | OCT, spectroscopy, tunable laser source | Semiconductor optical amplifier at 1060nm in BTF package | 1060 | 22 | 39 | 18 | 8 | 450 | 1.6 | 18 |
| SOA1060090YY30DBXXXX | OCT, spectroscopy, LIDAR, tunable laser source, sensing, research | Semiconductor optical amplifier at 1060nm in BTF package | 1060 | 90 | 32 | 18 | 6 | 450 | 1.7 | 17 |
| SOA1080025YY35DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1080nm in BTF package | 1080 | 25 | 35 | 15 | 7 | 400 | 1.5 | 18 |
| SOA1090025YY40DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1090nm in BTF package | 1090 | 25 | 39 | 16 | 7 | 400 | 1.5 | 16 |
| SOA1125025YY35DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1125nm in BTF package | 1125 | 25 | 35 | 16 | 10 | 600 | 1.6 | 18 |
| SOA1140090YY22DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1140nm in BTF package | 1140 | 90 | 22 | 15 | 5 | 400 | 1.4 | 18 |
| SOA1190090YY20DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1190nm in BTF package | 1190 | 90 | 20 | 12 | 7 | 300 | 1.4 | 18 |
| SOA1250110YY27DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1250nm in BTF package | 1250 | 110 | 27 | 15 | 8 | 900 | 1.6 | 18 |
| SOA1290045YY25DBXXXX | tunable laser source, research | Semiconductor optical amplifier at 1290nm in BTF package | 1290 | 45 | 25 | 12 | 7.5 | 400 | 1.4 | 18 |

### BOA (CHIP-ON-CARRIER)
以下の表は、BOAモデルの仕様を示しています。各モデルは、用途、ゲイン波長、ゲイン幅、出力、飽和利得、スモール信号利得、飽和出力、雑音指数、順電流、ビーム発散角、偏光消光比などの重要なパラメータを比較しています。

| 製品型番 | 用途 | 製品概要 | ゲイン波長(nm) | ゲイン幅 (3dB)nm | 出力(mW) | 飽和利得(dB) | スモール信号利得(dB) | 飽和出力(dBm) | 雑音指数(dB) | 順電流(mA) | Slow軸ビーム発散角(deg) | Fast軸ビーム発散角(deg) | 偏光消光比(dB) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BOA1290065CC550MXXXX | LIDAR, Datacom | Booster optical amplifier at 1290nm on submount | 1290 | 65 | 550 | 18 | 43 | 22 | 5 | 2000 | 8 | 28 | 18 |
| BOA1300060CC450MXXXX | LIDAR, Datacom | Booster optical amplifier at 1300nm on submount | 1300 | 60 | 450 | 17 | 31 | 22 | 5 | 2000 | 6 | 27 | 18 |

### BOA (FIBER-COUPLED)
以下の表は、ファイバー結合型BOAモデルの仕様を示しています。各モデルは、用途、ゲイン波長、ゲイン幅、出力、飽和利得、スモール信号利得、飽和出力、雑音指数、順電流、偏光消光比などの重要なパラメータを比較しています。

| 製品型番 | 用途 | 製品概要 | ゲイン波長(nm) | ゲイン幅 (3dB)nm | 出力(mW) | 飽和利得(dB) | スモール信号利得(dB) | 飽和出力(dBm) | 雑音指数(dB) | 順電流(mA) | 偏光消光比(dB) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BOA1060080YY120MXXXX | OCT | Booster optical amplifier at 1060nm in BTF package | 1060 | 80 | 120 | 10 | 15 | 19 | 6.5 | 400 | 18 |
| BOA1290065YY400MXXXX | LIDAR, Datacom | Booster optical amplifier at 1290nm in BTF package | 1290 | 65 | 400 | 16 | 41 | 21 | 6 | 2000 | 16 |
| BOA1300060YY350MXXXX | LIDAR, Datacom | Booster optical amplifier at 1300nm in BTF package | 1300 | 60 | 350 | 16 | 28 | 22 | 6.5 | 2000 | 16 |
| BOA1310070YY300MXXXX | LIDAR, Datacom | Booster optical amplifier at 1310nm in BTF package | 1310 | 70 | 300 | 16 | 38 | 20 | 6 | 2000 | 18 |

各SOAの入出力ファイバ:
- 780-HP
- HI1060
- SMF-28
- PM780
- PM980
- PM1300

## 製品に関するお問い合わせ
この製品のお問い合わせ