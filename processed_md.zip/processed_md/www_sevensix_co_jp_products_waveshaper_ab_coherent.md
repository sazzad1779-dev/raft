# 通信帯域 スペクトル・分散制御プロセッサ WaveShaper A/Bシリーズ

**カテゴリ:** 光増幅器/光変調器/PD/光フィルタ他  
**中カテゴリ:** 光フィルタ  
**小カテゴリ:** 光任意波形成形器(Wave Shaper)  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  
**Source URL:** [WaveShaper A/Bシリーズ](https://www.sevensix.co.jp/products/waveshaper_ab_coherent/)

WaveShaper A/Bシリーズは、O/S/C/L/U-bandに対応した光フィルタで、光スペクトルの強度と位相、群遅延を独立に高い自由度で制御できます。LCoS（Liquid Crystal on Silicon）技術を基にしており、可動部がなく安定で堅牢です。多様なポート構成（1 x 31, 4 x 28, 8 x 24, 12 x 20, 16 x 16）にも対応しています。

## 特長
- 業界唯一の任意波形整形機能（フィルタ帯域幅10GHzから複数の任意形状フィルタ設定可能）
- アッテネーション（レンジ 0~40 dB）と位相を独立に制御可能
- 幅広い動作周波数帯域（O-band, S-band, C-band, L-band, C+L-band, 拡張L-band, U-band, 1μm）
- 高解像度LCoS技術で構成され、安定性と堅牢性を確保
- Ethernet接続による遠隔制御に対応

### Bシリーズの機能追加について
- **高速フィルタ更新レート:** 最大10Hzのフィルタ更新レートを実現（フィルタ設定による）
- **高分解能モード:** Double pass configurationによる高分解能モード（フィルタ帯域幅：8GHz＠Super C-band）

## 動作原理
WaveShaperの任意波形整形機能は、回折格子とLCoSによって実現されます。入力光源は回折格子で波長分解され、各波長がLCoSのピクセルに照射されます。LCoSで制御された光は出力ファイバに結合され、光強度と位相（群遅延）を制御します。

## 用途
- 波長多重通信光のレベル等価制御、位相・分散制御、光スペクトル制御、光源生成
- 量子通信における単一光子信号周波数変換時の励起光パルス整形
- 短パルスレーザーの波長分散制御によるパルス圧縮
- 波長合分波（MUX/DEMUX）、De-/Interleaving

## アプリケーション事例
WaveShaperは、モードロックレーザーや光ファイバ増幅器と組み合わせることで性能を最大限に発揮します。推奨される光源には、光周波数コム光源『Frush』と超短パルスファイバレーザー『iQoM』があります。

### アプリケーション事例①：波長広帯域化とフェムト秒パルスの生成
### アプリケーション事例②：超短パルス光の出力

## 仕様詳細
以下の表は、WaveShaperのモデルとその主要な仕様を示しています。

| シリーズ名 | モデル番号 | ポート | 動作波長範囲 | フィルタ波形 |
| --- | --- | --- | --- | --- |
| WaveShaper Short-Pulse Shaping | WS-01000A/SP | 1×1 | 1μ, C-band, C+L band | 減衰と位相が任意 |
| WaveShaper A-Series | WS-01000A/S, WS-04000A/S | 1×1, 1×4 | S-band | 減衰と位相が任意 |
|  | WS-01000A/U, WS-04000A/U | 1×1, 1×4 | U-band | 減衰と位相が任意 |
| WaveShaper B-Series | WS 500B-Series | 1×1 | Super C-band, Super L-band | 減衰が任意 |
|  | WS 1000B-Series | 1×1 | Super C-band, Super L-band, C+L-band, O-band | 減衰と位相が任意 |
|  | WS 4000B-Series | 1×4 | Super C-band, Super L-band, C+L-band, O-band | 減衰と位相が任意 |
|  | WS 3200xB-Series | 1×31, 4×28, 8×24, 12×20, 16×16 | Super C-band, Super C + Super L-band | 減衰と位相が任意 |

## セブンシックスの技術サポート
- 導入前・導入後の相談
- 製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyzeの修理対応

## 解説・関連動画
- Coherent社WaveShaperオリジナルソフト『SAF』解説
- WaveShaper/光任意波形整形器の紹介動画

## アプリケーション・ノート
- [Creating Simple Filter Shapes in Excel, Labview and Matlab](#)
- [Double Pulse Generation in pSec and fSec Lasers](#)
- [Group Delay Ripple Compensation](#)
- [Automated Gain Flattening in an Optical Amplifier](#)
- [Short Pulse Shaping](#)
- [Pulse Burst Generation](#)
- [Filter Bandwidth Definition](#)
- [Dispersion Trimming](#)

## 資料ダウンロード
- [カタログ：WaveShaper Aシリーズ](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-a-series-family-br.pdf#view=Fit)
- [カタログ：WaveShaper Bシリーズ](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-b-series-family-br.pdf#view=Fit)
- [ユーザマニュアル：WaveShaper](https://www.sevensix.co.jp/wp-content/uploads/WaveShaper-Help-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

## 関連製品
- 1 μｍ 超短パルスファイバレーザー用 時間・スペクトルプロセッサ WaveShaper『1000A/SP』 - 1 μｍ, C-Band, C+L-Band
- C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』 - 帯域幅：1527.8 ~ 1610.05nm
- ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』 - Super C-band帯 (1523.9 ~ 1572.7nm)対応
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバー