# Flexgrid 波長選択型 光スイッチ (WSS)

**カテゴリ:** 光スイッチ  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  
**周波数レンジ:** 4.8THz ~ 10THz (C+L band)  
**Source URL:** [Flexgrid WSS](https://www.sevensix.co.jp/products/flexgridwss_coherent/)

Flexgrid対応の波長選択型光スイッチ（WSS）は、LCoS（Liquid Crystal on Silicon）技術を利用しており、周波数レンジは4.8THzから10THz（C+L band）をサポートします。ポート構成は1×N、2x1xN、4x1xNに対応しています。

## 特長
- **多様なポート構成:** 2x1xN, 4x1xN, Colorless/Directionless 2xNxM, 1xN (N≦20)
- **周波数レンジ:** 4.8～10 THz (C+L band)
- **安定性:** LCoS技術により可動部がなく、堅牢で安定
- **オルタネートコモンポート**
- **Flexgrid対応:** 
  - チャンネル幅の動的制御（ITUフレキシブルグリッドG.694.1準拠）
  - 6.25GHz 幅分解能（デフォルト）、3.125GHz（オプション）
  - スーパーチャンネルに割り当てる周波数に制約なし
  - ヒットレスなチャンネルのワイド化、ナロー化、マイグレーションが可能
- **チャンネル等価制御:** 
  - 66.25 GHz 分解能
  - 0 – 20dB レンジ
  - ヒットレス・チャネルおよびチャネル内パワーイコライゼーション

2021年のLightwave Innovation Reviewsを受賞しました。

## 用途
- データセンター
- 基幹系インフラ
- 通信

## 仕様詳細
近年、DWDM光ネットワークにおいて光パスの柔軟性が求められ、ROADM（Reconfigurable Optical Add/Drop Multiplexers）システムの重要性が増しています。Flexgrid技術は、400Gb/sや1Tb/s信号などの高データレートや変調方式において、光の帯域利用効率を最大化するために不可欠です。新しい伝送方式をネットワークに適用するために、チャネル間隔の柔軟な変更やリアルタイムでのチャネル数の増加が求められます。

Colorless directionless (CD) ROADMsやcolorless, directionless, contentionless (CDC)は、route & select (R&S) ROADMアーキテクチャにより実現可能です。これは、1方向に2つのWSSを必要とするbroadcast & select (B&S) ROADMとは異なり、1方向に1つのWSSのみで構成できます。Dual WSSは、R&S ROADMシステムに最適で、CD 2xNxM Add/Dropモジュールとしても使用可能です。また、Quad WSSにも対応しています。

## 資料ダウンロード
- [カタログ：Flexgrid 波長選択型 光スイッチ (WSS) Dual WSS](https://www.sevensix.co.jp/wp-content/uploads/Finisar-WSS-Dual-Wavelength-Selective-Switch-WSS.pdf#view=Fit)
- [カタログ：Flexgrid 波長選択型 光スイッチ (WSS) Single WSS](https://www.sevensix.co.jp/wp-content/uploads/Finisar-WSS-Single-Wavelength-Selective-Switch-WSS.pdf#view=Fit)