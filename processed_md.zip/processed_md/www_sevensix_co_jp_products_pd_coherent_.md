# 超広帯域フォトディテクタ

**カテゴリ:** 光増幅器/光変調器/PD/光フィルタ他  
**中カテゴリ:** フォトダイオード(PD)  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  
**Source URL:** [https://www.sevensix.co.jp/products/pd_coherent/](https://www.sevensix.co.jp/products/pd_coherent/)

## 概要
Coherentの超広帯域フォトディテクタは、DCから100GHzの広帯域（cut-off周波数3dB）でリニアな周波数応答特性と高い同窓信号除去比（common mode rejection ratio）を提供します。この製品は、コヒーレント通信、光ファイバ無線（RF over Fiber）、レーダ、測定器、マイクロウェイブ・フォトニクスなど、さまざまな分野で利用されています。

## 特長
- DC～100GHzの広い帯域（cut-off周波数3dB）
- リニアな周波数応答特性
- 高い同窓信号除去比（common mode rejection ratio）

## 用途
- 光アクセス
- 光ファイバセンシング
- 基幹系インフラ
- 通信

## プロダクト・ポートフォリオ

### Single Photo Detectorシリーズ
このシリーズは、異なる帯域幅とオプションを持つフォトディテクタのモデルを提供します。

| 帯域(typ) | 1310nmオプション | 型番 | 備考 |
| --- | --- | --- | --- |
| 50 GHz |  | XPDV2120R |  |
| 35 GHz |  | XPDV2120RA | ・ACカップル |
| 50 GHz |  | XPDV2150R | ・Low PDLモデル |
| 50 GHz | 〇 | XPDV2320R |  |
| 70 GHz |  | XPDV3120R |  |
| 70 GHz | 〇 | XPDV3320R |  |
| 90 GHz |  | XPDV4120R |  |
| 100 GHz |  | XPDV4121R |  |

### Balanced Photo Detectorシリーズ
このシリーズは、シングル、デュアル、クアッドのオプションを持つバランス型フォトディテクタを提供します。

| 帯域(typ) | 1310nmオプション | 型番 | 備考 |
| --- | --- | --- | --- |
| 43 GHz |  | BPDV2120R | ・Singleのみ |
| 43 GHz |  | BPDV2150R(M/Q) | ・Single/Dual/Quad<br>・Low PDLモデル |
| 70 GHz |  | BPDV3120R(M/Q) | ・Single/Dual/Quad |
| 70 GHz | 〇 | BPDV3320R | ・Singleのみ |
| 100 GHz |  | BPDV4121R(Q) | ・Single/Dual/Quad |

### High-Power Photo Detectorシリーズ
高RF出力で光ファイバ無線（RF over Fiber）やマイクロウェイブ・フォトニクスに最適な製品です。

| 帯域(typ) | 1310nmオプション | 型番 | 備考 |
| --- | --- | --- | --- |
| 50 GHz |  | HPDV2120R |  |
| 20 GHz |  | VPDV2120 |  |
| 18 GHz | 〇 | XPRV2324A | limitingアンプ内蔵 |
| 30 GHz | 〇 | XPRV2325A | Linearアンプ内蔵、I2C I/F内蔵 |

## 資料ダウンロード
- [カタログ：超広帯域フォトディテクタ](https://www.sevensix.co.jp/wp-content/uploads/II-VI-Coherent-and-Advanced-Photodetectors-and-Receivers.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ