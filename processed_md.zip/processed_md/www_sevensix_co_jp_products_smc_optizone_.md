# シングルモードサーキュレータ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** 光サーキュレータ  
**小カテゴリ:** SMサーキュレータ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 850 ~ 1610nm  
**ポート数:** 1×2 / 2×2  

Optizone Technology Limitedのシングルモードサーキュレータは、中国の深センに拠点を置き、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高アイソレーション

## 用途
- 光増幅器
- FBGアプリケーション
- ファイバーセンサ

## 仕様詳細
この仕様表は、シングルモードサーキュレータの主要な性能パラメータを示しています。波長は850nm、1064nm、1310nm、1550nm、1610nmに対応し、ポート数は1×2または2×2から選択可能です。入力パワーは300mWまたは500mWで、コネクタタイプはFC/UPC、FC/APC、SC/UPC、SC/APC、Noneなどが選べます。ファイバ被膜は250umベアファイバ、250umパンダファイバ、400umベアファイバ、900umルーズチューブなどに対応し、ファイバ長は標準で0.8mまたは1mから選択可能です。

|     |     |
| --- | --- |
| **波長** | 850nm、1064nm、1310nm、1550nm、1610nm、その他も対応可 |
| **ポート数** | 1×2、2×2 |
| **入力パワー** | 300mW、500mW、その他も対応可 |
| **コネクタタイプ** | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| **ファイバ被膜** | 250umベアファイバ、250umパンダファイバ、400umベアファイバ、900umルーズチューブ、その他も対応可 |
| **ファイバ長** | 標準0.8m、1m、その他も対応可 |

## パッケージタイプ
- 標準タイプ
- Type C139

## 資料ダウンロード
- [データシート：850nm Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-076B-FCIR-85-C139-1-NNN-BBB-1-112.pdf#view=Fit)
- [データシート：1064nm Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-003F-FCIR-1064nm.pdf#view=Fit)
- [データシート：1310nm、1550nm、1610nm 1x2 Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-002E-FCIR-1310nm1550nm.pdf#view=Fit)
- [データシート：1550nm 2x2 Polarization Insensitive Optical Circulator](https://www.sevensix.co.jp/wp-content/uploads/CAT-02-005A-2x2-FCIR-1550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

# Source URL: https://www.sevensix.co.jp/products/smc_optizone/