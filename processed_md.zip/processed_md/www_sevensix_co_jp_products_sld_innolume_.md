大カテゴリ: ファイバーレーザー・その他光源  
中カテゴリ: UV光源/ LED光源/ SLD光源  
メーカ: Innolume GmbH  
品名: SLD光源  

モデル:  
- モデル: (型番なし)  

# Source URL: https://www.sevensix.co.jp/products/sld_innolume/

## SLD光源
波長: 830 ~ 1250nm  
_メーカ：_ Innolume GmbH  

### 特長
SLD (Superluminescent Light emitting Diode) は半導体レーザーに似た半導体光源で、広帯域スペクトルを持ちます。ピーク波長と平均出力は半導体の活性層の組成と注入電流レベルに依存します。SLDは導波路に沿って自然放出光が大きく増幅されるように設計されており、シングルパスで動作します。半導体レーザーとは異なり、増幅された光は活性層に戻らず、ARコーティングが施された斜めの導波路によってレーザー発振しません。

SLDは広いスペクトルを持ち、時間コヒーレンスが低いですが、高い空間コヒーレンスを持つため、シングルモード光ファイバ (SMF) に効率よく結合できます。OCTなどの白色干渉を用いる用途では、低い時間コヒーレンスを持つ光源で高い空間分解能を実現できます。

InnolumeのSLD光源は通常、14ピンバタフライタイプのモジュールで出荷され、150 mWの高出力タイプや100 nmを超える広帯域幅タイプ、OCTなどの用途に適した低リップルモデル（典型値0.02 dB RMS）があります。また、量子ドット技術を用いた1100 ~ 1250 nmの波長帯のSLD光源もラインナップされています。

SLDのピグテールファイバは、波長と好みに応じて780-HP, HI1060, SMF-28, PM780, PM980, PM1300から選択可能で、PMFを選択した場合のPERは20 dBです。Innolumeは、SLD光源と一緒に使用できるコンパクト設計の温度コントローラ内蔵のドライバも提供しており、操作用のドライバソフトもインストール済みで、複数のピンアサインに対応しています。

### 用途
- ファイバセンサー、計測器、分光器
- スペクトラムドメインを用いた干渉測定

### 仕様詳細
以下の表は、SLD光源の主要な仕様を示しています。各モデルの平均波長、スペクトル幅、出力、スペクトルディップ、ASEリップル、順電流、順電圧、偏光消光比が記載されています。

| 製品型番                     | 用途                             | 製品概要                                   | 平均波長(nm) | スペクトル幅 (3dB)nm | 出力(mW) | スペクトルディップ(dB) | ASEリップル (RMS)dB | 順電流(A) | 順電圧(V) | 偏光消光比(dB) |
|-----------------------------|----------------------------------|-------------------------------------------|--------------|----------------------|----------|------------------------|---------------------|------------|------------|----------------|
| SLD0830010YY050MXXXX        | OCT, material processing, sensing, research | Superluminescent diode at 830nm in BTF package | 830          | 10                   | 50       | –                      | 0.05                | 350        | 1.8        | 17             |
| SLD1000100YY015MXXXX        | sensing, research                | Superluminescent diode at 1000nm in BTF package | 1000         | 100                  | 15       | 1                      | 0.02                | 400        | 1.6        | 20             |
| SLD1030110YY012MXXXX        | sensing, research                | Superluminescent diode at 1030nm in BTF package | 1030         | 110                  | 12       | 4                      | 0.03                | 400        | 1.7        | 19             |
| SLD1030025YY130MXXXX        | material processing, sensing, research | Superluminescent diode at 1030nm in BTF package | 1030         | 25                   | 130      | –                      | 0.06                | 800        | 1.8        | 21             |
| SLD1050120YY040MXXXX        | sensing, research                | Superluminescent diode at 1055nm in BTF package | 1055         | 120                  | 40       | 5                      | 0.04                | 700        | 1.7        | 20             |
| SLD1060020YY120MXXXX        | sensing, research                | Superluminescent diode at 1060nm in BTF package | 1060         | 20                   | 120      | –                      | 0.04                | 800        | 1.8        | 20             |
| SLD1060015YY250MXXXX        | medical devices, sensing, research | Superluminescent diode at 1060nm in BTF package | 1060         | 15                   | 250      | –                      | 0.1                 | 1500       | 1.9        | 21             |
| SLD1064020YY300MXXXX        | sensing, research                | Superluminescent diode at 1064nm in BTF package | 1064         | 20                   | 300      | –                      | 0.8                 | 800        | 1.9        | 18             |
| SLD1090030YY100MXXXX        | sensing, research                | Superluminescent diode at 1090nm in BTF package | 1090         | 30                   | 100      | –                      | 0.06                | 800        | 1.7        | 15             |
| SLD1120020YY030MXXXX        | OCT, sensing, research          | Superluminescent diode at 1120nm in BTF package | 1120         | 20                   | 30       | –                      | 0.03                | 300        | 1.5        | 20             |
| SLD1140080YY0D5MXXXX        | sensing, research                | Superluminescent diode at 1140nm in BTF package | 1140         | 80                   | 0.5      | 4                      | 0.02                | 250        | 1.3        | 19             |
| SLD1190090YY0D5MXXXX        | sensing, research                | Superluminescent diode at 1190nm in BTF package | 1190         | 90                   | 0.5      | 5                      | 0.01                | 315        | 1.4        | 19             |
| SLD1250110YY004MXXXX        | communication, sensing, research | Superluminescent diode at 1250nm in BTF package | 1250         | 110                  | 4        | 6                      | 0.01                | 800        | 1.5        | 19             |

## 製品に関するお問い合わせ
この製品のお問い合わせ