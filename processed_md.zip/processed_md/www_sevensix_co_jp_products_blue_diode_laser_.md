# 青色半導体レーザー / ブルーレーザー

**カテゴリ:** 半導体レーザーダイオード（LD）  
**中カテゴリ:** 青色レーザー  
**メーカー:** BWT Beijing LTD.  
**モデル:** (型番なし)  
**波長:** 405 ~ 445nm  
**出力:** 160mW ~ 200W  

この青色半導体レーザーは、組み込み用のモジュールタイプであり、ファイバとコネクタのカスタムが可能です。また、LDドライバについても相談が可能です。

## 特長
- 高輝度、高出力、小径コア
- 広範囲なパワーレンジ

## 用途
- 高反射材料加工（銅や金）
- レーザーマーキング、3Dプリント
- バイオ、医療

## 仕様詳細
以下の表は、異なるモデルの青色半導体レーザーの主要な仕様を比較しています。各モデルの波長、出力、コア径、開口数、用途が示されています。

| 製品名 | 型番 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| --- | --- | --- | --- | --- | --- | --- |
| 405nm 160mW Coaxial Packaged MM Diode Laser | [K405E03CN-0.160W]( | 405 | 0.16 | 40 | 0.22 | Plate Printing – CTP |
| 405nm 30W Fiber Coupled Diode Laser | [K405EMSCN-30.00WN1N-40022]( | 405 | 30 | 400 | 0.22 | バイオ、Laser Direct Writing、3Dプリント |
| 405nm 50W Fiber Coupled Diode Laser | [K405EMSCN-50.00WN1N-40022]( | 405 | 50 | 400 | 0.22 | バイオ、Laser Direct Writing、3Dプリント |
| 445nm 3.5W Fiber Coupled Diode Laser | [K445H03FN-3.500WN0N-10522]( | 445 | 3.5 | 105 | 0.22 | 照明、3Dプリント |
| 445nm 10W Fiber Coupled Diode Laser | [K445HMTFN-10.00WN1N]( | 445 | 10 | 105 | 0.22 | レーザー彫刻、材料加工、3Dプリント |
| 445nm Spatial Light Output Blue Laser | [K445HSEWN Series]( | 445 | 10<br>15<br>20 | ー | ー | レーザー彫刻、科学研究 |
| 445nm 50W Fiber Coupled Diode Laser | [K445HR7FN-50.00W]( | 445 | 50 | 113 | 0.15 | 材料加工、3Dプリント 、科学研究 |
| 445nm 50W Fiber Coupled Diode Laser | [K445FMKFN-50.00WN1N-20022R55ESM]( | 445 | 50 | 200 | 0.22 | 材料加工、3Dプリント、照明 |
| 445nm Fiber Coupled Blue Laser | [K445HR6FN Series V1.1]( | 445 | 100<br>150<br>200 | 105 | 0.22 | 材料加工、3Dプリント |

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[製品詳細はこちら](https://www.sevensix.co.jp/products/blue-diode-laser/)