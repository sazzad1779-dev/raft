大カテゴリ: 光増幅器/ 光変調器/ PD/ 光フィルタ他  
中カテゴリ: フォトダイオード(PD)  
メーカ: Agiltron Inc.  
品名: 光電界センサー  

モデル:  
- モデル: (型番なし)  

# 光電界センサー
周波数帯域: 0.25 ~ 18GHz  
メーカ： Agiltron Inc.  

光で電界を測定することができるセンサーです。非鉄製品でかつ、オールパッシブであるため、測定センサー自身から外乱を発生させることはありません。広帯域を高感度に測定できます。

## 特長
- 金属部品不使用
- 小型
- 光ファイバー読み出し
- 高い衝撃/振動耐性
- 高感度
- 広帯域
- 高ダメージ閾値

## 用途
- HPMのテスト＆評価
- HRI、EMPシステム
- PAAレーダ
- アクティブディナイアルシステム

## 仕様詳細
この仕様表は、光電界センサーの主要な性能パラメータを示しています。周波数帯域は、Ultra Highで最大18GHz、高周波で7GHz、低周波で250MHzです。感度は、Ultra Highで10 mV/m-Hz1/2、Ultra-High frequencyで20 mV/m-Hz1/2、Low frequencyで5 mV/m-Hz1/2です。最大検出Eフィールドは200 kV/m、ダメージEフィールドは5 MV/mです。パッケージ寸法はデザイン参照となります。

|     |     |     |     |
| --- | --- | --- | --- |
| **パラメータ** | **Typical** | **Max** | **Unit** |
| 周波数帯域 (Ultra High) |  | 18 | GHz |
| (High) |  | 7 | GHz |
| (Low) |  | 250 | MHz |
| 感度 \[1\] (Ultra High) | 10 |  | mV/m-Hz1/2 |
| (Ultra-High frequency) | 20 |  | mV/m-Hz1/2 |
| (Low frequency) | 5 |  | mV/m-Hz1/2 |
| 最大検出Eフィールド \[2\] | 200 |  | kV/m |
| ダメージEフィールド |  | 5 | MV/m |
| パッケージ寸法 | デザイン参照 |  |  |

## 資料ダウンロード
- [光電界センサー『EOFS』データシート](https://www.sevensix.co.jp/wp-content/uploads/%E5%85%89%E9%9B%BB%E7%95%8C%E3%82%BB%E3%83%B3%E3%82%B5%E3%83%BC%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ  

# Source URL: https://www.sevensix.co.jp/products/sensor_agiltron/