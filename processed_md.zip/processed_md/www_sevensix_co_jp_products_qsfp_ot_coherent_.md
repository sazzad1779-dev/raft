# 400GbE/100GbE QSFP 光トランシーバ

**カテゴリ:** 光通信 / 同軸・RF関連  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  
**伝送速度:** 400G/100Gbps  

最新の400G/100Gbpsイーサネット通信規格（IEEE802.3bs, IEEE802.3ba）に対応した光トランシーバです。

## 用途
- データセンター
- 光アクセス
- 基幹系インフラ
- 通信

## 仕様詳細

以下の表は、400GbEおよび100GbE QSFP光トランシーバの主要な仕様を示しています。各モデルのベンダ名、型番、対応プロトコル、伝送レート、伝送距離、光コネクタ、LD種類・構成・波長が含まれています。

| モデル名 | ベンダ名 | 型番 | 対応プロトコル | 伝送レート | 伝送距離 | 光コネクタ／対応ファイバ | LD種類・構成・波長 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 400GbE-FR4 QSFP-DD | Finisar | FTCD4313E1PCL | 400GBASE-FR4 | 4 x 100Gbps PAM4 | 2km | LC／SMF | CWDM LD x 4 |
| 400GbE-DR4+ QSFP-DD | Finisar | FTCD4533E2PxM | 400GBASE-DR4+ | 4 x 100Gbps PAM4 | 2km | MPO／SMF | 1310nm LD x 4 |
| 400GbE-DR4 QSFP-DD | Finisar | FTCD4523E2PxM | 400GBASE-DR4 | 400Gbps(4 x 100Gbps) | 500m | MPO／SMF | 1310nm LD x 4 |
| 100GbE-FR QSFP28 | Finisar | FTLC4351RJPL | 100GBASE-FR | 100Gbps PAM4 | 2km | LC／SMF | 1310nm LD |
| 100GbE-DR QSFP28 | Finisar | FTLC4351RHPL | 100GBASE-DR | 100Gbps PAM4 | 500m | LC／SMF | 1310nm LD |
| 400GbE-LR8 QSFP-DD | Finisar | FTCD1323E1PCL | 400GBASE-LR8 | 8 x 50Gbps PAM4 LAN-WDM DFB | 10km | LC／SMF | LAN-WDM DFB x 8 |
| 400GbE-FR8 QSFP-DD | Finisar | FTCD1333E1PCL | 400GBASE-FR8 | 8 x 50Gbps PAM4 | 2km | LC／SMF | LAN-WDM DFB x 8 |
| 400GbE-SR8 QSFP-DD | Finisar | FTCD8613E1PCM | 400GBASE-SR8 | 8 x 50Gbps PAM4 | 100m | MPO16／OM4 | 850nm VCSEL x 8 |
| 400GbE AOC | Finisar | FCBR850QE1Cxx | N/A | 400Gbps | 1m～70m | N/A／N/A | N/A |

## 資料ダウンロード
- [スペックシート：400G QSFP-DD Active Optical Cable](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-850-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-LR8 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-1323-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-FR8 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-1333-Specifications.pdf#view=Fit)
- [スペックシート：100GBASE-FR QSFP28 Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4351-Specifications.pdf#view=Fit)
- [スペックシート：100GBASE-DR QSFP28 Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4351R-Specifications.pdf#view=Fit)
- [スペックシート：400GBASE-DR4 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4523-Specifications.pdf#view=Fit)
- [スペックシート：400G-DR4+ QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-4533-Specifications.pdf#view=Fit)
- [スペックシート：400G-FR4 QSFP-DD Optical Transceiver Module](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-8519-1-Specifications.pdf#view=Fit)
- [スペックシート：400G-SR8 QSFP-DD](https://www.sevensix.co.jp/wp-content/uploads/FTRJ-8613-Specifications.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ  
**Source URL:** [https://www.sevensix.co.jp/products/qsfp_ot_coherent/](https://www.sevensix.co.jp/products/qsfp_ot_coherent/)