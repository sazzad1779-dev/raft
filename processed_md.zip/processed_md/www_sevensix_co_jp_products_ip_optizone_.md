# インラインポラライザ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** その他光ファイバ部品  
**小カテゴリ:** インラインポラライザ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 850 ~ 2000nm  

Optizone Technology Limitedのインラインポラライザは、中国の深センに拠点を構え、高品質・高安定性を兼ね備えた光ファイバ部品です。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、年間1000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低損失
- 高リターンロス

## 用途
- 研究開発
- ファイバレーザ
- センサ

## 仕様詳細
以下の表は、インラインポラライザの主要な仕様を示しています。

| 項目         | 詳細内容                                           |
|--------------|---------------------------------------------------|
| 波長         | 850nm、1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、LC/PC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                           |

## 資料ダウンロード
- [データシート：850nm In-line Polarizer](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-035D-ILP-850nm.pdf#view=Fit)
- [データシート：1064nm In-line Polarizer](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-002D-ILP-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm In-line Polarizer](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-003E-ILP-1310nm1550nm.pdf#view=Fit)
- [データシート：2000nm In-line Polarizer](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-019C-ILP-2000nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm High Power In-line Polarizer](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-015D-HILP-1310nm1550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/ip_optizone/)から。