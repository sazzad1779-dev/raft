# DFB / DBR レーザー

## 製品概要
- **カテゴリ**: 半導体レーザーダイオード（LD）
- **中カテゴリ**: シードLD
- **メーカー**: eagleyard Photonics GmbH
- **品名**: DFB / DBR レーザー
- **波長**: 760 ~ 1083nm
- **出力**: 最大 500mW

DFB / DBRレーザーは、レーザーチップに波長選択性の回折格子を組み込んだ単一周波数レーザーダイオードです。この設計により、非常に小さな線幅と低い位相雑音を持つ準単色光を放出します。

## 特長
- ガウシアンモードを採用しているため、出力は回折限界。
- モード分割ノイズがないため、非常に低い強度のノイズ性。

## 用途
- 酸素検出用
- VCSEL置き換え
- Rb D2 スペクトル

## 仕様詳細
以下の表は、DFB / DBRレーザーの主要な仕様を示しています。各モデルの波長、出力パワー、モード、パッケージタイプが記載されています。

| 製品名 | 波長 (nm) | 出力パワー (mW) | モード | パッケージ |
| --- | --- | --- | --- | --- |
| EYP-DFB-0760-00006-1500-BFY12-0005 | 760.9 ± 1 | 6 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0760-00030-1500-BFY02-0005 | 760.9 ± 1 | 30 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0760-00040-1500-BFW01-0005 | 760.9 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0760-00040-1500-TOV01-0005 | 760.9 ± 1 | 40 | CW | hermetic 8 Pin TO Package |
| EYP-DFB-0760-00040-1500-TOC03-0005 | 760.9 ± 1 | 40 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0767-00050-1500-BFW01-0005 | 767 ± 1 | 50 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0767-00050-1500-TOC03-0005 | 767 ± 1 | 50 | CW | hermetic 8 Pin TO Package |
| EYP-ECL-0770-00080-1500-BFW01-0005 | 770 ± 1 | 80 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00020-1500-BFY12-0005 | 780 ± 1 | 20 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00040-1500-BFW11-0005 | 780 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00040-1500-BFY02-0000 | 780 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00040-1500-BFY02-0002 | 780 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-RWS-0780-00080-1500-TOV01-0000 | 778(min)<br>780(typ)<br>783(max) | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0780-00080-1500-BFW01-0002 | 780 ± 1 | 80 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00080-1500-BFW01-0005 | 780 ± 1 | 80 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0780-00080-1500-TOC03-0000 | 780 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0780-00080-1500-TOC03-0002 | 780 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0780-00080-1500-TOC03-0005 | 780 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0780-00080-1500-TOV01-0005 | 780 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-ECL-0780-00080-1500-BFW01-0005 | 780 ± 1 | 80 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0785-00040-1500-BFY02-0000 | 785 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0785-00040-1500-BFY02-0002 | 785 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0785-00100-1500-TOV01-0000 | 785 ± 1 | 100 | CW | hermetic TO Package |
| EYP-DFB-0795-00040-1500-BFW11-0005 | 795 ± 1 | 40 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0795-00080-1500-BFW01-0005 | 795 ± 1 | 80 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0852-00015-1500-BFY12-0005 | 852 ± 1 | 15 | CW | hermetic 14 Pin Butterfly Housing |
| EYP-DFB-0852-00050-1500-BFY02-0000 | 852 ± 1 | 50 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-0852-00050-1500-BFY02-0002 | 852 ± 1 | 50 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-ECL-0852-00080-1500-BFW01-0005 | 852 ± 1 | 80 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-0852-00100-1500-BFW01-0002 | 852 ± 1 | 100 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-0852-00100-1500-BFW01-0005 | 852 ± 1 | 100 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-0852-00150-1500-TOC03-0000 | 852 ± 1 | 150 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0852-00150-1500-TOC03-0002 | 852 ± 1 | 150 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0852-00150-1500-TOC03-0005 | 852 ± 1 | 150 | CW | hermetic 8-Pin TO Package |
| EYP-ECL-0895-00080-1500-BFW01-0005 | 894 ± 1 | 80 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-0922-00080-1500-TOC03-0005 | 922 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0935-00080-1500-TOC03-0004 | 935 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-0935-00080-1500-TOC03-0005 | 934(min)<br>935(typ)<br>937(max) | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-1030-00500-1500-BFY02-0010 | 1030 ± 2 | 600 | パルス | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1060-00040-1500-BFY02-0002 | 1060 ± 1 | 40 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1064-00025-1500-BFY12-0002 | 1064 ± 1 | 25 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1064-00040-1500-BFY02-0000 | 1064 ± 1 | 40 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1064-00040-1500-BFY02-0002 | 1064 ± 1 | 40 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1064-00080-1500-TOC03-0000 | 1064 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-1064-00080-1500-TOC03-0002 | 1064 ± 1 | 80 | CW | hermetic 8-Pin TO Package |
| EYP-DFB-1064-00500-1500-BFY02-0010 | 1064 ± 2 | 600 | パルス | hermetic 14-Pin Butterfly Housing |
| EYP-TBR-1064-02000-6000-BTW09-0000 | 1064 ± 1 | 2,0(W) | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00025-1500-BFY12-0002 | 1083 ± 1 | 23 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00030-1500-BFY02-0000 | 1083 ± 1 | 30 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00030-1500-BFY02-0002 | 1083 ± 1 | 30 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00080-1500-BFW01-0000 | 1083 ± 1 | 80 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00080-1500-BFW01-0002 | 1083 ± 1 | 80 | CW | hermetic 14-Pin Butterfly Housing |
| EYP-DFB-1083-00080-1500-TOC03-0000 | 1083 ± 1 | 80 | CW | hermetic 8 Pin TO Package |
| EYP-DFB-1083-00080-1500-TOC03-0002 | 1083 ± 1 | 80 | CW | hermetic 8 Pin TO Package |

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行ってください。  
[製品リンク](https://www.sevensix.co.jp/products/dfblaser_eagleyard/)