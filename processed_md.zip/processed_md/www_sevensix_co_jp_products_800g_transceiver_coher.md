# 800G ZR/ZR+ QSFP-DD DCO 光トランシーバ

**カテゴリ:** 光通信 / 同軸・RF関連  
**中カテゴリ:** 光トランシーバ  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  

**Source URL:** [https://www.sevensix.co.jp/products/800g_transceiver_coherent/](https://www.sevensix.co.jp/products/800g_transceiver_coherent/)

## 概要
800G ZR/ZR+ QSFP-DD DCO 光トランシーバは、OIF800ZRおよびOpenZR+ MSAに対応したデジタルコヒーレント光トランシーバです。独自のInP+SOA技術を基盤とし、SiP+EDFA基盤に比べて集積化が容易でシンプルな構成を実現しています。C-bandおよびL-bandの波長に対応し、高出力モデルもサポートしています。

## 特長
- **技術:** 独自のInP+SOA技術を採用し、集積化とシンプルな構成を実現
- **波長対応:** C-bandおよびL-bandに対応
- **高出力:** High Tx Power 0 dBmに対応
- **インターフェース:** QSFP-DDおよびOSFPに対応
- **消費電力:** 低消費電力 (<28W@OIF800ZR, <31W@OpenZR+)
- **変調フォーマット:** 様々な変調フォーマットをサポート

## 用途
- データセンター間接続
- テレコムネットワーク
- モバイルネットワーク

## 資料ダウンロード
- [カタログ：800G ZR/ZR+ QSFP-DD DCO 光トランシーバ](https://www.sevensix.co.jp/wp-content/uploads/non-NDAFTCE33x6R1PCL-800G-QSFP-DD-DCO-ZR-vA01.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ