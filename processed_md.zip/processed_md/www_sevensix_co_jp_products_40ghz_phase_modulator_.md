# 薄膜LN 40GHz Ultra-low Vπ光位相変調器

- **カテゴリ**: 光変調器
- **メーカー**: HyperLight
- **モデル**: 型番なし
- **波長帯**: C / L-band

HyperLight社の薄膜LN 40GHz Ultra-low Vπ光位相変調器は、従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現しています。

## 特長
- **Ultra Low-Vπ**
- **高いRF電力処理能力**: 外部終端で5Wの高出力RFを処理
- **帯域幅**: 40 GHz以上
- **シンプルなモジュレーターソリューション**: EOコンバージョン生成用の一体型モジュレーター
- **C/L-bandサポート**

## 用途
- EOコンバージョン生成
- 量子測定
- マイクロ波フォトニクス

## 資料ダウンロード
- [カタログ：薄膜LN 40GHz Ultra-low Vπ光位相変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-Ultra-low-Vpai-Phase-Modulator.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/40ghz-phase_modulator-hyperlight/