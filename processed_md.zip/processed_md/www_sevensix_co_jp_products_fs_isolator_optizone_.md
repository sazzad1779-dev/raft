# フリースペースアイソレータ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** 光ファイバアイソレータ  
**小カテゴリ:** SMアイソレータ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 915 ~ 2000nm  

Optizone Technology Limitedのフリースペースアイソレータは、中国の深センに拠点を構え、高品質・高安定性を兼ね備えた製品です。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、年間18,000ケ以上を生産しています。主要地域として北米、ヨーロッパ、アジアを含む全世界へ出荷されており、高出力用受動部品を特に得意としています。9000㎡の大規模な工場で、カスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- ハイパワーハンドリング

## 用途
- 半導体レーザ
- 個体レーザ

## 仕様詳細
以下の表は、フリースペースアイソレータの主要な仕様を示しています。

| 項目             | 詳細内容                                      |
|------------------|-----------------------------------------------|
| 波長             | 915nm、980nm、1064nm、1310nm、1550nm、2000nm、その他も対応可 |
| ステージ         | Single Stage、Dual Stage                     |
| 光路             | Forward、Backward                             |
| パッケージサイズ | dia2.8×3.7mm、その他対応可能                 |
| ハンドリングパワー | 20W、50W、80W、100W、その他対応可能         |
| 有効開口         | 4.7mm、5.0mm、その他対応可能                 |
| 波長範囲         | λ±10nm、λ±40nm                              |

## 資料ダウンロード
- データシート：1064nm Free Space Isolator
- データシート：1310/1550nm Free Space Isolator
- [データシート：2000nm Free Space Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-017C-FSI-2000nm.pdf#view=Fit)
- [データシート：980nm High Power Free Space Isolator Sensitive C149](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-074B-HPFSI-98-C149-20-50-S.pdf#view=Fit)
- [データシート：1064nm High Power Free Space Isolator Sensitive C147](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-073B-HPFSI-06-C147-80-47-S-10.pdf#view=Fit)
- [データシート：1064nm High Power Free Space Isolator Sensitive](https://www.sevensix.co.jp/wp-content/uploads/79972fcb35d22a320bfa393741a0ea5d.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/fs_isolator_optizone/)から。