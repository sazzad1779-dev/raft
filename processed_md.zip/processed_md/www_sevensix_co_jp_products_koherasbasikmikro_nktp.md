# OEM型 超低ノイズ 狭線幅 ファイバーレーザー『Koheras BASIK MIKRO』

- **カテゴリ**: ファイバーレーザー・その他光源
- **中カテゴリ**: 狭線幅CWレーザー光源
- **メーカー**: NKT Photonics A/S
- **モデル**: (型番なし)
- **波長**: 1535 ~ 1580 nm
- **出力**: 40 mW

『Koheras BASIK MIKRO』は、産業センシングシステムのOEM統合用に設計された業界で最も小型な産業向け単一周波数ファイバレーザーです。Koheras BASIK MIKROモジュールはレーザ制御回路が完全に統合されており、レーザの性能を継続的にモニタリングできます。

## 特長
- OEM用途に適した小さな設置面積
- 低位相雑音と狭線幅
- 堅牢な単一周波数動作
- 高い波長安定性
- PM出力、高速波長チューニングオプション
- センサへのOEM統合に最適

発振波長は1535 – 1580 nmの範囲で選択可能ですが、標準品の発振波長は1550.12 nmです。オプションで用意しているUSBインタフェースキットとKoheras MIKROを使用することで、NKT Photonicsが無料配布しているGUIであるNKTP CONTROLソフトウェアを用いて制御することができます。

## Koheras BASIKシリーズとKoheras BASIK MIKROの違い

## 資料ダウンロード
- [データシート：Koheras BASIK MIKRO](https://www.sevensix.co.jp/wp-content/uploads/koheras-mikro-datasheet.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

# Source URL: https://www.sevensix.co.jp/products/koherasbasikmikro_nktp/