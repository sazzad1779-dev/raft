# ファイバーミラー

## 製品概要
- **品名**: ファイバーミラー
- **モデル**: (型番なし)
- **メーカー**: Optizone Technology Limited
- **カテゴリ**: 光ファイバ部品 > その他光ファイバ部品 > ファイバーミラー
- **波長範囲**: 1064 ~ 2000nm

Optizone Technology Limitedは、中国の深センに拠点を構え、高品質・高安定性を兼ね備えたファイバーミラーを提供しています。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、年間20,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9,000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失

## 用途
- レーザ
- ファイバーセンサ

## 仕様詳細
以下の表は、ファイバーミラーの主要な仕様を示しています。

| 項目         | 詳細内容                                           |
|--------------|---------------------------------------------------|
| 波長         | 1064nm、1310nm、1480nm、1530nm、1550nm、2000nm、その他も対応可 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                           |

## 資料ダウンロード
- [データシート：1064nm Optical Fiber Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-005B-OFM-1064nm.pdf#view=Fit)
- [データシート：1310nm～1550nm Optical Fiber Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-006B-OFM-1310nm1550nm.pdf#view=Fit)
- [データシート：2000nm Optical Fiber Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-022B-2000nm-Optical-Fiber-Mirror.pdf#view=Fit)
- [データシート：1064nm Polarization Maintaining Optical Fiber Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-034B-PMOFM-1064nm.pdf#view=Fit)
- [データシート：1310nm～1550nm Polarization Maintaining Optical Fiber Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-033B-PMOFM-1310nm1550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の資料ダウンロードリンクを参照してください。

# Source URL: https://www.sevensix.co.jp/products/fiberm_optizone/