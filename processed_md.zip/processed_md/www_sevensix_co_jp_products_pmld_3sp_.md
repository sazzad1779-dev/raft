# コア励起用ファブリペローレーザー (CW) PMファイバ

## 概要
- **カテゴリ**: 半導体レーザーダイオード（LD）
- **中カテゴリ**: ファブリペローレーザー
- **小カテゴリ**: PMファイバ
- **メーカー**: 3SP Technologies
- **モデル**: 型番なし
- **波長**: 974.0 ~ 981.0 nm
- **出力**: 100 ~ 950 mW

この製品は、最大950 mWの出力を持ち、FBGはSMF上に書かれており、波長は974.0 nm、974.5 nm、976.0 nm、979.5 nm、981.0 nmから選択可能です。動作温度範囲は-5 °Cから+75 °Cで、RoHS指令に対応しています。

## 特長
- 14ピン / 8ピン バタフライパッケージ
- 1999PLM、1999HPM、1999CHB、1999CVBの多様なグレード展開
- 高い波長安定性と電力安定性
- Telcordia GR-468-CORE認定済

## 用途
- ファイバレーザ、パルスレーザアンプ励起
- 産業用アプリケーション向け
- 高出力・低ノイズのEDFA
- 高密度波長分割多重伝送

## 仕様詳細

### 14ピン PMファイバ
以下の表は、異なる波長と出力に対するモデル番号を示しています。

| 出力   | 974.0 nm<br>T= 25 °C | 976.0 nm<br>T= 25 °C | 979.5 nm<br>T= 25 °C | 981.0 nm<br>T= 25 °C |
|--------|-----------------------|-----------------------|-----------------------|-----------------------|
| 350 mW | [3CN01784CL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794CL](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 400 mW | [3CN01784DA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN014DA79](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 450 mW | [3CN01784DL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794DL](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 500 mW | [3CN01784EA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794EA](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 540 mW | [3CN01784EJ](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794EJ](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 600 mW | [3CN01784FA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794FA](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 650 mW | [3CN01784FL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794FL](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 680 mW | [3CN01784FS](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01794FS](https://www.sevensix.co.jp/products/pmld_3sp/) | **–** | **–** |
| 700 mW | [3CN01764GA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765GA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800GA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766GA](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 750 mW | [3CN01764GL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765GL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800GL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766GL](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 800 mW | [3CN01764HA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765HA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800HA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766HA](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 850 mW | [3CN01764HL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765HL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800HL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766HL](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 900 mW | [3CN01764JA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765JA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800JA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766JA](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 950 mW | [3CN01764JL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01765JL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01800JL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01766JL](https://www.sevensix.co.jp/products/pmld_3sp/) |

### 8ピン PMファイバ
以下の表は、異なる波長と出力に対するモデル番号を示しています。

| 出力   | 974.5 nm<br>T= 25 °C | 976.0 nm<br>T= 25 °C |
|--------|-----------------------|-----------------------|
| 100 mW | [3CN01750AA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01751AA](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 150 mW | [3CN01750AL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01751AL](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 200 mW | [3CN01750BA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01751BA](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 250 mW | [3CN01750BL](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01751BL](https://www.sevensix.co.jp/products/pmld_3sp/) |
| 300 mW | [3CN01750CA](https://www.sevensix.co.jp/products/pmld_3sp/) | [3CN01751CA](https://www.sevensix.co.jp/products/pmld_3sp/) |

## 製品に関するお問い合わせ
[製品のお問い合わせ](https://www.sevensix.co.jp/products/pmld_3sp/)