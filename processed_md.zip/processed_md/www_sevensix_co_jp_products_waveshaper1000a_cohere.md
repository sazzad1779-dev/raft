# 1 μm 超短パルスファイバレーザー用 時間・スペクトルプロセッサ WaveShaper『1000A/SP』

## 概要
- **カテゴリ**: 光増幅器/光変調器/PD/光フィルタ他
- **中カテゴリ**: 光フィルタ
- **小カテゴリ**: 光任意波形成形器(Wave Shaper)
- **メーカー**: Coherent (旧 II-VI)
- **モデル**: 1um 超短パルス ファイバレーザー用 時間・スペクトルプロセッサ WaveShaper『1000A/SP』
- **動作波長範囲**: 1 μm, C-Band, C+L-Band

WaveShaper『1000A/SP』は、LCoSをベースにした光の振幅と位相を独立に制御できるフィルタです。高安定・高再現性を特徴とし、PCと接続して専用ソフトウェアで制御します。

## 特長
- 振幅と位相を任意制御
- 振幅の減衰設定: 
  - 0~25 dB@1 μm
  - 0~35 dB@C-band, C+L-band
- 設定可能な群遅延: ± 13~25 ps
- PMファイバ入出力
- LCoSベースで可動部なし
- 小型・堅牢なOEMモジュール

## 用途
- ファイバレーザー構築
- 微細加工
- パルス圧縮と拡張
- パルスシェープ
- マルチパルス化
- スーパーコンティニューム光の生成

WaveShaper『1000A/SP』は、1 μm帯ファイバレーザーのパルス圧縮に特化して設計されています。信頼性と再現性が高く、PMファイバを使用しています。

## アプリケーション事例
- **モードロックレーザー**や**光ファイバ増幅器**と組み合わせることで性能を最大限に発揮します。
- 推奨光源:
  1. 光周波数コム光源『Frush』
  2. 超短パルスファイバレーザー『iQoM』

### アプリケーション事例①：波長広帯域化とフェムト秒パルスの生成
### アプリケーション事例②：超短パルス光の出力

## 仕様詳細

### WaveShaperシリーズ概要
以下の表は、WaveShaperシリーズの主要なモデルとその仕様を示しています。

| シリーズ名 | モデル番号 | ポート | 動作波長範囲 | フィルタ波形 |
| --- | --- | --- | --- | --- |
| WaveShaper Short-Pulse Shaping | WS-01000A/SP | 1×1 | 1μ, C-band, C+L-band | 減衰と位相が任意 |
| WaveShaper A-Series | WS-01000A/S, WS-04000A/S Series | 1×1, 1×4 | S-band | 減衰と位相が任意 |
|  | WS-01000A/U, WS-04000A/U Series | 1×1, 1×4 | U-band | 減衰と位相が任意 |
| WaveShaper B-Series | WS 500B-Series | 1×1 | Super C-band, Super L-band | 減衰が任意 |
|  | WS 1000B-Series | 1×1 | Super C-band, Super L-band, C+L-band, O-band | 減衰と位相が任意 |
|  | WS 4000B-Series | 1×4 | Super C-band, Super L-band, C+L-band | 減衰と位相が任意 |
|  | WS 3200xB-Series | 1×31, 4×28, 8×24, 12×20, 16×16 | Super C-band, Super C+ Super L-band | 減衰と位相が任意 |

### WaveShaper 1000A/SP の使用詳細
WaveShaper 1000A/SPは、入力コネクタから入ったレーザーを回折格子で波長分解し、LCoSで制御された光を出力ファイバに結合します。最大25~35 dBの減衰を与え、群遅延はLCoSで制御されます。USB 2.0またはギガビットイーサネットでPCに接続し、専用ソフトウェアで制御します。

## セブンシックスの技術サポート
- 導入前・導入後の相談
- 製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyzeのオリジナルソフトウェアサポート
- 修理対応 (電源系、ファン、ファイバ端面等の交換・修理)

## 資料ダウンロード
- [カタログ：WaveShaper『1000A/SP』](https://www.sevensix.co.jp/wp-content/uploads/waveshaper-1000a-sp-ds.pdf#view=Fit)

## 関連製品
- 超短パルスファイバレーザー『iQoM』 - 波長: 1040 / 1064 nm　パルス幅: 3 - 15 / 2 - 8 ps
- 光周波数コム発生器 Frush - 波長帯 1550 nm / FSR 12－18 GHz
- C+L-band 高分解能 光スペクトラム・アナライザ『WaveAnalyzer 400A』 - 帯域幅：1527.8 ~ 1610.05nm
- ポータブル高分解能光スペクトラムアナライザ : WaveAnalyzer『200B/200A』 - Super C-band帯 (1523.9 ~ 1572.7nm)対応
- 高性能光スペクトラムアナライザ : WaveAnalyzer - C-Band フルカバー
- 通信帯域 スペクトル・分散制御プロセッサ WaveShaper A/Bシリーズ - O / S / C / L / U-band対応

# Source URL: https://www.sevensix.co.jp/products/waveshaper1000a_coherent/