# 偏波保持WDMフィルタ型カプラ

## 概要
- **品名**: 偏波保持WDMフィルタ型カプラ
- **モデル**: (型番なし)
- **カテゴリ**: 光ファイバ部品 / WDMカプラ
- **メーカー**: Optizone Technology Limited
- **波長範囲**: 980 ~ 2000nm Pass / 980 ~ 1570nm Reflect

Optizone Technologiesは中国の深センに拠点を構え、全製品はTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を得意としており、9000㎡の工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高リターンロス

## 用途
- ファイバレーザ
- 研究用途

## 仕様詳細
以下の表は、偏波保持WDMフィルタ型カプラの主要な仕様を示しています。

| 項目         | 詳細内容                                                                                     |
|--------------|----------------------------------------------------------------------------------------------|
| 波長         | 9806 – 980nm Pass / 1064nm Reflect、0698 – 1064nm Pass / 980nm Reflect、5598 – 1550nm Pass / 980nm Reflect、2057 – 2000nm Pass / 1570nm Reflect、3155 – 1310nm Pass / 1550nm Reflect、5531 – 1550nm Pass / 1310nm Reflect、4855 – 1480nm Pass / 1550nm Reflect、5548 – 1550nm Pass / 1480nm Reflect、5155 – 1510nm Pass / 1550nm Reflect、5551 – 1550nm Pass / 1510nm Reflect |
| ファイバタイプ | PM 1550 Fiber (all ports)、PM 1550 Fiber at Common & Reflect ports and PM 1950 Fiber at Pass port、その他対応可能 |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、無し、その他対応可能                                      |
| ファイバジャケット | 250umベアファイバ、900umルーズチューブ、その他対応可能                                   |
| ファイバ長   | 0.8m、その他対応可能                                                                        |
| ハンドリングパワー | 1W、その他対応可能                                                                        |

## 資料ダウンロード
- [データシート：9806nm-9803nm Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-025D-PMFWDM-9806nm-9803nm-2.pdf#view=Fit)
- [データシート：5598nm Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-032D-PMFWDM-5598nm.pdf#view=Fit)
- [データシート：9806nm-9803nm Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/PMFWDM-9806nm-9803nm-1.pdf#view=Fit)
- [データシート：2000nm Polarization Maintaining Filter Wavelength Division Multiplexers](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-016D-PMFWDM-2057.pdf#view=Fit)
- [データシート：9806nm-9803nm High Power Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-049C-HPMFWDM-9806nm-9803nm.pdf#view=Fit)
- [データシート：5598nm High Power Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-048C-HPMFWDM-5598nm.pdf#view=Fit)
- [データシート：3155nm~5551nm High Power Polarization Maintaining Filter Wavelength Division Multiplexers](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-047C-HPMFWDM-3155nm5551nm.pdf#view=Fit)
- [データシート：2000nm High Power Polarization Maintaining Filter Wavelength Division Multiplexers](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-060C-HPMFWDM-2057-CAT-05-060C.pdf#view=Fit)
- [データシート：9806nm-9803nm High Power Polarization Maintaining Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-11-001B-HPMFWDM-for-Ultra-fast-Laser-9806nm-9803nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の情報を参照してください。

# Source URL: https://www.sevensix.co.jp/products/pm_wdmfiltertc_optizone/