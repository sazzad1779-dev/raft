# ラマン励起用 シングルモード半導体レーザー

## 製品概要
- **カテゴリ**: 半導体レーザーダイオード（LD）
- **中カテゴリ**: ファブリペローレーザー
- **小カテゴリ**: PMファイバ
- **メーカー**: 3SP Technologies
- **モデル**: (型番なし)
- **波長**: 1420 ~ 1510 nm
- **出力**: 300 ~ 500 mW
- **動作温度範囲**: -5℃～70°C
- **RoHS指令対応品**: はい

[製品URL](https://www.sevensix.co.jp/products/ramanld_3sp/)

## 特長
- 14ピンバタフライ型モジュール
- TEC、NTCサーミスタ、モニタリングPDを内蔵
- Telcordia GR-468-CORE認定済

## 用途
- FTTH用途向けのラマンアンプ
- ラマン分光の励起光源

## 仕様詳細
### 電気光学特性
- **Tsubmount**: 35°C
- **Tcase**: -5 to 70°C
- **TFBG**: 25°CのBOLで規定

## 資料ダウンロード
- [データシート：ラマン励起用 シングルモード半導体レーザー](https://www.sevensix.co.jp/wp-content/uploads/3SP-%E3%83%A9%E3%83%9E%E3%83%B3%E3%82%A2%E3%83%B3%E3%83%97.pdf#view=Fit)