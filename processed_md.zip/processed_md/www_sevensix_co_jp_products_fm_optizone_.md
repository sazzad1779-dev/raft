# ファラデーミラー

## 製品概要
- **品名**: ファラデーミラー
- **モデル**: (型番なし)
- **メーカー**: Optizone Technology Limited
- **カテゴリ**: 光ファイバ部品 > その他光ファイバ部品 > ファラデーミラー
- **波長範囲**: 1064 ~ 1550nm

Optizone Technology Limitedは、中国の深センに拠点を構え、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 高リターンロス
- 高消光比
- 低挿入損失

## 用途
- ファイバセンサ
- 光増幅器
- ファイバレーザ

## 仕様詳細
以下の表は、ファラデーミラーの主要な仕様を示しています。

| 項目         | 詳細内容                                           |
|--------------|---------------------------------------------------|
| 波長         | 1064nm、1310nm、1480nm、1550nm、その他も対応可   |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、400umベアファイバ、900umルーズチューブ、3mmケーブル、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                           |

## 資料ダウンロード
- [データシート：1064nm Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-003B-FM-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-004B-FM-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Mini Fiber Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/MFM-1310nm-1480nm-1550nmCAT-10-008B.pdf#view=Fit)
- [データシート：1064nm Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-022B-PMFM-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-023B-PMFM-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Mini Polarization Maintaining Faraday Mirror](https://www.sevensix.co.jp/wp-content/uploads/MPMFM-1310nm-1480nm-1550nmCAT-09-038A-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の情報を参照してください。

# Source URL: https://www.sevensix.co.jp/products/fm_optizone/