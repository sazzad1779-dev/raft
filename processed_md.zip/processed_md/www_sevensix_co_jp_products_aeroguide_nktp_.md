# aeroGUIDE ラージモードエリアフォトニック結晶ファイバパッチコード

- **カテゴリ**: 光ファイバ素線 / 光ファイバパッチコード
- **中カテゴリ**: 光ファイバパッチコード
- **小カテゴリ**: PCFパッチコード
- **メーカー**: NKT Photonics A/S
- **モデル**: (型番なし)
- **波長**: 400 ~ 2000nm

## 概要
aeroGUIDE ラージモードエリアフォトニック結晶ファイバを用いたパッチコードです。以下のシリーズがあります。

### aeroGUIDE シリーズ
- **モデル**: LMA-PM-5、LMA-8、LMA-PM-10、LMA-PM-15
- **コネクタ**: 両端にFC/APCコネクタ
- **耐久パワー**: 2W CW

### aeroGUIDE Power シリーズ
- **モデル**: LMA-PM-15
- **コネクタ**: 両端にSMA905コネクタ

## 特長
- シングルモード伝送
- 400~2000nmの広帯域伝送が可能

## 資料ダウンロード
- [データシート：aeroGUIDE](https://www.sevensix.co.jp/wp-content/uploads/aeroGUIDE.pdf#view=Fit)
- [データシート：aeroGUIDE Power](https://www.sevensix.co.jp/wp-content/uploads/aeroGUIDE-Power.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

# Source URL: https://www.sevensix.co.jp/products/aeroguide_nktp/