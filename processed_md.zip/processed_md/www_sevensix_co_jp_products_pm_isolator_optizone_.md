# 偏波保持アイソレータ

## 概要
- **品名**: 偏波保持アイソレータ
- **モデル**: (型番なし)
- **メーカー**: Optizone Technology Limited
- **カテゴリ**: 光ファイバ部品 > 光ファイバアイソレータ > PMアイソレータ
- **波長**: 1064 ~ 2000nm

Optizone Technology Limitedは、中国の深センに拠点を構える企業で、全製品はTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高アイソレーション
- 低偏波依存性損失

## 用途
- 光ファイバ増幅器
- ファイバレーザ
- ファイバセンサ

## 仕様詳細
以下の表は、偏波保持アイソレータの主要な仕様を示しています。

| 項目               | 内容                                         |
|--------------------|--------------------------------------------|
| **波長**           | 1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可 |
| **ステージ**       | シングルステージ、デュアルステージ       |
| **光軸アライメント** | Fast Axis Blocked、Both Axis Working     |
| **コネクタタイプ**   | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| **ファイバ被膜**     | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| **ファイバ長**       | 標準1m、その他も対応可                     |

## 資料ダウンロード
- [データシート：1064nm Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-026C-PMI-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-027C-PMI-1310nm1550nm.pdf#view=Fit)
- [データシート：2000nm Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-013D-PMI-2000.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Twin Polarization Maintaining Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-036C-TPMI-1310nm1550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/pm_isolator_optizone/)から。