# 高性能光スペクトラムアナライザ : WaveAnalyzer

**カテゴリ:** 光計測器  
**中カテゴリ:** 光スペクトラムアナライザ  
**メーカー:** Coherent (旧 II-VI)  
**モデル:** 型番なし  

**Source URL:** [WaveAnalyzer](https://www.sevensix.co.jp/products/wa100s1500s_coherent/)

WaveAnalyzerは、リアルタイムかつ高分解能で1527 – 1612 nmの波長帯を測定できる光スペクトラムアナライザです。光通信分野の研究用途や、光通信関連部品の工場での検査用途に最適です。さらに、当社オリジナル・ソフトウェアのサポートも提供しています。

## 特長
- C-band/L-band 高い分解能帯域幅／1500S: 180MHz
- リアルタイム測定／1500S: 4 update/s
- 小型軽量／1500S: 4kg
- USB, Ethernet 接続

## 用途
WaveAnalyzerはコヒーレント検波方式の光スペクトラム・アナライザです。内部にはFinisar社の高速掃引可能なローカルオシレータとコヒーレントレシーバが内蔵されており、非常に高分解能な測定が可能です。LN変調器の試験、LN変調器のバイアス調整、トランシーバの試験に使用できます。また、リアルタイムでの測定が可能なため、モードロックレーザの調整時に調整結果を確認できます。

以下のモデルのデモ機がございますのでお申し付けください。
- WaveAnalyzer 1500S (C-band)
- WaveAnalyzer 1500S (L-band)
- WaveAnalyzer 200A (ポータブルタイプ)

## 仕様詳細
以下の表は、WaveAnalyzerの主要な仕様を示しています。

| 項目                     | 値               |
|------------------------|-----------------|
| 波長(nm)               | 1527 ～ 1612    |
| 耐光出力(dBm)          | 10 ～ 23        |
| サンプリング分解能(MHz) | 20 ～ 312.5     |
| 分解能帯域幅(MHz)      | 180 ～ 1750     |

### WaveAnalyzerモデルの比較
WaveAnalyzerには、WaveAnalyzer 100SとWaveAnalyzer 1500Sの2モデルがあります。WaveAnalyzer 1500Sは分解能が180 MHzと非常に高く、-80 dBmまでの信号を測定可能です。スプリアスフリーダイナミックレンジ(SFDR)が> 50 dBと高く、x偏波とy偏波を別々に測定できます。Ethernet接続が可能です。

WaveAnalyzer 100Sは分解能1.75 GHzで、一般的な光スペクトラムアナライザよりも数十倍高分解能です。非常にコンパクト（108 mm x 163 mm x 26 mm）、軽量で安価な製品です。光通信の研究用途だけでなく、通信帯域をカバーする製品の検査測定器として最適です。ソフトウェアはWaveAnalyzer 1500Sと共通です。

### ブロックダイアグラム
1500Sと100Sは基本的に同じ構成です。WaveAnalyzer 1500Sでは、Coherent Receiverの前に1:99の分岐光ファイバカプラがあります。Normal Portは+23 dBmまで、High Sense Portは+3 dBmまで入力可能です。各ポートは99:1分岐光ファイバカプラの1%のポートと99%のポートに対応します。WaveAnalyzer 1500SではギガビットEthernetを用いて、Windows PCだけでなくLinux、Android OS、iOSで測定結果を表示できます。

### 使い勝手
WaveAnalyzer 100Sと1500Sにはディスプレイがありませんが、PCのディスプレイと直感的GUIにより、ストレスなく光スペクトルを測定できます。無料の専用ソフトウェアWaveAnalyzerを用いてOSNR、SMSR（サイドモード抑圧比）、FWHM、WDM解析、波長計解析など各種解析が可能です。LabVIEW、Matlab、C言語を用いての測定も可能で、必要なAPIやサンプルコードを配布しています。ウェブブラウザとHTTPコマンドを用いて任意の波長域を測定・記録することもできます。WaveAnalyzer 1500SとWi-FiルータをEthernetケーブルで繋げることで、複数のAndroid端末で同時に測定結果を確認できます。

光周波数コムのスペクトル測定、モード同期レーザのスペクトル測定をはじめとした先進的な光通信領域の研究用途に最適です。

## セブンシックスの技術サポート
導入前・導入後のご相談を承っております。
- 製品に精通した当社技術部エンジニアによる製品説明、デモ対応、実験サポート、トレーニングサービス
- WaveShaper・WaveAnalyzerのポテンシャルを最大限に引き出す当社オリジナル・ソフトウェアのサポート
- WaveShaper・WaveAnalyzerの修理対応（電源系、ファン、ファイバ端面等の交換・修理）

## 資料ダウンロード
- [カタログ：Waveanalyzerシリーズ](https://www.sevensix.co.jp/wp-content/uploads/20250314_Waveanalyzer_family.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ