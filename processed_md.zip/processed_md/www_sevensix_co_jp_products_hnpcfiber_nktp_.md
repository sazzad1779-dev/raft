# 高非線形フォトニック結晶ファイバ

**カテゴリ:** 光ファイバ素線 / 光ファイバパッチコード  
**中カテゴリ:** シングルクラッドファイバ  
**小カテゴリ:** PMファイバ  
**メーカー:** NKT Photonics A/S  
**品名:** 高非線形フォトニック結晶ファイバ  
**モデル:** (型番なし)  
**波長:** 0.8um帯 / 1um帯  

高非線形フォトニック結晶ファイバは、0.8 umおよび1 um用のレーザーを種光源とした白色スーパーコンティニュームレーザ生成用のファイバデバイスです。

## 白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバ

以下のモデルが利用可能です：

| モデル名         | 種光源の例                                   |
|------------------|---------------------------------------------|
| NL-PM-750        | Ti:Sapphireレーザ、780nmモードロックErファイバレーザ |
| SC-5.0-1040      | マイクロチップレーザ、1umモードロックYbファイバレーザ |
| SC-5.0-1040-PM   | マイクロチップレーザ、1umモードロックYbファイバレーザ |

### 特長
- 小さいモードフィールド径
- 高い非線形係数

## 白色スーパーコンティニュームレーザ生成用高非線形フォトニック結晶ファイバデバイス：FemtoWHITE シリーズ

以下のモデルが利用可能です：

| モデル名         | 種光源の例                                   |
|------------------|---------------------------------------------|
| FemtoWHITE 800   | 800nm帯のTi:Sapphireレーザ                   |
| FemtoWHITE CARS  | 800nm帯のTi:Sapphireレーザ、モードロックErファイバレーザ |

### 特長
- メンテナンスフリー
- お持ちのTi:Sapphireレーザの利用が可能
- 標準のホルダーとの互換性
- コンパクトデザイン
- 堅牢な構造

## 資料ダウンロード
- [データシート：NL-PM-750 / SC-5.0-1040 / SC-5.0-1040-PM](https://www.sevensix.co.jp/wp-content/uploads/Non-linear-fibers.pdf#view=Fit)
- [アプリケーションノート：白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/Supercontinuum-application-note.pdf#view=Fit)
- [アプリケーションノート：SC-5.0-1040を用いた白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/Supercontinuum-application-note-SC-5.0-1040.pdf#view=Fit)
- [データシート：FemtoWHITE 800 / FemtoWHITE CARS](https://www.sevensix.co.jp/wp-content/uploads/FemtoWhite.pdf#view=Fit)
- [アプリケーションノート：FemtoWHITE CARSを用いた白色スーパーコンティニュームレーザ生成について](https://www.sevensix.co.jp/wp-content/uploads/FemtoWHITE-CARS-application-note.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/hnpcfiber_nktp/)から。