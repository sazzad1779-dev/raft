# 1.5 um帯 10GHz/20GHz/40GHz 高消光比 強度変調器

## 概要
- **カテゴリ**: 光変調器
- **小カテゴリ**: 強度変調器
- **メーカー**: iXBlue SAS
- **波長**: 1530 ~ 1625nm
- **帯域幅**: 最大 40GHz
- **モデル**: (型番なし)

[製品の詳細はこちら](https://www.sevensix.co.jp/products/15ummodulator_erim_ixbue/)

## 特長
- 高消光比: 40 dB
- 広帯域
- X-cut で高安定
- 低い駆動電圧
- 低い挿入損

### 高ER特性
MXER-LN シリーズの LN 強度変調器は、非常に高い消光比 (ER: Extinction Ratio) を持つマッハツェンダ変調器です。この高ER特性は、Photoline Technologiesの特許技術である“Magic Junction”法に基づいています。導波路チップの製造方法には、Ti-In Defusion法とProton Exchange法があります。Proton Exchange法を採用することで、TEモードのみを同派し、ERが高くなります。

MXER-LN シリーズでは、ERを30 – 35 dB、35 – 40 dB、> 40 dBの3タイプから選択可能です。出荷時のER測定は通常1550 nmのレーザで行われます。

### iX Blueの信頼性
iXBlue Photonicsは、NASAなどの宇宙開発システムにも関与しており、品質、堅牢さ、高い安定性が求められます。LN変調器の納品時には、湿度、バキュームなど9つの指標のテストをパスしています。

## 用途
MXER-LN シリーズは、高消光比と広いバンド幅が求められる用途に最適です。具体的には、パルスレーザのアンプ前のパルスピッキングや、LIDARベースのセンシングシステムに有用です。

### モデルの選択肢
- バンド幅: 10 GHz、20 GHz
- フォトダイオード内蔵: Yes or No
- 入出力ファイバ: 偏波保持ファイバ、Standard SMファイバ
- 入出力コネクタ: 素線、FC/APC、FC/SPC コネクタ（ナローキー）
- 消光比: 30 – 35 dB、35 – 40 dB

## 使用方法 / RFデバイスの提供
LN強度変調器は、周囲の温度変化やエイジングによってドリフトするため、適切なDCバイアス電圧を与えるRFドライバが必要です。iXBlue Photlineは、バイアスコントローラからRFドライバまでエレクトロニクス全般を提供し、ユーザがスムーズに研究開発を行えるようサポートしています。

## 仕様詳細
| 対応波長(nm) | 1530 ～ 1625 |
|--------------|--------------|
| 耐光出力(mW) | 100          |
| 変調帯域(GHz) | 10 ～ 40    |
| 消光比(dB)   | 20 ～ 40    |
| 挿入損失(dB) | 0 ～ 4      |

## 資料ダウンロード
- [データシート：1.5 um帯 10GHz/20GHz/30GHz 高消光比 強度変調器](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A0-1.pdf#view=Fit)
- [データシート：RFドライバの紹介資料](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A1.pdf#view=Fit)
- [アプリケーションノート：低周波数駆動時](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A2.pdf#view=Fit)
- [紹介資料：バイアスコントローラの紹介資料](https://www.sevensix.co.jp/wp-content/uploads/10-GHz-20-GHz-LN-%E5%BC%B7%E5%BA%A6%E5%A4%89%E8%AA%BF%E5%99%A8MXER-LN%E3%82%B7%E3%83%AA%E3%83%BC%E3%82%BA%E3%80%80%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88%E2%91%A4.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ