# 超短パルスレーザー用光増幅モジュール『aeroGAIN-ROD』

## 製品概要
超短パルスレーザー用光増幅モジュール『aeroGAIN-ROD』は、NKT Photonics A/Sによって設計・製造された水冷ホルダ付きのYbファイバベースの増幅モジュールです。波長範囲は1030 ~ 1040nmで、出力は250Wです。このモジュールを使用することで、産業用の繰返し周波数MHz、パルスエネルギーが数百μJ、パルス幅がピコ秒からフェムト秒のレーザーを製造することが可能です。

## 特長
- non-PM、PM双方に対応
- 高出力対応かつ低線形性
- 優れた位置安定性
- 堅牢な産業向けの構造
- 熱管理が容易
- 市場で証明された信頼性

## 用途
- ピコ秒、ナノ秒パルスの増幅
OEMとしての寿命は、励起LD出力、励起波長、冷却効率に依存します。NKT Photonicsはシステム設計をサポートし、OEMを検討する企業には本社への訪問・トレーニングも提供しています。

## 仕様概要
以下の表は、aeroGAIN-RODの主要な仕様を示しています。

|     | aeroGAIN ROD 2.1 | aeroGAIN ROD 3.1 |
| --- | ----------------- | ----------------- |
| 動作波長 \[nm\] | 1030 ~ 1040 | 1030 ~ 1040 |
| ファイバコア径 \[µm\] | 85 | 85 |
| モードフィールド径, 1/e2 \[µm\] | 65 ± 10% | 65 ± 10% |
| インナークラッド径 \[µm\] | 260 ± 15 | 260 ± 15 |
| インナークラッドNA (FWHM @ 950 nm) | \> 0.5 | \> 0.5 |
| Yb添加ファイバ長 \[µm\] | 804 ± 3 | 804 ± 3 |
| クラッド吸収率 \[dB\] @ 915 nm | 5 ± 0.7 | 5.7 ± 0.7 |
| クラッド吸収率 \[dB\] @ 976 nm | 15 | 17 |
| 変換効率 \[%\] | \> 60 | \> 60 |
| シグナル光の平均出力 \[W\] | 100 | 250 |
| ビーム品質 | M2 < 1.3 | M2 < 1.3 |
| PER, typical \[dB\] | \> 15 | \> 15 |

aeroGAIN-ROD 2.1および3.1は、内部に使用されているRODファイバー長が80.4cmで、増幅後の超短パルスレーザーの出力はそれぞれ100Wおよび250Wです。ファイバ出力端にはARコートされた大口径エンドキャップが取り付けられており、モード径の拡大と後方反射の抑制に寄与しています。高いビーム位置安定性と低い非線形性を持つaeroGAIN-RODを使用することで、柔軟で多様な高出力超短パルスレーザーを構成できます。

## 資料ダウンロード
- [データシート：『aeroGAIN-ROD』](https://www.sevensix.co.jp/wp-content/uploads/aeroGAIN-ROD-Datasheet.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD 2.1』の増幅事例](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes-1.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD 3.1』の増幅事例](https://www.sevensix.co.jp/wp-content/uploads/175-W-average-power-from-a-single-core-rod-fiber-based-chirped-pulse-amplification-system.pdf#view=Fit)
- [参考資料：『aeroGAIN-ROD』へのシグナル光と励起光の入力方法](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes-2.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクからご確認ください。

# Source URL: https://www.sevensix.co.jp/products/aerogain-rod/