# テーパーアンプ

**カテゴリ:** 光増幅器  
**メーカー:** Toptica Eagleyard  
**モデル:** (型番なし)  
**波長:** 650 ~ 980nm  
**出力:** 0.25 ~ 3W  

テーパーアンプは、1つのエミッターで優れたビームと最高の出力を兼ね備えています。モノリシックデザインで、シングルモードのリッジ導波管部分をテーパー構造にしています。マスターオシレーターのパワーアンプのセットアップに最適です。全ての製品は、ISO 9001:2015で要求される厳格な品質基準に準拠しています。

## 特長
- 線幅が小さく、サイドモード抑制比（SMSR）が強いなど、種レーザーの良好なスペクトル特性を維持します。
- マスターオシレーターのパワーアンプのセットアップに最適で、シードソースの特性をすべて受け継いでいます。
- パッケージは、C-Mount / 14 Pin Butterfly Packageです。

## 用途
- 量子技術
- 分光法

## 仕様詳細
以下の表は、テーパーアンプの主要な仕様を示しています。各モデルの波長、出力、モード、パッケージタイプが記載されています。

| 製品名 | 波長 (nm) (typ) | 出力 (W) (推奨環境) | モード | パッケージ |
| --- | --- | --- | --- | --- |
| [EYP-TPA-0650-00250-2007-CMT02-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 650 | 0.25 | CW | C-Mount Package |
| [EYP-TPA-0765-01500-3006-CMT03-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 765 | 1.5 | CW | C-Mount Package |
| [EYP-TPA-0765-01500-3006-BTU02-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 765 | 1.5 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0780-01000-3006-CMT03-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 780 | 1.0 | CW | C-Mount Package |
| [EYP-TPA-0780-03000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 780 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0780-03000-4006-BTU02-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 780 | 3.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0795-02000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 795 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0795-02000-4006-BTU02-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 795 | 2.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0808-02000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 808 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0830-01000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 830 | 1.0 | CW | C-Mount Package |
| [EYP-TPA-0845-02000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 845 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0850-00500-3006-CMT03-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 850 | 0.5 | CW | C-Mount Package |
| [EYP-TPA-0850-02000-4006-BTU02-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 850 | 2.0 | CW | 14 Pin Butterfly Package |
| [EYP-TPA-0850-02000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 852 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0870-00500-3006-CMT03-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 880 | 0.5 | CW | C-Mount Package |
| [EYP-TPA-0960-02000-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 960 | 2.0 | CW | C-Mount Package |
| [EYP-TPA-0970-02500-4006-CMT04-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 970 | 3.0 | CW | C-Mount Package |
| [EYP-TPA-0980-00500-3006-CMT03-0000](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/) | 980 | 0.5 | CW | C-Mount Package |

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/taperamplifier_eagleyard/)から。