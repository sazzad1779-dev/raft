# 量子用超低損失 マトリックス光スイッチ

**カテゴリ:** 光スイッチ  
**メーカー:** HUBER+SUHNER Polatis  
**モデル:** 型番なし  
**波長:** 1260 ~ 1675nm  
**ポート数:** 16x16  

POLATIS Series 6000 Ultra Q 光スイッチは、16入力×16出力ポートを持つコンパクトかつ高性能なノンブロッキング型の光マトリクススイッチです。量子通信やQKDネットワーク向けに超低損失コネクタ（< 0.35 dB）を採用し、スイッチ内の光路の位相整合（±0.5 ns）を実現しています。

## 特長
- 1260～1675nm ノンブロッキング16×16光スイッチ
- 量子用途に最適な超低損失（typ < 0.35 dB）QuPC（LC/APC）光コネクタ採用
- スイッチ内の光路の位相整合：±0.5 ns以内
- ダークファイバー接続のスイッチングおよび保持が可能
- 双方向（Bidirectional）の光接続
- API対応（NETCONF, RESTCONF, TL2他）

## 用途
- 量子通信
- 量子鍵配送（QKD）ネットワーク

## 仕様
以下の表は、量子用超低損失マトリックス光スイッチの主要な仕様を示しています。

| パラメータ                             | 数値                     |
|--------------------------------------|------------------------|
| Switch Size (Ports)                 | 16 input x 16 output    |
| Typical Insertion Loss               | 0.35 dB                |
| Maximum Insertion Loss               | 0.70 dB                |
| Loss Repeatability                   | +/-0.1dB               |
| Connection Stability                  | +/-0.1dB               |
| Dark Fiber Switching                  | Yes                    |
| Bi-Direction Optics                  | Yes                    |
| Data latency through a switch connection | 25 +/- 0.5 ns         |
| Maximum Switching Time                | 25ms                   |
| Polarization Dependent Loss (PDL)    | <0.1dB (C+L Bands)     |
| Crosstalk                            | <-50dB                 |
| Operating Wavelength Range           | 1260-1675nm            |
| Wavelength Dependent Loss (WDL)      | <0.3dB (C+L Band)      |
| Return Loss (with APC connectors)    | >50dB                  |
| Optical Input Power Range            | Dark to +24 dBm        |
| Switch Lifetime                       | >10^9 Cycles           |

## 資料ダウンロード
- [データシート：Polatis\_Quantum\_Switch](https://www.sevensix.co.jp/wp-content/uploads/POLATIS_Series-6000_Ultra_Q_Quantum_Switch_Data_Sheet.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/quantum_switch_polatis/)から。