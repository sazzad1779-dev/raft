# 製品概要
NKT Photonics社のORIGAMI XPおよびORIGAMI XP-Sシリーズは、超高安定で低位相雑音のOrigamiフェムト秒シードレーザーをシンプルでコンパクトなチャープパルス増幅器で増幅した構成です。レーザーヘッド、コントローラ、冷却装置はワンボックスのコンパクトサイズ（292 mm x 176 mm x 508 mm）に全て搭載され、最大70 uJのパルスエネルギーを空冷タイプで提供します。パルス幅400 fsにおける最大平均出力は5 W、最大パルスエネルギーは70 uJです。繰返し周波数はsingle-shotから1 MHzまで対応し、オプションとして1030 nm、515 nm、343 nmの最大3波長出力が可能です。

## 特長
- ワンボックス搭載の超コンパクトサイズ
- +24 Ddc入力が必要なだけの容易な操作性
- Single shot – 1MHz, Pulse-on demand
- SHG結晶、THG結晶を用いた最大3波長出力が可能
- 堅牢な産業向けの構造
- 全ての設置方向に柔軟に対応
- リアルタイムのパルスエネルギーの測定・診断・制御
- 高信頼性
- 高いビームポインティングスタビリティ: < 30 urad rms (12 h)
- 水冷オプションあり

## 用途
- 眼科用途
- 医療機器の製造
- フェムト秒微細加工
- 薄膜パターニング
- サファイア・ガラス・ポリイミドの切断と穴あけ
- セラミックの穴あけとスクライビング
- 多光子顕微鏡
- FPDピクセルの修復
- ホイル切断
- LCDパターニング
- OLEDディスプレイの修理
- PCB加工
- 光パラメトリック増幅器の励起光

## 仕様詳細
以下の表は、ORIGAMIシリーズの各モデルの主要な仕様を示しています。

| モデル名          | 波長          | 平均出力 | パルスエネルギー | 繰返し周波数 |
|-------------------|---------------|----------|------------------|---------------|
| ORIGAMI 03XP      | 343 nm / 515 nm / 1030 nm | 1.5 W / 2.5 W / 5 W | 20 uJ / 35 uJ / 70 uJ | single-shot - 1 MHz |
| ORIGAMI 10XP      | -             | -        | -                | -             |
| ORIGAMI 5XP       | -             | -        | -                | -             |
| ORIGAMI 03XP-3P   | IR / Green / UV | -        | -                | -             |

## アプリケーションノート
- [Precision polymer cutting with femtosecond UV laser](#)
- [Micromachining of thermally sensitive PET film](#)
- [Femtosecond lasers ensure higher quality polyimide micromachining](#)
- [Laser micromachining of thin PMMA film](#)
- [Laser micromachining of thin glass](#)
- [Laser micromachining of Nitinol stents](#)
- [Laser micromachining of glass for biomedical applications](#)
- [Laser cutting of polymer tubes for biomedical applications](#)
- [Integration of an ORIGAMI XP with galvanometer scanners](#)
- [Laser marking of polymer tubes for biomedical applications](#)
- [Sub-surface marking of glass](#)
- [Unique device identification black marking for the medical industry](#)

## 資料ダウンロード
- [データシート：ORIGAMI XP-S (1030 nmのみ と 1030 & 515 nm)](https://www.sevensix.co.jp/wp-content/uploads/onefive-origami-10xp.pdf#view=Fit)
- [データシート：ORIGAMI XP-S (1030 & 343 nm)](https://www.sevensix.co.jp/wp-content/uploads/OneFive_ORIGAMI_03XP-2P.pdf#view=Fit)
- [データシート：ORIGAMI XP-S (1030 & 515 & 343 nm)](https://www.sevensix.co.jp/wp-content/uploads/OneFive_ORIGAMI_03XP-3P.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/origamixp_nktp/