# 薄膜LN 65GHz光強度変調器

**カテゴリ:** 光変調器  
**メーカー:** HyperLight  
**モデル:** 型番なし  
**波長:** C-band / O-band  

HyperLight社の薄膜LN 65GHz光強度変調器は、従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現しています。C-bandとO-bandの2波長に対応し、Low VπモデルとRegular Vπモデルの2タイプが用意されています。

## 特長
- 75 GHz以上の帯域幅
- Low VπモデルおよびRegular Vπモデルのサポート
- 高い消光比
- C/L-bandおよびO-bandのサポート
- コンパクトなフットプリント、安定したDCバイアス
- 1.85mm RFコネクタ(V)、PMファイバー

## 用途
- 200G bps/lane テスト
- 150 Gbaud テスト

## 資料ダウンロード
- [カタログ：薄膜LN 65GHz光強度変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-65GHz-Intensity-Modulator.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/65ghz_intensity_modulator_hyperlight/