# 製品概要
- **品名**: 広帯域シングルモードアイソレータ
- **モデル**: (型番なし)
- **カテゴリ**: 光ファイバ部品
- **中カテゴリ**: 光ファイバアイソレータ
- **小カテゴリ**: SMアイソレータ
- **メーカー**: Optizone Technology Limited
- **波長**: 850 ~ 1064nm
- **入力パワー**: 300mW ~ 5W

Optizone Technology Limitedの広帯域シングルモードアイソレータは、中国の深センに拠点を構え、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高アイソレーション

## 用途
- 光ファイバ増幅器
- ファイバレーザ

## 仕様詳細
この仕様表は、広帯域シングルモードアイソレータの主要な性能パラメータを示しています。波長は850nmおよび1064nmに対応し、入力パワーは300mWから5Wまでの範囲で選択可能です。コネクタタイプはFC/UPC、FC/APC、SC/UPC、SC/APC、Noneなどがあり、ファイバ被膜は250umベアファイバ、900umルーズチューブなどに対応しています。ファイバ長は標準1mで、その他の仕様も対応可能です。

| 項目         | 内容                                   |
|--------------|----------------------------------------|
| 波長         | 850nm、1064nm、その他も対応可        |
| 入力パワー   | 300mW、500mW、1W、5W、その他も対応可 |
| コネクタタイプ| FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                |

## パッケージタイプ
- Type C40
- Type C8

## 資料ダウンロード
- [データシート：850nm Broadband Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-022C-BI-850nm.pdf#view=Fit)
- [データシート：1064nm Broadband Polarization Insensitive Isolator](https://www.sevensix.co.jp/wp-content/uploads/BI-HPMBI-1064nm-Type-C8-1W20WCAT-05-020C.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。

# Source URL: https://www.sevensix.co.jp/products/wsm_isolator_optizone/