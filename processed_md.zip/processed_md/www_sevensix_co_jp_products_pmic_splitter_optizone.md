# 偏波保持アイソレータコンバイナ / スプリッタ

## 概要
- **カテゴリ**: 光ファイバ部品
- **中カテゴリ**: 光ファイバアイソレータ
- **小カテゴリ**: PMアイソレータ
- **メーカー**: Optizone Technology Limited
- **モデル**: (型番なし)
- **波長**: 1064 ~ 1550nm

Optizone Technology Limitedの偏波保持アイソレータコンバイナ/スプリッタは、中国の深センに拠点を構えています。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、高品質・高安定性を兼ね備えています。年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高消光比
- ハイリターンロス

## 用途
- ファイバーレーザ

## 仕様詳細
以下の表は、偏波保持アイソレータコンバイナ/スプリッタの主要な仕様を示しています。

| 項目               | 詳細内容                                           |
|--------------------|---------------------------------------------------|
| 波長               | 1064nm、1310nm、1480nm、1550nm、その他も対応可   |
| コネクタタイプ     | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜       | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバタイプ on Port3 | HI 1060 Fiber、Slow Axis align 45°to Port1、Slow Axis align to Port1、その他も対応可 |
| ファイバ長         | 標準1m、その他も対応可                           |

## 資料ダウンロード
- [データシート：1064nm Isolator Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-004C-IPBCS-1064nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm Isolator Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-005BC-IPBCS-1310nm1550nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm High Power Isolator Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-051B-HIPBCS-1310nm1550nm-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。

# Source URL: https://www.sevensix.co.jp/products/pmic_splitter_optizone/