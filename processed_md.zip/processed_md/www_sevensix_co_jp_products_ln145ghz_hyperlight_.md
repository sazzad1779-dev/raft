# 薄膜LN 145GHz光強度変調器

**カテゴリ:** 光変調器  
**メーカー:** HyperLight  
**モデル:** 型番なし  
**波長:** C-band, O-band  

この薄膜LN 145GHz光強度変調器は、従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現しています。HyperLight社の145GHz強度変調器は、Low VπモデルとRegular Vπモデルの2タイプがあり、260 Gbaudおよび140 Gbaudのテストに対応しています。

## 特長
- **帯域幅:** 145 GHz
- **コネクタ:** 0.8mm
- **消光比:** 高い
- **安定したDCバイアス:** 可能
- **光およびRFパワー処理能力:** 高い
- **対応波長:** C-band, O-band

## 用途
- 260 Gbaudテスト
- 140 Gbaudテスト
- 70 GHz単側波帯変調

## 資料ダウンロード
- [カタログ：薄膜LN 145GHz光強度変調器](https://www.sevensix.co.jp/wp-content/uploads/145GHz-IM.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/ln145ghz_hyperlight/)から。