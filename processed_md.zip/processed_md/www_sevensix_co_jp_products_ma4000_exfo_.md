# 光トランシーバテスター『MA-4000』概要
光トランシーバテスター『MA-4000』は、EXFOが製造した400G / 100G対応のビットエラーレートテスト(BERT)専用テスターです。このオールインワン型デバイスは、BERT、MCB、電源機能を一台で兼ね備えています。

# 特長
- 8チャンネル、10～28 GBd、PAM4/NRZサポート
- MCB付け替え方式により、QSFP-DD、OSFP、QSFP28、SFP28、SFP-DDをサポート
- 将来的な次世代規格にもMCB付け替えで柔軟に対応可能
- 煩雑でかさばるRFケーブル不要（基板同士の直接コンタクト）
- バーストエラー分析を強力にサポートするFECシミュレーション機能
- 3.13～3.465Vの内蔵電源による電圧テスト機能

# 用途
- 光トランシーバのループバックBERT
- OSA評価
- レイヤ1伝送試験

# 仕様詳細
## MCB付け替え方式の特徴とメリット
- 専用のMCBの付け替えで各種の光トランシーバテストに対応
- QSFP-DD、OSFP、QSFP28、SFP28、SFP-DDに対応
- 将来的な次世代規格にもMCB付け替えで柔軟に対応
- 接続作業が煩雑でかさばるRFケーブル不要（基板同士の直接コンタクト）
- コネクタ挿抜の耐久回数を超えた際にも簡易に交換可能
- 温度サイクル時間が5分の1（外付けMCB対比）

# 資料ダウンロード
- [スペックシート：光トランシーバテスター『MA-4000』](https://www.sevensix.co.jp/wp-content/uploads/exfo_spec-sheet_ma-4000_v5_en.pdf#view=Fit)
- [パンフレット：光トランシーバテスト製品ラインナップ - 最大800G伝送速度](https://www.sevensix.co.jp/wp-content/uploads/c0e90febf49b7bdbef1693a146c5fa68.pdf#view=Fit)

# Source URL
[光トランシーバテスター『MA-4000』](https://www.sevensix.co.jp/products/ma4000_exfo/)