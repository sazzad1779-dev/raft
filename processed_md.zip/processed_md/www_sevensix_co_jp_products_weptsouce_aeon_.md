大カテゴリ: 光増幅器/ 光変調器/ PD/ 光フィルタ他  
中カテゴリ: 光増幅器  
小カテゴリ: SOA  
メーカ: Aeon Corporation  
品名: Swept Source向け半導体光アンプ  

モデル:  
- モデル: (型番なし)  

# Source URL: [https://www.sevensix.co.jp/products/weptsouce_aeon/](https://www.sevensix.co.jp/products/weptsouce_aeon/)  

## Swept Source向け半導体光アンプ  
波長: 1450 ~ 1600nm　ゲイン: 19dB  
_メーカ：_ Aeon Corporation  

医療用・産業OCTの光源として利用されているSwept Source用の光半導体アンプ（SOA）です。各波長領域毎に広帯域な光半導体アンプをご用意しております。  
- X-band：40nm  
- O-band：100nm  
- C-band：150nm  

シグナル光の増幅用途やバランスドディテクタの受信直前でのご利用が期待できます。  

### 特長  
- 広帯域動作  
- 低偏波依存性  
- 14ピンMSAパッケージ  
- 医療画像  
- ASEソース  
- 光ファイバーセンシング  
- 掃引光源用ゲインメディア  

### 用途  
- バイオ/医療/イメージング  

### 仕様詳細  
以下の表は、Swept Source向け半導体光アンプの主要な仕様を示しています。各パラメータの最小値、中央値、最大値が記載されています。

| パラメータ                     | 最小値 | 中央値 | 最大値 | 単位 | 備考                          |
|------------------------------|------|------|------|----|-----------------------------|
| 動作波長(λ)                  | 1040 |      | 1080 | nm |                             |
|                              | 1250 |      | 1350 | nm |                             |
|                              | 1450 |      | 1600 | nm |                             |
| ピークゲイン(Gpk)            | 19   |      |      | dB |                             |
| ゲインリップル(GR)           |      |      | 2    | dB |                             |
| 偏光依存のゲイン(PDG)         |      |      |      | dB | Gain peak + 10 nm          |
| 飽和出力電力(P SAT)          | 7    |      |      | dBm| 3.0dBのゲインコンプレッション |
| 順電圧(Vf)                   |      | 2    |      | V  |                             |
| 動作バイアス電流(Iop)        |      | 300  |      | mA |                             |
| サーミスタ抵抗(R therm)       |      | 10   |      | kΩ | At 25˚C                    |
| 総消費電力(P)                |      |      | 4    | W  | Tcase = 70˚C, By design    |

## 資料ダウンロード  
- [Swept Source向け光半導体アンプ　カタログ](https://www.sevensix.co.jp/wp-content/uploads/SAX20r-SAO20r-and-SAC20r.pdf#view=Fit)  

## 製品に関するお問い合わせ  
この製品のお問い合わせ