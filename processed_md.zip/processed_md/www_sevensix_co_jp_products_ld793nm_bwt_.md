# ファイバ付 高出力 半導体マルチモードレーザー 793nm

## 概要
- **カテゴリ**: 半導体レーザーダイオード（LD）
- **中カテゴリ**: ファブリペローレーザー
- **小カテゴリ**: MMファイバ
- **メーカー**: BWT Beijing LTD.
- **モデル**: 型番なし
- **波長**: 793nm
- **出力**: 4 ~ 180W

このレーザーは、TmファイバレーザやTDFA（Tm Doped Fiber Amplifier）の励起用光源として使用可能で、コンパクトで高輝度、高出力を特徴としています。また、1900-2100nmのフィードバック保護機能が付いています。

## 特長
- 2 µmで発振するツリウムファイバレーザおよびその増幅器（TDFA）に使用可能
- 広いパワーレンジ

## 用途
- ファイバーレーザーの励起
- 固体レーザーの励起

## 仕様詳細
以下の表は、異なる出力のファイバ付高出力半導体マルチモードレーザーの仕様を示しています。各モデルは、波長793nm、コア径、開口数、用途に関する情報を提供しています。

| 製品名 | 型番 | 波長(nm) | 出力(W) | コア径(µm) | 開口数(NA) | 用途 |
| --- | --- | --- | --- | --- | --- | --- |
| 793nm 4W Fiber Coupled Diode Laser | [K793DB2RN-4.000WN0N-10522F10EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 4 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 8W Fiber Coupled Diode Laser | [K793DA2RN-8.000WN0N-10522F10EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 8 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 22W Fiber Coupled Diode Laser | [K793DAHRN-22.00W](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 22 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 30W Fiber Coupled Diode Laser | [K793DA5RN-30.00WN0N-10522F10EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 30 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 50W Fiber Coupled Diode Laser | [K793DA5RN-50.00WN0N-10522F20EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 50 | 105 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 90W Fiber Coupled Diode Laser | [K793DN1RN-90.00WN0N-10522F20EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 90 | 106.5 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 100W Fiber Coupled Diode Laser | [K793DN1RN-100.00WN0N-10522F20EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 100 | 106.5 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 140W Fiber Coupled Diode Laser | [K793DN1RN-140.0WN0N-20022F20EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 140 | 200 | 0.22 | ファイバーレーザー増幅、科学研究 |
| 793nm 180W Fiber Coupled Diode Laser | [K793DN2RN-180.0WN0N-20022F20EFF](https://www.sevensix.co.jp/products/ld793nm_bwt/) | 793 | 180 | 200 | 0.22 | ファイバーレーザー増幅 |

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/ld793nm_bwt/)から。