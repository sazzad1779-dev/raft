# ピエゾアクチュエータ式マトリックス光スイッチ

## 概要
- **カテゴリ**: 光スイッチ
- **メーカー**: HUBER+SUHNER Polatis
- **モデル**: 型番なし
- **波長**: 1260 ~ 1675nm
- **ポート数**: 最大 576x576

ピエゾアクチュエータを採用したこの光スイッチは、ビームを直接出射側ファイバへ結合することで、損失を最小限に抑え、振動にも強い構造を実現しています。8x8から576x576までの様々なポート構成に対応し、ユーザー側で自由にポート構成の組み換えが可能なsingle-sided NxCC構成にも対応しています。

## 特長
- 8×8 ～ 最大576×576のNon-blockingマトリックス光スイッチ
- ユーザー側で自由自在にポート構成の組み換えが可能なsingle-sided NxCCに対応
- 低挿入損失
- オプションで光パワーモニタリング、VOA、シャッター機能に対応
- NETCONF及びRESTCONFコントロールI/F対応

## 用途
- ソフトウェアデファインドネットワーキング (Software-defined networking)
- データセンターアグリゲーション (Data center aggregation)
- 自動アクセス、メトロおよび長距離ネットワーク運用 (Automated access, metro and long-haul network operations)
- 機器の一元共有とネットワークテストの自動化 (Centralized equipment sharing and automated network testing)
- コロケーションピアリングとデマケーション (Colocation peering and demarcation)
- ハイパフォーマンスコンピューティング (High performance computing)
- UHDビデオ配信 (UHD Video distribution)
- 自動システム検証試験 (Automated systems verification testing)
- 高速な自動プロビジョニングと保護切り替え (Fast automatic provisioning and protection switching)
- ネットワーク監視と自動障害位置特定 (Network monitoring and automatic fault location)

## 製品ラインナップ
### スイッチ構成例

## 資料ダウンロード
- [データシート：Polatis\_576\_Prelim](https://www.sevensix.co.jp/wp-content/uploads/POLATIS_576_Data_Sheet_Prelim.pdf#view=Fit)
- [データシート：Polatis\_6000i\_Instrument](https://www.sevensix.co.jp/wp-content/uploads/Polatis_6000i_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_6000n\_Network](https://www.sevensix.co.jp/wp-content/uploads/Polatis_6000n_Network_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_7000i\_Instrument](https://www.sevensix.co.jp/wp-content/uploads/Polatis_7000i_Data_Sheet.pdf#view=Fit)
- [データシート：Polatis\_7000n\_Network](https://www.sevensix.co.jp/wp-content/uploads/Polatis_7000n_Data_Sheet-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ

# Source URL: https://www.sevensix.co.jp/products/opticalswitch_polatis/