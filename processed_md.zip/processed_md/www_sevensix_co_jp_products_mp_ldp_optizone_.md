# マルチモードポンプLDプロテクタ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** その他光ファイバ部品  
**小カテゴリ:** ポンプLDプロテクタ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 915 / 980nm  
**入力パワー:** 6W / 10W  

Optizone Technology LimitedのマルチモードポンプLDプロテクタは、中国の深センに拠点を構え、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- レーザ保護

## 用途
- ファイバレーザ

## 仕様詳細
以下の表は、マルチモードポンプLDプロテクタの主要な仕様を示しています。

| 項目           | 詳細内容                          |
|----------------|-----------------------------------|
| 波長           | 915nm、980nm、その他も対応可     |
| 入力パワー     | 6W、10W、その他も対応可          |
| NA             | 0.15、0.22、その他も対応可       |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜   | 250umベアファイバ、900umルーズチューブ、3mmケーブル、その他も対応可 |
| ファイバ長     | 標準1m、その他も対応可            |

## 資料ダウンロード
- [データシート：915nm、980nm Multimode Pump Laser Protector](https://www.sevensix.co.jp/wp-content/uploads/CAT-08-004C.pdf#view=Fit)
- [データシート：915nm、980nm Multimode Pump Laser Protector for EDFA](https://www.sevensix.co.jp/wp-content/uploads/MMPLPE-915nm980nm-15001620nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[製品URL](https://www.sevensix.co.jp/products/mp_ldp_optizone/)