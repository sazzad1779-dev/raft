# 薄膜LN 65GHz IQ光変調器

**カテゴリ:** 光変調器  
**メーカー:** HyperLight  
**モデル:** 型番なし  
**波長帯:** C / L / O-band  
**リリース予定:** 2025年中  

薄膜LN方式の光変調器で、従来のLN変調器に比べて大幅に広帯域化、低消費電力化、小型化を実現しています。

## 特長
- Single-polarization IQ modulator
- > 70 GHz bandwidth
- Supports 140 Gbaud signaling
- Two 1.85mm RF connector (V)
- IQ bias controller available
- C/L-band, O-band support
- Cryogenic-compatible version available

## 用途
- 140 Gbaud testing
- 70 GHz single sideband modulation

## 資料ダウンロード
- [カタログ：薄膜LN 65GHz IQ光変調器](https://www.sevensix.co.jp/wp-content/uploads/TFLN-65GHz-IQ-modulator.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/65ghz-iq_modulator_hyperlight/