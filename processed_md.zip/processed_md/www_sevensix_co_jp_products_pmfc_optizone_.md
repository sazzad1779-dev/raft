# 偏波保持フィルタカプラ

## 製品概要
- **品名**: 偏波保持フィルタカプラ
- **モデル**: (型番なし)
- **カテゴリ**: 光ファイバ部品
- **中カテゴリ**: 光ファイバカプラ
- **小カテゴリ**: フィルタカプラ（Tapカプラ含む）
- **メーカー**: Optizone Technology Limited
- **波長範囲**: 1064 ~ 2000nm
- **ポート数**: 1×2 / 2×2

Optizone Technology Limitedの偏波保持フィルタカプラは、中国の深センに拠点を置き、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間20,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9,000㎡の工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 高い消光比
- 低挿入損失
- 高リターンロス

## 用途
- ファイバーレーザ
- EDFA、ラマン分光
- センサー

## 仕様詳細
以下の表は、偏波保持フィルタカプラの主要な仕様を示しています。

| 項目               | 詳細内容                                   |
|--------------------|--------------------------------------------|
| 波長               | 1064nm、1310nm、1550nm、2000nm、その他も対応可 |
| ポート数           | 1×2、2×2                                  |
| ハンドリングパワー | 0.5W、1W                                   |
| コネクタタイプ     | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他組も対応可 |
| ファイバ被膜       | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長         | 標準0.8m、1m、その他も対応可              |

ハイパワー対応の製品も取り扱っています。

## 資料ダウンロード
以下のリンクからデータシートをダウンロードできます。
- [1064nm 1×2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-018D-PMFC-1030-1064nm-1x2-1.pdf#view=Fit)
- [1064nm 2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-017C-PMFC-1030-1064nm-2x2-1.pdf#view=Fit)
- [1310nm、1550nm 1×2、2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-019C-PMFC-1310nm1550nm-1x2-2x2-1.pdf#view=Fit)
- [2000nm 1×2、2x2 Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-10-015C-PMFC-2000nm-1x2-2x2-1.pdf#view=Fit)
- [1064nm 1×2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-045D-HPMFC-1030-1064nm-1x2-1.pdf#view=Fit)
- [1064nm 2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/SR2101011B-HPMFC-06-2-50-F-0.5-NNNN-BBBB-0.8-04A-01.pdf#view=Fit)
- [1310nm、1550nm 1×2、2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-046C-HPMFC-1310nm1550nm-1x2-2x2-1.pdf#view=Fit)
- [2000nm 1×2、2x2 High Power Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-059B-HPMFC-2000nm-1x2-2x2-1.pdf#view=Fit)
- [1310nm、1550nm 1×2、2x2 Mini Polarization Maintaining Filter Coupler](https://www.sevensix.co.jp/wp-content/uploads/MPMFC-1310nm-1550nmCAT-09-037B.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。

[Source URL](https://www.sevensix.co.jp/products/pmfc_optizone/)