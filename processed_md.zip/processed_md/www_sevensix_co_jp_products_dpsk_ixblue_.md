# 1.5um帯 12.5 / 28Gbps DPSK変調器ボックス

**カテゴリ:** 光変調器  
**メーカー:** iXBlue SAS  
**波長:** 1530 ~ 1565nm (Cバンド)  
**伝送レート:** 12.5 / 28 Gbps DPSK  
**モデル:** (型番なし)  

このDPSK変調器ボックスは、12.5 / 28 Gbpsの伝送レートに対応しており、オプションでDFBレーザやチューナブルレーザ、PDを内蔵可能です。

## 特長
- フルCバンドリファレンストランスミッター
- 最大10GHzまでのアナログ変調
- 信頼性・再現性の高い測定
- 高いアイダイアグラム安定性

## 用途
- 伝送系試験
- 部品特性評価
- 生産試験
- R&Dラボラトリー

## 仕様詳細

### ModBox-CBand-12.5Gb/s-DPSK 特性ハイライト
- 伝送レート: 12.5 Gbps
- 波長範囲: 1530 ~ 1565nm (Cバンド)

### ModBox-CBand-28Gb/s-DPSK 特性ハイライト
- 伝送レート: 28 Gbps
- 波長範囲: 1530 ~ 1565nm (Cバンド)

## 資料ダウンロード
- [データシート：ModBox-CBand-12.5Gbs-DPSK](https://www.sevensix.co.jp/wp-content/uploads/ModBox-CBand-12.5Gbs-DPSK-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88.pdf#view=Fit)
- [データシート：ModBox-CBand-28Gbs-DPSK](https://www.sevensix.co.jp/wp-content/uploads/ModBox-CBand-28Gbs-DPSK-%E3%83%87%E3%83%BC%E3%82%BF%E3%82%B7%E3%83%BC%E3%83%88-1.pdf#view=Fit)

# Source URL: https://www.sevensix.co.jp/products/dpsk_ixblue/