# 偏波保持タップアイソレータ

## 概要
- **品名**: 偏波保持タップアイソレータ
- **モデル**: (型番なし)
- **メーカー**: Optizone Technology Limited
- **カテゴリ**: 光ファイバ部品 > 光ファイバアイソレータ > PMアイソレータ
- **波長範囲**: 1064 ~ 1590nm

Optizone Technology Limitedは、中国の深センに拠点を構え、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。特に高出力用受動部品に強みを持ち、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 低偏波依存性損失

## 用途
- ファイバレーザ
- アンプ

## 仕様詳細
以下の表は、偏波保持タップアイソレータの主要な仕様を示しています。

| 項目               | 詳細内容                                      |
|--------------------|-----------------------------------------------|
| **波長**           | 1064nm、1310nm、1480nm、1550nm、1590nm       |
| **ステージ**       | シングル、デュアル                            |
| **コネクタタイプ** | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| **光軸アライメント** | Fast Axis Blocked、Both Axis Working        |
| **ファイバ被膜**   | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| **ファイバタイプ on Tap** | SMF 28e Fiber、PM Panda Fiber            |
| **ファイバ長**     | 標準1m、その他も対応可                       |

## パッケージタイプ
- 小型タイプ
- 標準タイプ

## 資料ダウンロード
- [データシート：1310nm、1480nm、1550nm、1590nm Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-030C-PMTAPI-13101590nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm、1590nm High Power Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-054C-HPMTAPI-1310nm1590nm.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm、1590nm Mini Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-040B-MPMTAPI-1530-to-1570nm.pdf#view=Fit)
- [データシート：1064nm Polarization Maintaining Tap Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-11-008B-PMTAPI-1064nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、[こちら](https://www.sevensix.co.jp/products/pmt_isolator_optizone/)から。