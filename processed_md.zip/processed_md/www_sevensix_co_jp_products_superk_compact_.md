大カテゴリ: ファイバーレーザー・その他光源  
中カテゴリ: 広帯域白色レーザー光源  
メーカ: NKT Photonics A/S  
品名: 広帯域 白色レーザー光源 入門モデル『SuperK COMPACT』  
モデル: SuperK COMPACT  

# Source URL: https://www.sevensix.co.jp/products/superk-compact/

## 製品概要
SuperK COMPACT は 450 – 2400 nm という広帯域スペクトルを出力する小型・低価格な Supercontinuum レーザーです。シングルモードファイバ (SMF) から射出される Supercontinuum レーザーは輝度が高く、ハロゲンランプ、キセノンランプと比べて 10 倍以上も長寿命です。出力方式は高性能コリメータもしくは FCコネクタ (FC/PC or FC/APC) から選択可能です。SuperK COMPACT は、材料評価、光部品試験、分光、光コヒーレンストモグラフィなど、広帯域光源を必要とする多くの研究・測定システムに採用されています。

## 特長
- 低価格な広帯域レーザー光源
- 高輝度かつ長寿命
- 入力パルストリガ対応
- 繰返し周波数可変: 1 Hz ~ > 20 kHz
- 豊富なフィルタアクセサリ
- アライメントフリー、メンテナンスフリー
- SMF 出力、コリメート時 M2 < 1.1
- 無偏光 (Un-polarized)
- 24/7 オペレーション
- 小型・軽量: 220.5 (W) x 93 (H) x 367 (L) mm、3.8 kg

### SuperK COMPACT : Supercontinuum レーザーの特長
Supercontinuum 光源の用途のほとんどは、広いスペクトルの中から限られた領域を選択的に抜きだして使います。NKT Photonics は必要なフィルタリング機能を提供する Plug ＆ Play の SuperK アクセサリを提供しています。SuperK COMPACT の Supercontinuum レーザーのフィルタリングにお勧めの SuperK アクセサリは、SuperK SPLIT と SuperK VARIA です。

### 全波長スペクトル
SuperK COMPACT のスペクトルは 450 – 2400 nm に連続的に広がっています。450 – 850 nm 領域での平均出力は 20 mW、トータル (450 – 2400 nm) の出力は > 110 mW です。SuperK COMPACT のパルス幅は < 2 ns、繰返し周波数は 1 Hz- 約 20 kHz の間で可変です。

### 外部入力
SuperK COMPACT は繰返し周波数可変のパルスレーザーです。外部トリガ入力ポートがあり、低ジッタにパルス出力を最大 20 kHz まで対応します。

## 仕様詳細

### 光学仕様
| 項目 | 内容 |
| --- | --- |
| スペクトル範囲 | 450 ~ 2400 nm |
| 全出力パワー | > 110 mW |
| 可視光パワー (350-850 nm) | > 20 mW |
| 出力パワー安定性 | < ± 1.0 % (± 0.5 % on request) |
| ウォームアップ時間 (パワー安定性) | ~30分 (代表値, 室温) |
| 繰返し周波数 | 1 Hz ~ > 20 kHz |
| 出力パルス幅 | < 2 ns |
| パルス間ジッタ | < 2 μs (パルス繰り返し周波数により異なる) |
| 出力ファイバ | シングルモード |
| 出力端 | コリメータ、FCコネクタ (FC/PC or FC/APC) |
| ビーム径 (コリメータビーム) | 1 mm @ 532 nm<br>2 mm @ 1100 nm<br>3 mm @ 2000 nm |
| M2 | < 1.1 |
| 偏光 | 無偏光 |
| ビーム出力 | ガウシアン、シングルモード |

### 機械 / 電気 / 環境 仕様
| 項目 | 内容 |
| --- | --- |
| 冷却方法 | 13 |
| 稼働電圧 | 100-240 VAC, 50-60 Hz |
| 消費電力 | < 40 W |
| コンピュータインターフェース | USB |
| パルスシグナル出力 | アナログ / デジタル |
| トリガ入力 | スタンダード / インダストリアル (直流的に絶縁) |
| ドアインターロックコネクタ | 2-pin LEMO 0B |
| 外部busコネクタ | 15-pin D-sub |
| 寸法（WxHxL） | 220.5 x 93 x 367 mm |
| 重量 | 3.8 kg |
| 使用温度 | 15 ~ 30 °C |
| 保管温度 | 5 ~ 50 °C (結露無し) |
| 湿度 | 20-80 % RH |

## 用途
- デバイス評価
- バイオ/医療/イメージング
- フローサイトメトリー
- 分光
- 産業用OCT
- 研究/医療用 OCT
- 蛍光イメージング・測定
- 顕微鏡
- ランプ、SLD、ASE 光源の置き換え
- FBG の特性評価
- CWDM / DWDM 部品の評価
- 3Dディスプレイシステム

### 産業用途
SuperK COMPACT は、小型・低価格・長寿命であるため、研究用途よりも産業用途に向いています。標準品は筐体から出ている Photonic Crystal Fiber の先端にある高性能コリメータもしくは FCコネクタ (FC/PC or FC/APC) から Supercontinuum レーザーが出力されます。

### SuperK COMPACT の構成
SuperK COMPACT は、小型で安価なマイクロチップレーザーを種光源として、NKT Photonics が本製品用に開発した Photonic Crystal Fiber を組み合わせるだけのシンプルな構成です。現在の SuperK COMPACT は第4世代です。NKT Photonics は世界中の企業・研究機関と研究のコラボレーションをする一方で、エンジニアリングにも資本を投入しています。

## 資料ダウンロード
- [データシート：SuperK COMPACT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-COMPACT-Datasheet.pdf#view=Fit)
- [アプリケーションノート：Supercontinuum の生成方法](https://www.sevensix.co.jp/wp-content/uploads/Application_note_-_Supercontinuum-SC-5.0-1040.pdf#view=Fit)

## よくあるご質問
SuperK COMPACT は繰返し周波数可変のパルスレーザです。外部トリガ入力ポートがあり、低ジッタにパルス出力を最大 20 kHz まで対応します。