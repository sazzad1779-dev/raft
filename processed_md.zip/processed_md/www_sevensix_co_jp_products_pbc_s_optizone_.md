# 偏光ビームコンバイナ/スプリッタ

## 製品概要
- **品名**: 偏光ビームコンバイナ/スプリッタ
- **モデル**: (型番なし)
- **カテゴリ**: 光ファイバ部品
- **中カテゴリ**: 光コンバイナ/スプリッタ
- **小カテゴリ**: 偏波ビームコンバイナ/スプリッタ
- **メーカー**: Optizone Technology Limited
- **波長範囲**: 1064 ~ 2000nm
- **ポート数**: 1×2 / 2×2

Optizone Technology Limitedは、中国の深センに拠点を構える企業で、偏光ビームコンバイナ/スプリッタを提供しています。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、高品質・高安定性を兼ね備えています。年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品に特化しており、9000㎡の工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高消光比
- 高リターンロス

## 用途
- EDFA & ラマン分光
- ファイバレーザ

## 仕様詳細
以下の表は、偏光ビームコンバイナ/スプリッタの主要な仕様を示しています。

| 項目         | 詳細内容                                         |
|--------------|--------------------------------------------------|
| 波長         | 1064nm、1310nm、1480nm、1550nm、2000nm、その他も対応可 |
| ポート数     | 1×2、2×2                                       |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                         |

## 資料ダウンロード
- [データシート：1064nm 1x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-007D-PBCS-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 2x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-006C-PBCS-1064nm-2x2-1.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-009D-PBCS-1310nm1550nm-1x2-2.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 Polarization Beam Combiner/Splitter (High Extinction Ratio)](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-049B-High-ER-PBCS-1310nm1550nm-1x2-1.pdf#view=Fit)
- [データシート：1064nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-052C-HPBCS-1064nm-1x2-1.pdf#view=Fit)
- [データシート：1310nm、1480nm、1550nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-053C-HPBCS-1310nm1550nm-1x2-1.pdf#view=Fit)
- [データシート：2000nm 1x2 High Power Polarization Beam Combiner/Splitter](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-055C-HPBS-20.pdf#view=Fit)
- [データシート：1064nm 1x2 High Power Polarization Beam Combiner/Splitter (Ultra-Fast Fiber Lasers)](https://www.sevensix.co.jp/wp-content/uploads/CAT-11-004B-HPBCS-1064nm-1x2-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、上記の情報を参照してください。

# Source URL: https://www.sevensix.co.jp/products/pbc_s_optizone/