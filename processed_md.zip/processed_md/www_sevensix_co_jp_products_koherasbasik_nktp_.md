# 小型モジュール型 超低ノイズ 狭線幅ファイバレーザー『Koheras BASIK』

- **カテゴリ**: ファイバーレーザー・その他光源
- **中カテゴリ**: 狭線幅CWレーザー光源
- **メーカー**: NKT Photonics A/S
- **モデル**: 型番なし
- **波長**: 1535 ~ 1580nm / 1030 ~ 1120nm
- **最大出力**: 40mW

[Source URL](https://www.sevensix.co.jp/products/koherasbasik_nktp/)

## 製品概要
Koheras BASIKは小型モジュール構成で、産業用システムへのOEM統合に適しています。このモデルはKoherasシリーズの中で最もシンプルな構成であり、他のKoherasシリーズのベースモデルとなっています。例えば、Koherasのベンチトップ型シリーズであるKoheras ADJUSTIKには、Koheras BASIKが内蔵されています。

また、Koheras ACOUSTIKを使用することで、最大16台のKoheras BASIKレーザを3U 19インチラック筐体に出力することが可能です。NKT Photonicsが無償配布しているCONTROLというPC用ソフトウェアを用いることで、Koheras BASIKのピーク波長、出力、RIN抑圧度を読み出し、直感的に制御できます。

## 特長
- 超低位相雑音と狭線幅
- 安定した単一周波数動作
- 産業向けOEMパッケージ
- マルチチャンネルシステム向け設計 (ACOUSTIK)
- 高速波長変調を組み込み（オプション）
- PM出力（non-PM出力は要相談）

## 用途
Koheras BASIKは、高い周波数安定性と長いコヒーレンス長が求められる干渉用途で威力を発揮します。具体的な用途としては、オイル＆ガスの探索/開発、油田周辺やパイプラインの安全確保のための感震センシングがあります。低RINにより強度ノイズが低く、スペクトル安定性が高いため、宇宙産業や風力発電で使用されるLIDARシステムの光源に最適です。また、干渉計を用いるドップラ振動計の光源としても振動の正確な計測が可能です。

## Koheras ACOUSTIK マルチチャンネルプラットフォーム
Koheras ACOUSTIKは、Koheras BASIK単一周波数低ノイズファイバレーザを最大16台搭載可能な電源込みのラックシステムです。ACOUSTIKは搭載中のKoheras BASIKに電源を供給し、それぞれを制御します。BASIKは簡単にACOUSTIKに出し入れでき、光増幅器モジュールであるKoheras BOOSTIKの搭載も可能です。

このシステムは、堅牢性が求められる産業用途に対応するため、パッシブ冷却システムデザインとなっています。標準的な3U 19インチラック筐体には、制御エレクトロニクスと電源が含まれています。各BASIKやBOOSTIKレーザモジュールには、ACOUSTIKのフロントパネルから直接アクセスできます。Koheras ACOUSTIKと搭載したBASIKおよびBOOSTIKモジュールは、NKT Photonicsが無償配布しているCONTROLソフトウェアを用いて制御できます。

## 資料ダウンロード
- [データシート：Koheras BASIK](https://www.sevensix.co.jp/wp-content/uploads/Koheras_BASIK.pdf#view=Fit)
- [データシート：Koheras ACCOUSTIK](https://www.sevensix.co.jp/wp-content/uploads/Koheras_ACCOUSTIK.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ