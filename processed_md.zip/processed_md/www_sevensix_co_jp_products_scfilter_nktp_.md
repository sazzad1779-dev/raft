# 白色レーザー光源用 高機能波長選択フィルタ

## 概要
- **カテゴリ**: ファイバーレーザー・その他光源
- **中カテゴリ**: 広帯域白色レーザー光源
- **小カテゴリ**: 波長帯域幅可変光フィルタ
- **メーカー**: NKT Photonics A/S
- **波長選択範囲**: 400 ~ 2300nm

## モデル一覧
- **モデル**: LLTF
  - **型番**: SWIR, VIS
- **モデル**: SuperK CONNECT
  - **型番**: FD1-PM, FD10, FD2, FD3, FD3-PM, FD4, FD4-PM, FD5, FD6, FD7, FD8, FD9
- **モデル**: SuperK SELECT
- **モデル**: SuperK SPLIT
- **モデル**: SuperK VARIA

## 製品の特徴
白色スーパーコンティニューム光源用の高機能フィルタで、NKT PhotonicsのSuperKシリーズのフィルタアクセサリは、15-pin sub-Dケーブルで接続され、PCの専用ソフトウェアを介して制御されます。

### SuperK アクセサリの比較表
以下の表は、SuperKシリーズの各フィルタアクセサリの主な特長を示しています。

| モデル名         | 特徴                                                                                     |
|------------------|------------------------------------------------------------------------------------------|
| **SuperK SPLIT** | 400 – 2400 nmのスペクトルを可視域と近赤外領域に分割。主な用途は蛍光イメージングなど。 |
| **SuperK SELECT**| 任意の波長を同時に選択可能。出力安定性 ± 0.5 %。主な用途は超解像イメージングなど。   |
| **LLTF**         | 高分解能で中心波長を可変。可視域と赤外域の2モデル。帯域外スペクトル抑圧比 > 60 dB。   |
| **SuperK VARIA** | 400 – 840 nmで任意の中心波長、スペクトル幅10 – 100 nm。高透過率で高感度アプリケーションに最適。 |
| **SuperK CONNECT**| フィルタリング後のコリメートビームを再結合するファイバ結合ユニット。出力端は3種類。 |

### 各モデルの詳細

#### SuperK SPLIT
- **波長範囲**: 400 – 2400 nm
- **用途**: 蛍光イメージング、ナノ構造の特性評価、光学機器の評価
- **特長**:
  - 標準で830 nmまたは1120 nmでスペクトルを分割
  - ファイバ出力可能 (FCコネクタまたはコリメータ出力)

#### SuperK SELECT
- **用途**: 走査型レーザ検眼鏡、超解像イメージング、フローサイトメトリー
- **特長**:
  - スペクトル幅 0.5 – 19.8 nm
  - 任意の1～16色を出力
  - 出力安定性 ± 0.5 %
  - ファイバ出力可能 (FCコネクタまたはコリメータ出力)

#### LLTF
- **波長範囲**: 400 – 1000 nm または 1000 – 2300 nm
- **特長**:
  - 狭帯域 & 高分解能
  - 帯域外スペクトル抑圧比 > 60 dB
  - 非常に優れたビーム位置安定性

#### SuperK VARIA
- **波長範囲**: 400 – 840 nm
- **特長**:
  - 高出力可能 (スペクトル幅に依存)
  - 帯域外スペクトル抑圧比 > 50 dB
  - 高透過率 70 – 90 %

#### SuperK CONNECT
- **用途**: フィルタリング後のコリメートビームを再結合
- **出力端**: FC/PCコネクタ、FC/APCコネクタ、コリメータの3種類

## 資料ダウンロード
- [データシート：SuperK SPLIT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-SPLIT-Datasheet.pdf#view=Fit)
- [データシート：SuperK SELECT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-SELECT-Datasheet.pdf#view=Fit)
- [アプリケーションノート：SuperK SELECTを用いたパワーロックオプションの説明](https://www.sevensix.co.jp/wp-content/uploads/application_note_-_SuperK_Power_Lock_and_modulation_V01-2.pdf#view=Fit)
- [データシート：SuperK LLTF](https://www.sevensix.co.jp/wp-content/uploads/SuperK-LLTF-Datasheet.pdf#view=Fit)
- [データシート：SuperK VARIA](https://www.sevensix.co.jp/wp-content/uploads/SuperK-VARIA-Datasheet-1.pdf#view=Fit)
- [データシート：SuperK CONNECT](https://www.sevensix.co.jp/wp-content/uploads/SuperK-CONNECT-Datasheet.pdf#view=Fit)
- [データシート：SuperK Accessories](https://www.sevensix.co.jp/wp-content/uploads/SuperK-Accessories-Datasheet-1.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行ってください。
[Source URL](https://www.sevensix.co.jp/products/scfilter_nktp/)