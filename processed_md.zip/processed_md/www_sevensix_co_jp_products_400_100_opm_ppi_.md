# 400G/100G 光パワーメータ

## 概要
- **カテゴリ**: 光計測器
- **中カテゴリ**: パワーメータ
- **メーカー**: PPI Inc.
- **品名**: 400G/100G 光パワーメータ
- **モデル**: (型番なし)
- **Source URL**: [https://www.sevensix.co.jp/products/400_100_opm_ppi/](https://www.sevensix.co.jp/products/400_100_opm_ppi/)

400GbE / 100GbE高速光通信規格をサポートするハンディタイプの光パワーメータです。このデバイスは、100GbE-LR4/ER4/CWDM4や400GbE-FR4の波長多重された信号光のレベルを波長毎に測定・表示することができ、さらに100GbE-SR4/400GbE-DR4のMPOケーブルの多芯ファイバの光レベルをレーン毎に同時に測定・表示します。

## 特長
- 400GbE/100GbE規格の波長毎・レーン毎の光パワー測定が可能
- 通常の光パワーメータとしても使用可能（850/1310/1550nm）
- バッテリ駆動で7時間使用可能（USB充電式）
- ハンディタイプで小型軽量
- USB接続でPCへデータ転送（データファイル形式: CSV）

## 用途
- 光通信用信号光のレベル測定

## 仕様詳細
以下の表は、NSK-LCOPMおよびPPI-MPO-12の仕様とディスプレイ表示例を示しています。

| モデル       | 測定波長         | 特徴                                   |
|--------------|------------------|----------------------------------------|
| NSK-LCOPM    | 850/1310/1550nm  | 通常の光パワーメータとして使用可能   |
| PPI-MPO-12   | SR4/DR4用        | MPOケーブルの多芯ファイバの測定に対応 |

## 資料ダウンロード
- [カタログ：NSK-LCOPM (LR4/ER4/CWDM4/FR4用)](https://www.sevensix.co.jp/wp-content/uploads/%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0_PPI%E8%A5%BF%E5%B7%9D%E8%A8%88%E6%B8%AC_NSK-LCOPM.pdf#view=Fit)
- [カタログ：PPI-MPO-12 (SR4/DR4用)](https://www.sevensix.co.jp/wp-content/uploads/%E3%82%AB%E3%82%BF%E3%83%AD%E3%82%B0_PPI_MPO%E3%83%91%E3%83%AF%E3%83%BC%E3%83%A1%E3%83%BC%E3%82%BF%E3%83%BB%E5%85%89%E6%BA%90.pdf#view=Fit)