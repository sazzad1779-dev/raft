# ベンチトップ型 狭線幅波長可変レーザー

**カテゴリ:** ファイバーレーザー・その他光源  
**中カテゴリ:** 狭線幅CWレーザー光源  
**メーカー:** ID Photonics GmbH  
**モデル:** 型番なし  
**発振波長:** 186 ～ 196THz  
**Source URL:** [https://www.sevensix.co.jp/products/cobritedx_idphotonics/](https://www.sevensix.co.jp/products/cobritedx_idphotonics/)

ベンチトップタイプの狭線幅チューナブルレーザー、CoBrite DXシリーズです。4CHモデルはタッチパネルを搭載し、ウェブブラウザからアクセスしてPC制御やソフトウェアのインストールも可能です。ラインナップには、4CHモデルの他に1CHモデル、2CHモデル、48CHモデルもございます。

## 特長
- 仕様範囲全体にわたる完全なチューナビリティ
- CおよびLバンドへの拡張（1525nm～1625nm）
- 最大出力: 17.8dBm
- レーザー線幅: < 25kHz
- 偏波保持出力
- ブラウザーベースのコントロール用統合ウェブサーバー
- 19インチラックマウント可能

## 用途
- 光ファイバー通信
- コヒーレント光トランシーバー開発
- 局部発振器
- シリコンフォトニクス
- 光学・物理研究への多用途光源

## モデル一覧
- **CoBrite DX – 4CHモデル**: タッチパネル搭載、イーサネット対応（リモート制御可）
- **CoBrite DX2 – 2CHモデル**: イーサネット対応（リモート制御可）
- **CoBrite DX1 – 1CHモデル**
- **CoBrite MX – 48CHモデル**

## 仕様詳細
### 製品比較表
この表は、CoBrite DXシリーズの各モデル（4CH、2CH、1CH、48CH）の主要な特長や機能を比較しています。各モデルは、タッチパネルの有無やリモート制御の対応状況が異なります。

## 資料ダウンロード
- [データシート：CoBrite DXシリーズ](https://www.sevensix.co.jp/wp-content/uploads/DataSheet_IDPhotonics_CoBrite_Series.pdf#view=Fit)