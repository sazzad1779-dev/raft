# 超低ノイズ 狭線幅ファイバレーザー ラインナップ『Koheras』シリーズ

- **カテゴリ**: ファイバーレーザー・その他光源
- **中カテゴリ**: 狭線幅CWレーザー光源
- **メーカー**: NKT Photonics A/S
- **波長**: 1030 ~ 1120nm / 1535 ~ 1580nm / 766 ~ 780nm

『Koheras』シリーズは、研究用途に特化した高性能な狭線幅ファイバレーザーです。真のシングル縦モードDFBファイバレーザー構成を採用しており、モードホップフリーで非常に高い安定性を誇ります。

## Koheras シリーズラインナップ

以下の表は、Koherasシリーズの各モデルの出力と波長範囲を示しています。

| モデル | BASIK (OEM) | BASIK MIKRO (OEM) | ADJUSTIK (Benchtop) | ADJUSTIK HP (Benchtop) | BOOSTIK HP (Benchtop) | HARMONIK (Benchtop) |
| --- | --- | --- | --- | --- | --- | --- |
| C15 | 10 mW @ 1535 ~ 1580 nm | – | 10 mW @ 1535 ~ 1580 nm | 2 W / 0.2 W @ 1545 ~ 1565 nm | – | > 4 W @ λ/2, λ |
| E15 | 40 mW @ 1535 ~ 1580 nm | 40 mW @ 1530 ~ 1580 nm | 40 mW @ 1535 ~ 1580 nm | 2 W @ 1545 ~ 1565 nm | 5W / 10W / 15W @ 1550 ~ 1570 nm | > 4 W @ λ/2, λ |
| X15 | 30 mW @ 1535 ~ 1580 nm | – | 22.5 mW @ 1535 ~ 1580 nm | 0.2 W @ 1545 ~ 1565 nm | – | – |
| Y10 | 10 mW @ 1030 ~ 1120 nm | – | 10 mW @ 1030 ~ 1120 nm | 0.2 W @ 1060 ~ 1075 nm | 5W / 10W / 15W @ 1050 ~ 1090 nm | > 7 W @ λ/2, λ |

### OEM / Benchtop

Koherasシリーズは、OEMタイプとBenchtopタイプの2つに分類されます。OEMタイプは、マルチチャンネルプラットフォームに最適な筐体と、機能を制限した小型筐体に分かれます。Benchtopタイプは、OEMタイプと同程度の出力を持つものと、光ファイバ増幅器と組み合わせて高出力を実現するものに分かれます。

### モデルの特徴

- **C15**: 波長1535 – 1580 nmで動作するEr/Yb添加ファイバレーザー。業界で最も低いRINレベルを持ち、ショット雑音限界のシステム構築が可能。
- **E15/X15**: 波長1535 – 1580 nmで動作するエルビウム添加ファイバレーザー。位相雑音と周波数雑音が低く、狭線幅が特徴。特にX15は波長安定性に優れ、1.5 um帯の最上位モデル。
- **Y10**: 波長1030 – 1120 nmで動作するYb添加ファイバレーザー。狭線幅と低強度雑音が特徴で、様々な研究用途に適している。

### チューニング / PM出力

- **PM出力**: Koherasファイバレーザーの出力ポートは通常PM（偏波保持）ファイバで、出力レーザの偏光方向はSlow軸のみ。
- **温度による波長チューニング**: デフォルトで波長の温度チューニングが可能で、指定した波長に安定化。
- **高速波長チューニング**: 高速波長チューニングオプションは、より高い波長安定性が求められる用途に必要。

## Koheras BOOSTIK HP : Benchtop / OEM 高出力

Koheras BOOSTIK HPはメンテナンスフリーの単一周波数ファイバレーザで、BenchtopタイプはKoheras ADJUSTIKと専用のEDFA/YDFAが組み合わさったモデルです。狭線幅、優れたビーム品質、高出力性を兼ね備え、ラボ内での実験や研究用途に最適です。

## 資料ダウンロード

- [アプリケーションノート：Koherasレーザの位相ノイズについて](https://www.sevensix.co.jp/wp-content/uploads/laser-phase-noise-application-note-version-1-0-october-2013.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの線幅について](https://www.sevensix.co.jp/wp-content/uploads/linewidth-application-note-version-1-1-october-2013.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの波長チューニングについて](https://www.sevensix.co.jp/wp-content/uploads/NKT-Photonics-App-notes.pdf#view=Fit)
- [アプリケーションノート：Koherasレーザの周波数安定性について](https://www.sevensix.co.jp/wp-content/uploads/frequency-stability-application-note-version-1-1-.pdf#view=Fit)

## 製品に関するお問い合わせ

この製品のお問い合わせは、以下のリンクからご確認ください。

[Source URL](https://www.sevensix.co.jp/products/koherasseries_nktp/)