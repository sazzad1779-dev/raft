# マルチモードWDMフィルタ型カプラ

**カテゴリ:** 光ファイバ部品  
**中カテゴリ:** WDMカプラ  
**メーカー:** Optizone Technology Limited  
**モデル:** (型番なし)  
**波長:** 1310nm Pass / 850 ~ 1550nm Reflect  

Optizone Technology LimitedのマルチモードWDMフィルタ型カプラは、中国の深センに拠点を構えています。全製品はTelcordia規格、RoHS指令、REACH規制に対応しており、高品質・高安定性を兼ね備えています。年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失
- 高リターンロス

## 用途
- 研究用途

## 仕様詳細
この仕様表は、マルチモードWDMフィルタ型カプラの主要な性能パラメータを示しています。波長は複数のオプションがあり、1310nm Pass / 1550nm Reflect、1550nm Pass / 1310nm Reflect、850nm Pass / 1310nm Reflect、1310nm Pass / 850nm Reflectが含まれます。コア直径は62.5umと50umの2種類、コネクタタイプはFC/UPC、FC/APC、SC/UPC、SC/APC、無し、その他に対応可能です。ファイバジャケットは250umベアファイバ、900umルーズチューブ、3mmケーブル、その他に対応可能で、ファイバ長は1.0m及びその他に対応可能です。

|     |     |
| --- | --- |
| 波長 | 1310nm Pass / 1550nm Reflect、1550nm Pass / 1310nm Reflect、850nm Pass / 1310nm Reflect、1310nm Pass / 850nm Reflect |
| コア直径 | 62.5um、50um |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、無し、その他対応可能 |
| ファイバジャケット | 250umベアファイバ、900umルーズチューブ、3mmケーブル、その他対応可能 |
| ファイバ長 | 1.0m、その他対応可能 |

## 資料ダウンロード
- [データシート：Multimode Filter Wavelength Division Multiplexer](https://www.sevensix.co.jp/wp-content/uploads/CAT-08-002D-MMFWDM-8501550nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ  
[Source URL](https://www.sevensix.co.jp/products/m_wdmfiltertc_optizone/)