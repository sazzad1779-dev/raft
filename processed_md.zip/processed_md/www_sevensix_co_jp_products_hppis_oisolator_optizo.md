# 高出力偏波無依存空間出力型アイソレータ

**カテゴリ:** 光ファイバ部品  
**サブカテゴリ:** 光ファイバアイソレータ、コリメータ付きアイソレータ  
**メーカー:** Optizone Technology Limited  
**モデル:** 型番なし  
**波長:** 1064nm  
**入力パワー:** 5W ~ 500W  

Optizone Technology Limitedの高出力偏波無依存空間出力型アイソレータは、中国の深センに拠点を置き、全製品がTelcordia規格、RoHS指令、REACH規制に対応しています。高品質・高安定性を兼ね備え、年間18,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 高アイソレーション
- 低偏波依存性損失
- 低挿入損失

## 用途
- 光ファイバ増幅器
- ファイバレーザ

## 仕様詳細
以下の表は、アイソレータの主要な仕様を示しています。

| 項目         | 詳細内容                                   |
|--------------|--------------------------------------------|
| 波長         | 1064nm、その他も対応可                    |
| 入力パワー   | 5W、10W、20W、100W、150W、200W、350W、500W、その他も対応可 |
| ビーム径     | 5mm、6mm、7mm、その他も対応可            |
| ファイバ被膜 | 900umルーズチューブ、3mmルーズチューブ、3mmアーマードケーブル、6mmアーマードケーブル、7mmアーマードケーブル、10mmアーマードケーブル、その他も対応可 |
| ファイバ長   | 標準1m、その他も対応可                    |

## パッケージタイプ
- Type D72
- Type D3
- Type D62
- Type D143
- Type D157

## 資料ダウンロード
- [データシート：1064nm 5W、10W、20W High Power Collimated Beam Output Isolator](https://www.sevensix.co.jp/wp-content/uploads/HPICI-1064nm-Type-D72-5W20WCAT-05-065C.pdf#view=Fit)
- [データシート：1064nm 5W、10W、20W High Power Collimated Beam Output Isolator](https://www.sevensix.co.jp/wp-content/uploads/HPICI-1064nm-Type-D3-5W20WCAT-05-012G.pdf#view=Fit)
- [データシート：1064nm 10W、20W High Power Collimated Beam Output Isolator](https://www.sevensix.co.jp/wp-content/uploads/HPICI-1064nm-Type-D62-5W20WCAT-05-061D.pdf#view=Fit)
- [データシート：1064nm 100W、150W、200W High Power Collimated Beam Output Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-077B.pdf#view=Fit)
- [データシート：1064nm 350W、500W High Power Collimated Beam Output Isolator](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-080A-1064nm-High-Power-Polarization-Insensitive-Collimated-Beam-Isolator-D157.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせは、以下のリンクから行えます。  
[Source URL](https://www.sevensix.co.jp/products/hppis_oisolator_optizone/)