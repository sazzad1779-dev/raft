大カテゴリ: 光増幅器/ 光変調器/ PD/ 光フィルタ他  
中カテゴリ: 光フィルタ  
小カテゴリ: 光ハイブリッド  
メーカ: Optizone Technology Limited  
品名: 偏波保持アイソレータ / WDMハイブリッド  

モデル:  
- モデル: (型番なし)  

# 偏波保持アイソレータ / WDMハイブリッド
波長: 1530 ~ 1580nm / 1530 ~ 1565nm  
_メーカ：_ Optizone Technology Limited  

Optizone Technologiesは中国の深センに拠点を構え、偏波保持アイソレータ/WDMハイブリッドを提供しています。全製品はTelcordia規格、RoHS指令、REACH規制に対応し、高品質・高安定性を兼ね備えています。年間20,000ケ以上を生産し、北米、ヨーロッパ、アジアを含む全世界へ出荷しています。高出力用受動部品を特に得意としており、9,000㎡の大規模な工場でカスタム仕様の小ロットからOEM受注生産まで幅広く対応可能です。

## 特長
- 低挿入損失

## 用途
- ファイバレーザ
- ファイバセンサ
- 光増幅器

## 仕様詳細
この仕様表は、偏波保持アイソレータ/WDMハイブリッドの主要な性能パラメータを示しています。波長は1530-1580nmおよび1530-1565nmで、シングルまたはデュアルステージのオプションがあります。光軸アライメントはFast Axis BlockedまたはBoth Axis Workingが選べ、コネクタタイプはFC/UPC、FC/APC、SC/UPC、SC/APC、Noneなどに対応しています。ファイバ被膜は250umベアファイバ、900umルーズチューブなどがあり、ファイバ長は標準1mでその他の長さにも対応可能です。

|     |     |
| --- | --- |
| 波長 | 1530-1580nm、1530-1565nm |
| ステージ | シングル、デュアル |
| 光軸アライメント | Fast Axis Blocked、Both Axis Working |
| コネクタタイプ | FC/UPC、FC/APC、SC/UPC、SC/APC、None、その他も対応可 |
| ファイバ被膜 | 250umベアファイバ、900umルーズチューブ、その他も対応可 |
| ファイバ長 | 標準1m、その他も対応可 |

### パッケージ
- 標準タイプ
- 小型タイプ

## 資料ダウンロード
- [データシート：1530-1580nm PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-028F-PMIWDM-15301565nm-new.pdf#view=Fit)
- [データシート：1530-1565nm High Power PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-05-050D-HPMIWDM-15301565nm.pdf#view=Fit)
- [データシート：1530-1565nm Mini PM Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/MPMIWDM-CAT-09-039B.pdf#view=Fit)
- [データシート：1530-1565nm PM Tap Isolator Wavelength Division Multiplexer Hybrid](https://www.sevensix.co.jp/wp-content/uploads/CAT-09-031F-PMTIWDM-5598nm.pdf#view=Fit)

## 製品に関するお問い合わせ
この製品のお問い合わせ  

# Source URL: https://www.sevensix.co.jp/products/pmi_wdmhybrid_optizone/